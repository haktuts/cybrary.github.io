<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Linux</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link href="css/10.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance1300" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li class="active"><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance1302" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance1301" class="wb_element"><ul class="vmenu"><li><a href="Installation-1/" target="_self" title="Installation">Installation</a></li><li><a href="Intro-to-File-Directory-1/" target="_self" title="Intro to File Directory">Intro to File Directory</a></li><li><a href="Basic-Commands-1/" target="_self" title="Basic Commands">Basic Commands</a></li><li><a href="File-Management-1/" target="_self" title="File Management">File Management</a></li><li><a href="VIM-1/" target="_self" title="VIM">VIM</a></li><li><a href="User-Group-Management-1/" target="_self" title="User &amp; Group Management">User &amp; Group Management</a></li><li><a href="Maintenance-of-Linux-system-1/" target="_self" title="Maintenance of Linux system">Maintenance of Linux system</a></li><li><a href="System-Management-1/" target="_self" title="System Management">System Management</a></li><li><a href="Network-Managemnt/" target="_self" title="Network Managemnt">Network Managemnt</a></li><li><a href="Server-Management-1/" target="_self" title="Server Management">Server Management</a></li><li><a href="Security-1/" target="_self" title="Security">Security</a></li><li><a href="Shell-Scripting-1/" target="_self" title="Shell Scripting">Shell Scripting</a></li></ul></div><div id="wb_element_instance1306" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>LINUX </strong> is a Unix-like and mostly POSIX-compliant  computer operating system assembled under the model of free and open-source software development and distribution. The defining component of Linux is the Linux kernel, an operating system kernel first released on 5 October 1991 by Linus Torvalds. The Free Software Foundation uses the name GNU/Linux to describe the operating system.</p>

<p class="wb-stl-normal">Linux is the first truly free Unix-like operating system. The underlying GNU Project was launched in 1983 byRichard Stallman originally to develop a Unix-compatible operating system called GNU, intended to be entirely free software. Many programs and utilities were contributed by developers around the world, and by 1991 most of the components of the system were ready. Still missing was the kernel.</p>

<p class="wb-stl-normal">Linus Torvalds invented Linux itself in 1991. This kernel, which is called Linux, was afterwards combined with the GNU system to produce a complete free operating system.</p>

<p class="wb-stl-normal">Linux Kernel was bundled with many software's from various distributors and it gave rise to many flavors of  LINUX.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<h2 class="wb-stl-heading2">Features Of Linux OS:</h2>

<p class="wb-stl-normal">1. Open Source- Free</p>

<p class="wb-stl-normal">2. Multitasking</p>

<p class="wb-stl-normal">3. Multi-User</p>

<p class="wb-stl-normal">4.Portable</p>

<p class="wb-stl-normal">5.Reliability</p>

<p class="wb-stl-normal">6.Scalability</p>

<p class="wb-stl-normal">7.Networking &amp; Security</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>
</div><div id="wb_element_instance1307" class="wb_element"><img alt="" src="gallery/15d356c4c3389cbf72261920d60d7334_300x167.jpg"></div><div id="wb_element_instance1308" class="wb_element"><img alt="" src="gallery/6f3bc553a041b5afba74343d5bc5d0b6_608x414.jpg"></div><div id="wb_element_instance1309" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(10);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance1309");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance1309").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance1303" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance1304" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance1305" class="wb_element"><div id="wb_element_instance1305_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance1305_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance1305_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1305_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1305_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1305_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance1305_toolbox"); }
			</script></div><div id="wb_element_instance1310" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>