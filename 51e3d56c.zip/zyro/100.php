<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>News2</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/100.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance608" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance609" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance613" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">THE LAST AND THE 3RD FOUNDER OF “THE PIRATE BAY” ARRESTED</h1>

<p> </p>

<p><span style="color:#bebebe;">Fredrik Neij – known online as “TiAMO”, third and the last founder of the popular file sharing website The Pirate Bay has been arrested driving across the border of Laos and Thailand.The 36-year-old fugitive Fredrik Neij was convicted by a Swedish court in 2009 of aiding copyright infringement and now he has been arrested under an Interpol warrant after four years on the run.</span></p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;">The Pirate Bay allows users to share files, including copyrighted content such as movies and music, through peer-to-peer technology.He fled the country after being released on bail and had been living in Laos with his wife and children since 2012. Neij was arrested on Monday while trying to cross a border checkpoint in Nong Khai province, about 385 miles northeast of Bangkok, with his wife.</span></p>

<p> </p>

<p><span style="color:#bebebe;">Pirate Bay’s first Founder Gottfird Svartholm, who used the alias “Anakata” on the Internet, was also found guilty of hacking by a Danish court and is now serving a three-and-a-half year sentence, while the second founder – Peter Sunde is serving the final days of an eight month sentence in Sweden.</span></p>

<p><span style="color:#bebebe;">But “The Pirate Bay” is still alive working well and normal.</span></p>

<p> </p>

<p> </p>

<h1 class="wb-stl-heading1">CHINA UNVEILS LASER DRONE DEFENCE SYSTEM</h1>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;">China has developed a highly accurate laser weapon system that can shoot down light drones at low altitude, state media reported.</span></p>

<p><span style="color:#bebebe;">The machine has a 1.2-mile range and can bring down “various small aircraft” within five seconds of locating its target, the official Xinhua news agency said, citing a statement by the China Academy of Engineering Physics (CAEP), one of the developers.</span></p>

<p><span style="color:#bebebe;">Xinhua showed pictures of large metal boxes in camouflage paint and the wreckage of a small drone, some of it burning.</span></p>

<p><span style="color:#bebebe;">The laser system is expected to “play a key role in ensuring security during major events in urban areas” and address concerns on unlicensed mapping activities, according to Xinhua. It is effective up to a maximum altitude of 500 metres and against aircraft flying at up to 50 metres per second (112mph), Xinhua said.</span></p>

<p><span style="color:#bebebe;">It cited Yi Jinsong, a manager with China Jiuyuan Hi-Tech Equipment Corp, as saying that small-scale, unmanned drones were relatively cheap and easy to use, making them a likely choice for terrorists.</span></p>

<p><span style="color:#bebebe;">“Intercepting such drones is usually the work of snipers and helicopters, but their success rate is not as high and mistakes with accuracy can result in unwanted damage,” he said.</span></p>

<p><span style="color:#bebebe;">The system, which can be installed on vehicles, shot down more than 30 drones in a recent test with a “100% success rate” said the CAEP statement.</span></p>

<p><span style="color:#bebebe;">The academy is developing similar laser security systems with greater power and range, Xinhua said in its report on Sunday.</span></p>

<p><span style="color:#bebebe;">China typically deploys tight security for domestic political meetings, international conferences and sports events, looking to prevent public protests over issues such as illegal land seizures and corruption as well as any threats to the participants.</span></p>

<p> </p>

<p> </p>

<h1 class="wb-stl-heading1">Russian Cyber Attack on U.S. Critical Infrastructure</h1>

<p> </p>

<p><span style="color:#bebebe;">America’s power grids, nuclear plants and oil pipelines and many others important critical utilities have been targeted by Russian hackers.</span></p>

<p><span style="color:#bebebe;">Hackers using a Trojan Horse called Black Energy which infected systems years ago but has not been activated and only recently discovered.</span></p>

<p><span style="color:#bebebe;">Cyber attack by using Black Energy could allow the attacker to use the internet to shut down a generator, wind turbines, nuclear plants, water treatment plants.</span></p>

<p><span style="color:#bebebe;">According to the Department of Homeland Security (DHS) Black Energy is the same malware that was used by a Russian cyber-espionage group dubbed “Sandworm” to target NATO and some energy and telecommunications companies in Europe earlier this year.</span></p>

<p> </p>
</div><div id="wb_element_instance614" class="wb_element"><img alt="" src="gallery/d06fc7134e4a71d1472d67a2cb3727e0_250x180.jpg"></div><div id="wb_element_instance615" class="wb_element"><img alt="" src="gallery/ccddf75dbd93ec958e252d9b9ad8384a_370x200.jpg"></div><div id="wb_element_instance616" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(100);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance616");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance616").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance610" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance611" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance612" class="wb_element"><div id="wb_element_instance612_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance612_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance612_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance612_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance612_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance612_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance612_toolbox"); }
			</script></div><div id="wb_element_instance617" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>