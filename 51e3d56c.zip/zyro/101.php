<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>News3</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/101.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance618" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance619" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance623" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">FBI Seize Silk Road 2.0 Servers; Admin Arrested</h1>

<p> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><br>
The authorities of the U.S. Federal Bureau of Investigation have announced that they have arrested "Silk Road 2.0" operator Blake Benthall, used the alias "Defcon" in California on Wednesday and charged him with conspiracy to commit drug trafficking, computer hacking, money laundering and other crimes.<br>
Silk Road 2, an alternative to the notorious online illegal-drug marketplace that went dark in October of 2013, has been seized in a joint action involving the FBI, Department of Homeland Security, and European law enforcement.<br>
The arrest comes almost a year after the arrest of a San Francisco man Ross William Ulbricht, also known as "Dread Pirate Roberts," — the alleged founder of the dark Web online drug bazaar "Silk Road" that generated $8 million in monthly sales and attracted 150,000 vendors and customers. At that time, FBI seized the notorious site, but the very next month, a nearly identical site, Silk Road 2.0, opened for business.</p>

<p class="wb-stl-normal"><br>
The Feds and the US Department of Justice claim 26-year-old Blake Benthall launched the notorious Silk Road 2.0 on Nov. 6, 2013, five weeks after the shutdown of the original Silk Road website and arrest of its alleged operator.<br>
Benthall appeared Thursday afternoon in federal court before Magistrate Judge Jaqueline Scott Corley, where Assistant US Attorney Kathryn Haun told the judge that Benthall is a "severe flight risk," according to the San Francisco Chronicle.<br>
Benthall is charged with conspiring to commit narcotics trafficking, conspiring to commit computer hacking, conspiring to traffic in fraudulent identification documents and money laundering. If convicted, he could be sentenced to life in prison.<br>
Silk Road 2.0 operated much the same way as its predecessor did, it sold illegal goods and services on the Tor network and generates millions of dollars each month. As of September 2014, Benthall allegedly processed $8 Million in monthly sales, according to the FBI.<br>
In order to maintain the the anonymity of buyers and sellers, Silk Road 2.0 offers transactions to be made entirely in Bitcoin, as well as accessed through The Onion Router, or TOR, which conceals Internet Protocol (IP) addresses enabling users to hide their identities and locations.<br>
According to the FBI, it bought 1 kilogram of heroin, 5 kilograms of cocaine, and 10 grams of LSD from Silk Road 2.0, apparently from Benthall himself.</p>

<p class="wb-stl-normal">Silk Road 2.0 had over 13,000 listings for controlled substances, including, among others, 1,783 listings for 'Psychedelics,' 1,697 listings for'“Ecstasy,' 1,707 listings for 'Cannabis,' and 379 listings for 'Opioids.<br>
 </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<h1 class="wb-stl-heading1">Facebook Now Accessible Via Tor Anonymous Network Using .Onion Address</h1>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p><br>
 </p>

<p> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;">If you are fan of the largest social networking site Facebook, but also want to remain anonymous while using your Facebook account, then there is really a Good news for you.<br>
Facebook  began offering a way for security and Privacy conscious users to connect to its social networking service using the anonymizing service running on the Tor network, by launching a .onion address. This is really a historic move of the social network.<br>
Tor Browser is an open source project, launched in 2002, designed to increase the anonymity of your activities on the Internet by not sharing your identifying information such as your IP address and physical location with websites and your service providers. Browsing and data exchange over a network is made through encrypted connections between computers.<br>
The social network just created a special URL – https://facebookcorewwwi.onion – that will allow users running Tor-enabled browsers to connect Facebook’s Core WWW Infrastructure. Hidden services accessed through the Tor network allow both the Web user and website to remain anonymous. Do note that the Tor link will only work on Tor-enabled browsers.</span></p>

<p class="wb-stl-normal"><br><span style="color:#bebebe;">Facebook has previously been criticised by Tor users as the company’s security features treated Tor as a botnet — a collection of computers designed to attack the site. Users were able to access their Facebook account before today, but it often loaded irregularly with incorrectly displayed fonts and sometimes didn't load at all.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">Back in 2013, the social network assured Tor users that the company would work with Tor service on a possible solution. Now, after a year, we can see a great move from Facebook’s side with the launch of a dedicated Tor access address. However, the company said that the Tor network may poses some risks as the .onion address is described as an "experiment" by the social network.<br>
Furthermore, the company also offers encryption using SSL over Tor with a certificate that cites the unique Tor address, so that users won’t have to deal with SSL certificate warnings and can therefore be assured they are connecting to a secure and real Facebook, preventing users from being redirected to fake sites.</span></p>

<p> </p>

<p><span style="color: rgb(190, 190, 190); font-family: 'Times New Roman', Times, serif; font-size: 20px; line-height: 30px;">Google Releases 'nogotofail' Network Traffic Security Testing Tool</span></p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p class="wb-stl-normal"><span style="color: rgb(190, 190, 190);">Google introduced a new security tool to help developers detect bugs and security glitches in the network traffic security that may leave passwords and other sensitive information open to snooping.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">The open source tool, dubbed as Nogotofail, has been launched by the technology giant in sake of a number of vulnerabilities discovered in the implementation of the transport layer security, from the most critical Heartbleed bug in OpenSSL to the Apple's gotofail bug to the recent POODLE bug in SSL version 3.<br>
The company has made the Nogotofail tool available on GitHub, so that so anyone can test their applications, contribute new features to the project, provide support for more platforms, and help improve the security of the internet.<br>
Android security engineer Chad Brubaker said that the Nogotofail main purpose is to confirm that internet-connected devices and applications aren't vulnerable to transport layer security (TLS) and Secure Sockets Layer (SSL) encryption issues.<br>
The network security testing tool includes testing for common SSL certificate verification issues, HTTPS and TLS/SSL library vulnerabilities and misconfigurations, SSL and STARTTLS stripping issues, and clear text traffic issues, and more.</span></p>

<p class="wb-stl-normal"><br><span style="color:#bebebe;">Nogotofail tool, written by Android engineers Chad Brubaker, Alex Klyubin and Geremy Condra, works on devices running Android, iOS, Linux, Windows, Chrome OS, OS X, and “in fact any device you use to connect to the Internet.” The tool can be deployed on a router, a Linux machine, or a VPN server.<br>
The company says it has been using the Nogotofail tool internally for "some time" and has worked with developers to improve the security of their apps before releasing it. "But we want the use of TLS/SSL to advance as quickly as possible.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">The Nogotofail tool requires Python 2.7 and pyOpenSSL&gt;=0.13. It features an on-path network Man-in-the-Middle (MiTM), designed to work on Linux machines, as well and optional clients for the devices being tested.</span></p>

<p class="wb-stl-normal"><br>
 </p>
</div><div id="wb_element_instance624" class="wb_element"><img alt="" src="gallery/89b00c19bdd561c6a96d6bb08da82d64_450x270.jpg"></div><div id="wb_element_instance625" class="wb_element"><img alt="" src="gallery/e00224c48879ec8a70373f1ddef010af_484x252.jpg"></div><div id="wb_element_instance626" class="wb_element"><img alt="" src="gallery/0a6e57534fa5cbfd6637368cbe8e1183_335x150.jpg"></div><div id="wb_element_instance627" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(101);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance627");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance627").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance620" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance621" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance622" class="wb_element"><div id="wb_element_instance622_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance622_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance622_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance622_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance622_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance622_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance622_toolbox"); }
			</script></div><div id="wb_element_instance628" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>