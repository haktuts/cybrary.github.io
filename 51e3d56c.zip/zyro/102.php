<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>iOS</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="AirBlue Sharing 7
AirBlue Sharing 7 brings true Bluetooth sharing to iOS 7 powered devices. After installing it on their devices users can share all kinds of files from one device to another. With AirBlue Sharing 7 the Bluetooth file transfer is not limited to iOS to iOS as users can also send or receive files from OS X, Windows, Android and other devices powered by other softwares." />
	<meta name="keywords" content="BEST CYDIA TWEAKS FOR iOS" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/102.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance629" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li class="active"><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li class="active"><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance630" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance634" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">BEST CYDIA TWEAKS FOR iOS</span></h1>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">AirBlue Sharing 7</span></h1>

<p><span style="color:#bebebe;">AirBlue Sharing 7 brings true Bluetooth sharing to iOS 7 powered devices. After installing it on their devices users can share all kinds of files from one device to another. With AirBlue Sharing 7 the Bluetooth file transfer is not limited to iOS to iOS as users can also send or receive files from OS X, Windows, Android and other devices powered by other softwares.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Augmented </span></h1>

<p><span style="color:#bebebe;">Uses Live Camera Feed to Replace Your iOS Wallpaper.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Guest Mode</span></h1>

<p><span style="color:#bebebe;"> I have seen many iPhone, iPad Air, iPad Mini and iPod Touch users concern to give their iDevice with important data to other user or relatives. Actually, its okay, because its your data and its depend on you that you wanna share or not. Guest Mode is new jailbreak tweak that allows user to choose apps, tweaks and functionality to share with your guest user.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Activator</span></h1>

<p><span style="color:#bebebe;">Activator has been the must have app for many years and it seems like it is going to stay that for many years to come. With this tweak iOS users can make doing different things on their device much easier. Activator enables users to assign different actions for tasks which includes pressing of buttons multiple times and on-screen gestures. Performing an Activator gesture can trigger different operations. The latest edition of Activator even allows users to assign actions to Touch ID, which makes it even more useful and fun. Activator can be downloaded from Cydia for free.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">CleverPin</span></h1>

<p><span style="color:#bebebe;">CleverPin is another tweak related to passcode. With this hack installed users don’t have to enter passcode again and again when they are at home, listening to music, charging battery and more. It intelligently handles the passcode problem making the process less annoying for iOS users.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">RecordMyScreen (tweak)</span></h1>

<p><span style="color:#bebebe;">RecordMyScreen tweak provides an instant way for iOS users to record their on screen activity and share it with their friends. After installing this tweak users can assign an Activator action to it and instantly start recording after performing that action. There are a few options to configure that can be found within the Settings app. RecordMyScreen is available for free.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Scramble Pass</span></h1>

<p><span style="color:#bebebe;">Randomly rearrange passcode buttons.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">TapToUnlock7 </span></h1>

<p><span style="color:#bebebe;"> As the name suggests, the jailbreak tweak replaces the Apple’s patented slide to unlock feature with a “tap to unlock” button, which allows you to unlock your iPhone by tapping on it.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Appellancy</span></h1>

<p><span style="color:#bebebe;">unlock your iPhone using Facial Recognition.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">BioProtect</span></h1>

<p><span style="color:#bebebe;">BioProtect tweak makes iPhone 5s’ more useful by allowing users to protect indivisual apps with their fingerprints. This tweak only allows access to apps after the user has verified authorization using his or her fingerprint.AppScan is a free alternative to BioProtect with similar functionality.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">iFile</span></h1>

<p><span style="color:#bebebe;">iFile is a file management app for iOS devices that gives root access to users. It allows file transfer to root directory of the device wirelessly from a web browser. Users can move, edit, rename as well as delete files using iFile application. iFile allows photos, sounds, text, HTML, sounds, iWork, PDF, Compressed and other types of file transfers.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Zeppelin</span></h1>

<p><span style="color:#bebebe;">Zeppelin enables iOS users to give their device a personal touch by replacing the carrier name with a cool logo from their favorite brand, game or movie. Users can also create and  upload their own art to Zeppelin. It is a free download.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">iCleaner</span></h1>

<p><span style="color:#bebebe;">iCleaner is a jailbreak app that makes it easier for users to remove unnecessary files from their iPhone, iPad or iPod touch thus free up space for other stuff. It deletes message attachments, Safari data, data related to apps, Cydia and more. iCleaner app deleted nearly 1GB of data on my first attempt. iCleaner is available for free in Cydia.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">AdBlocker</span></h1>

<p><span style="color:#bebebe;">AdBlocker for jailbroken iOS devices does exactly what AdBlocker extension does on desktop browsers. This tweak can significantly make web experience better on iOS devices by blocking ads on Safari and third party browsers.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color: rgb(190, 190, 190); background-color: transparent;">BytaFont 2</span></h1>

<p><span style="color:#bebebe;">BytaFont 2 makes it simple for iOS 7 users to change the font of their iPhone, iPad or iPod touch. Users can download fonts of their choice from Cydia and apply them using this jailbreak application. BytaFont 2 allows users to apply fonts to all parts of the OS or at specific areas. BytaFont 2 is free in Cydia and so are its fonts. It is one of the best tweaks to change the visual look of iOS 7.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">BiteSMS</span></h1>

<p><span style="color:#bebebe;">Just like Activator the BiteSMS tweak has been around from several years and has established itself as a favorite and most popular tweak among iOS users. It allows users to instantly reply to text messages or initiate a call without leaving the current app they are in. BiteSMS 8 with support for iOS 7 and ARM64 devices is available in Cydia for free. You have to add http://test-cydia.bitesms.com/ repo to get it as it is still in beta.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">ByPass</span></h1>

<p><span style="color:#bebebe;">ByPass makes having passcode protection less painful by allowing users to skip entering their password by performing an Activator action. Users can set a secret gesture that they can perform to ByPass passcode. ByPass tweak requires Activator and is available for free.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">CCHide</span></h1>

<p><span style="color:#bebebe;">CCHide is a Control Center tweak using which users can change the appearance of this section of iOS. CCHide enables users to hide the sections of CC they don’t use or conditionally hide the music controls when they are not required. CCHide can be used to make Control Center shorter, minimalistic and less crowded. It is available in Cydia for free with full support for ARM64 devices.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">FlipControlCenter</span></h1>

<p><span style="color:#bebebe;">With this tweak you can add, remove and rearrange the switches in the top and bottom shelves of Control Center. Users can add new toggles and links to their Control Center and even suppress some of them from being accessible from the lockscreen.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Swipey</span></h1>

<p><span style="color:#bebebe;">Swipey adds a simple app launcher to the lockscreen that can be accessed simply by swiping. Users can launch their most used apps right from the homescreen by swiping to opposite direction of ‘Slide to unlock’ gesture. Swipey allows upto to six apps to be added in the launcher.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">SwipeSelection</span></h1>

<p><span style="color:#bebebe;">SwipeSelection is an infamous jailbreak tweak that recently got updated for iOS 7. It brings a new way to edit text on iPhone, iPad or iPod touch making the task easier by adding gestures. SwipeSelection is free as well.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Winterboard</span></h1>

<p><span style="color:#bebebe;">This list of must have Cydia tweaks and apps could not be  complete without the inclusion of Winterboard. This tweak enables iOS users to apply themes and other third party visual elements on their device giving iOS a fresh new look. Although Winterboard has yet to receive update for iOS 7 and ARM64 it is still working on iOS 7 devices other than iPhone 5s, iPad mini Retina Display and iPad Air. Winterboard is free.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">CyDelete</span></h1>

<p><span style="color:#bebebe;">CyDelete makes it easier to delete applications that were downloaded from Cydia. With CyDelete installed users can delete Cydia apps just like they delete App Store ones. Its free.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">f.lux</span></h1>

<p><span style="color:#bebebe;"> f.lux tweak changes the brightness settings and temperature of the display according to the lighting conditions of the place you are at. This makes using the device less painful for the eyes. f.lux is free.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">SkipLock</span></h1>

<p><span style="color:#bebebe;">SkipLock simply removes the lockscreen when there are no pending notifications (or passcode protection) allowing users to access their device simply by pressing the home button or the lock button. It is free, too.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">IntelliScreenX</span></h1>

<p><span style="color:#bebebe;">If you are a frequent user of the Notification Center, then this tweak is for you. IntelliScreenX further enhances the Notification Center to your liking, and makes reading the things that are important to you a breeze. You can set up pages for your Twitter, Facebook, RSS Reader, and your Mail account. Also with the ability to access IntelliScreenX from the lockscreen, this tweak will make your social life much more accessible on your iOS Device</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Gestr</span></h1>

<p><span style="color:#bebebe;">Brings a whole new way to launch apps/multitask on the iOS device. It allows users to assign gestures to a specific app and launch the app using the assigned gesture.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Asphaleia</span></h1>

<p><span style="color:#bebebe;">Allows users to protect their apps and folders. Once your app is locked, you tap the app icon, an animated fingerprint scanning UI appears within the icon of the app. This is unlike all other similar tweaks that push a dialog box asking you to scan your fingerprint in ordeAppellancy – unlock your iPhone using Facial Recognitionr to get access.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Auxo 2 </span></h1>

<p><span style="color:#bebebe;">The popular alternative to the iOS app switcher. This new app switcher is packed with customizable toggles and redesigned music controls. Each app in the switcher displays a screenshot with a small centered icon and title. If you’d like to close out of an app, simply swipe down on the screenshot.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Apex 2 </span></h1>

<p><span style="color:#bebebe;">Allowes users to group app icons in folder-like structures.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">AltKeyboard 2 </span></h1>

<p><span style="color:#bebebe;">Awesome keyboard tweak.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">AppSync 7.0</span></h1>

<p><span style="color:#bebebe;">Allowing iPhone, iPad and iPod touch users to install unofficial apps on their devices. </span></p>
</div><div id="wb_element_instance635" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(102);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance635");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance635").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance631" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance632" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance633" class="wb_element"><div id="wb_element_instance633_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance633_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance633_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance633_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance633_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance633_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance633_toolbox"); }
			</script></div><div id="wb_element_instance636" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>