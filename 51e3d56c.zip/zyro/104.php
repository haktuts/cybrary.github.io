<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Desktop Phishing</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="In this we will not create a hosting,a websiteand even we do not have to send victim a spoofed mail too instead we will use our own webserver to store webpages and scripts and we will create our own file and we will send the file to the victim." />
	<meta name="keywords" content="how to hack someone account without sending victim a spoofed page" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/104.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance656" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance657" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance661" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">Desktop Phishing</span></h1>

<p> </p>

<p><span style="color:#bebebe;">In this we will not create a hosting,a websiteand even we do not have to send victim a spoofed mail too instead we will use our own webserver to store webpages and scripts and we will create our own file and we will send the file to the victim.</span></p>

<p><span style="color:#bebebe;">In this method we will need a</span></p>

<p><span style="color:#bebebe;">A <strong>WebServer</strong> - for hosting data</span></p>

<p><span style="color:#bebebe;">A <strong>php script</strong> - it will be the same script that we used in Phishing.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Xampp</strong> - For creating a Webserver</span></p>

<p><span style="color:#bebebe;">The main vulnerbility and our profit lies in one file called hosts.txt in the directory in <strong>C:/windows/system32/drivers/etc/</strong> just put backslash instead of forword slash just open it up and create a copy on the desktop.</span></p>

<p><span style="color:#bebebe;">Now do not mess up with this and leave it as it is Now is the time to create a web server so quickly go to and download it and install it than start it and go to htdocs folder you can search it or you can go to the directory you installed nd put your phishing page in it and rename it to index.html and put your phishing php script in it too</span></p>

<p><span style="color:#bebebe;">Now for testing open your browser and type <strong>https://127.0.0.1</strong> as address and type in your credentials and click on log in and then go to your htdocs folder and look at the logs.txt file it will display your username and Password there so Now What?</span></p>

<p><span style="color:#bebebe;">Go and connect your net and then go to run and type cmd</span></p>

<p><span style="color:#bebebe;">Now type ipconfig and it will show your ip copy your ip and open the host.txt file up and paste your ip in new line and after leaving somespaces type the domain of the website you want to hack and then save it up and then right click on it and choose compress and archive and click on create sfx archieve and just above that in update mode choose add and replace files</span></p>

<p><span style="color:#bebebe;">Now goto files and under files to add type <strong>C:/windows/system32/drivers/etc/host.txt</strong> what this will do is when victim opens the file it will quickly replace the file with the one we created and when he will open the website which we want to hack than even the url will not change the url and our phishing page will open as soon as he types the credentials we will be able to get the password and username in our logs.txt  .</span></p>

<p> </p>

<p><span style="color:#bebebe;"><strong>Note:</strong> Static ip is required for this type of attack.</span></p>
</div><div id="wb_element_instance662" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(104);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance662");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance662").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance658" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance659" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance660" class="wb_element"><div id="wb_element_instance660_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance660_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance660_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance660_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance660_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance660_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance660_toolbox"); }
			</script></div><div id="wb_element_instance663" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>