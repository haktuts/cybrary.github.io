<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>install android lollipop</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/111.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance716" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance717" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance721" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">How to install Android Lollipop.</h1>

<p> </p>

<p><span style="color:#bebebe;">Install Android Lollipop Developer Preview</span></p>

<p><br><span style="color:#bebebe;">NOTE: If you've already installed a preview of Android, skip to step 2.<br>
Step 1. <a data-target="true" data-type="url" data-url="https://www.dropbox.com/s/hlp8lelbyge5q1d/AndroidTool.rar?dl=0" href="https://www.dropbox.com/s/hlp8lelbyge5q1d/AndroidTool.rar?dl=0" target="_blank">Download</a> the minimal 2MB installer from this XDA thread this XDA thread which includes the Android ADB and fastboot tools.You need these to install the Android L image, and this is the quickest and easiest way to install the tools without downloading the entire Android SDK, which is huge and contains stuff you don’t need to get Android L.<br>
Follow the instructions (don’t change the installation path when asked where to install it) and you should end up with a command prompt window<br><br>
Step 2. Download the appropriate file for your device:<br>
Nexus 5<br>
Nexus 7<br>
Extract the files to the same folder as the Minimal ADB and Fastboot<br>
Once extracted you should have a list of files as per the image below. (Note you do NOT need to unzip the zip file. Leave this as it is<br><br>
Step 3. On your phone or tablet, head to Settings, and scroll down to About phone at the bottom. Scroll down to Build number and tap it 7 times. This unhides the developer options, which aren’t displayed in Android 4.2 and later.<br>
 In the Developer options menu, enable USB debugging. You'll need to do this even if you are running the preview version of Android L. And if you are, now skip to step 6.<br><br>
Step 4. Download the Google USB driver from here here and extract the zip file somewhere.</span></p>

<p><span style="color:#bebebe;">Step 5. Now, Power off your device, and leave it connected to your computer’s USB port. Now start it using the appropriate key combination to put it in “fastboot” mode.<br>
For the Nexus 5, that’s by holding down the volume up, volume down and power buttons simultaneously. Press power and volume down on the Nexus 7. Alternatively, you can leave your device on and type adb reboot-bootloader to restart in fastboot mode.</span></p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p><br><span style="color:#bebebe;">Step 6. If the LOCK STATE says locked (which it should) then type ‘fastboot oem unlock’ at the command prompt, without the quotes, and press Enter. This WILL erase your device, so make sure you’ve backed everything up first<br><br>
Step 7. With the bootloader unlocked, you can now install the Android Lollipop firmware. Simply type<br>
flash-all and the process will begin.</span></p>

<p> </p>

<p> </p>
</div><div id="wb_element_instance722" class="wb_element"><img alt="" src="gallery/cea1a31b1c2b00b4b5b10299dba1354c_600x500.jpg"></div><div id="wb_element_instance723" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(111);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance723");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance723").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance718" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance719" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance720" class="wb_element"><div id="wb_element_instance720_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance720_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance720_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance720_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance720_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance720_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance720_toolbox"); }
			</script></div><div id="wb_element_instance724" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>