<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>windows in android</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/112.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance725" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance726" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance730" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;"> Install windows in android device.</span></h1>

<p><br><span style="color:#bebebe;">1.First create a blank image file in Bochs on your PC and for that what you have to do is that go to Start and open up Bochs&gt; and then Disk image creation tool and then the new tab with black screen appears.</span></p>

<p><br><span style="color:#bebebe;">2.In that you have to type hd and press enter.</span></p>

<p><br><span style="color:#bebebe;">3.After that it go to the next line here you have to type flat and it will ask the size. Here you have to type 1500.</span></p>

<p><br><span style="color:#bebebe;">4.Then type in c.img and then press the enter key</span></p>

<p><br><span style="color:#bebebe;">5.The next thing is that you have to install Windows XP on blank .img file using Qemu manager, then open up the Qemu manager.</span></p>

<p><br><span style="color:#bebebe;">6.After opening up the Qemu manager, click on the VM on the top left side and select new virtual machine.</span></p>

<p><br><span style="color:#bebebe;">7. Then a sub tab appears and type out any name that you need in the first box and hit next.</span></p>

<p><br><span style="color:#bebebe;">8. Now in the new tab you can locate the desired RAM that you want to change and change it to 1 Giga hertz and hit finish.</span></p>

<p><br><span style="color:#bebebe;">9. Now what you want to do is install XP to your blank image file. So what you want to do is click on drives on the left top side and find out the c.img file from the drives. Usually the c.img file will be seen at the C drive&gt; Program files &gt; flash &gt; and change view to all files and your c.img file will be seen select the file and click Okay.</span></p>

<p><br><span style="color:#bebebe;">10.The next thing you have to do is find out the Window XP.iso file and click Ok. </span></p>

<p><br><span style="color:#bebebe;">11. After selecting the iso file click on the run button on the top left side.</span></p>

<p><br><span style="color:#bebebe;">12.Installation will take about 45 minutes or about an hour depending on how fast your computer is and right now it will be running on a virtual machine. Wait till the loading finishes and after that start the installation and a couple of options comes out choose from. Choose ntfs file system and then the installation will take place and it will take few minutes to complete.</span></p>

<p><br><span style="color:#bebebe;">13.When the installation is finished, the next thing you have to do is that you have to stop the virtual machine, for that press the red button on the top left and click Ok. And then you have to find the c.img file and transfer it to phone. For that find out the c.img file from the local disk as mentioned above and copy the file and paste the file in the SDL folder on the SD card. And after that go to the link I have given below and copy the text with code given and paste it in the boch.txt file in the SDL folder on the SD card. </span></p>

<p><br><span style="color:#bebebe;">Note:The next thing you have to do is turn on your phone and take out the application Bosh which has been installed on your device .one thing you must remember is that it will be not as fast as your personal computer and you need a lot of patience for the loading to finish for the first time. After loading is finished you may be in a black display screen for a little bit time and there you must wait for few minutes and then you can run XP on your Android device. </span></p>
</div><div id="wb_element_instance731" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(112);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance731");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance731").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance727" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance728" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance729" class="wb_element"><div id="wb_element_instance729_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance729_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance729_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance729_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance729_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance729_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance729_toolbox"); }
			</script></div><div id="wb_element_instance732" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>