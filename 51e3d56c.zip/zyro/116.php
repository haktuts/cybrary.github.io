<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Lock &amp; Unlock Pc via USB</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/116.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance762" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance763" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance767" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal">Lock &amp; Unlock Windows PC with a USB Drive.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;">PREDATOR locks your PC when you are away, even if your Windows session is still opened.<br>
It uses a regular USB flash drive as an access control device, and works as follows:</span></p>

<ul><li class="wb-stl-normal"><span style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;">You insert the USB drive</span></li>
	<li class="wb-stl-normal"><span style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;"><span style="color:#bebebe;">You run PREDATOR (autostart with Windows is possible)</span></span></li>
	<li class="wb-stl-normal"><span style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;"><span style="color:#bebebe;"><span style="color:#bebebe;">you do your work...</span></span></span></li>
	<li class="wb-stl-normal"><span style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;">When you're away from your PC, you simply remove the USB drive:</span></span></span></span></li>
	<li class="wb-stl-normal"><span style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"> Once it is removed, the keyboard and mouse are disabled and the screen darkens</span></span></span></span></span></li>
	<li class="wb-stl-normal"><span style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;">When you return back to your PC, you put the USB flash drive in place:</span></span></span></span></span></span></li>
	<li class="wb-stl-normal"><span style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;">Keyboard and mouse are immediately released, and the display is restored.</span></span></span></span></span></span></span></li>
</ul><p class="wb-stl-normal"><span style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;"><span style="color:#bebebe;">In case if you lose your USB key, you can still type your password to get access to your computer.</span></span></span></span></span></span></span></span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<h1 class="wb-stl-heading1">Steps to use Predator Tool:</h1>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">1.First, download Predator Free Edition, it also has Professional Edition that you need to buy and has some better features. Predator Free Edition has the basic features required for the protection of a home computer.</p>

<p class="wb-stl-normal">2.After download completes, extract its contents into My Documents, then run InstallPredator.exe file. When prompted for an installation folder, accept the default path "C:\Program Files\Predator2\" or select your desired folder on your hard drive, but do not select a folder on your USB flash drive. Never install PREDATOR on removable media.<br>
3.The installer program will automatically start Predator application. If not, you can launch it manually via the Start Menu or via the PREDATOR icon on the Desktop. A dialog box will ask you to enter a password and to prepare a USB flash drive. Now its time to insert your USB drive and click Ok. (your data in USB pen drive will not be disturbed).<br>
4.Now, you'll see the Preferences window.<br>
5.Now, as you can see Three tab on top of Preferences; Main options, Alarm options and Advanced options.</p>

<p class="wb-stl-normal">Type the password you want in the "Password" field. This will also be used to unlock your session if you lose your USB key. <br>
Below the password field, check the drive letter displayed under "Flash drives" it should match with your flash drive letter or choose the correct letter from the drop-down list. <br>
Then click "Create key" button and finally, click Ok.</p>

<p class="wb-stl-normal">6.Predator will exit after this setup procedure, here a window will appear saying Predator setup complete.</p>

<p class="wb-stl-normal">7.Finally, click the Predator icon installed on the desktop to restart the program. When you restart Predator, initialization takes a few seconds, then a green ball icon should flash in the system tray.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Note:When you want to leave your PC, look at the PREDATOR icon in the taskbar: if it is red, wait. If it is green and blinking, remove the USB key. And, your Windows desktop will be locked in a few moments, depending on the settings you have made.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">If somebody tries to use your PC, PREDATOR shows the password dialog and starts a countdown.<br>
If an invalid password is entered, PREDATOR sounds an audible alarm and displays a blinking Access Denied sign.<br><br>
When you're back, insert the USB key. The desktop will be unlocked in few second. If somebody has tried to use your PC, PREDATOR automatically opens the Log window and shows the failed access attempts.<br><br>
 </p>

<p><span style="color:#bebebe;">What if you lose/break your key:</span></p>

<p><br><span style="color:#bebebe;">Follow these instructions:</span><br>
 </p>

<p><span style="color:#bebebe;">Run PREDATOR<br>
When the screen goes black, click anywhere on the screen with the left mouse button, then press 3 times the Enter key to display the password dialog.<br>
Type your password: the session is released and the monitoring is suspended.<br>
Insert a blank flash drive.<br>
Right-click the PREDATOR icon that is in the taskbar and click the Preferences item</span></p>

<p><span style="color:#bebebe;"> </span></p>
</div><div id="wb_element_instance768" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(116);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance768");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance768").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance764" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance765" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance766" class="wb_element"><div id="wb_element_instance766_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance766_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance766_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance766_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance766_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance766_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance766_toolbox"); }
			</script></div><div id="wb_element_instance769" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>