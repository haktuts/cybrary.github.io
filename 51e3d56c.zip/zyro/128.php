<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>TOR not 100% untraceable</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link href="css/128.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance872" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance873" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance877" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">TOR USERS’ IP ADDRESSES CAN BE IDENTIFIED BY EXPLOITING ROUTERS.</h1>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Tor users’ IP addresses can be identified by exploiting routers now,  however it has previously been a tough target for law enforcement for years and FBI has spent millions of dollars to de-anonymize the identity of Tor users, the latest research suggests that more than 81% of Tor clients can be “de-anonymised” by exploiting the traffic analysis software ‘Netflow’ technology that Cisco has built into its router protocols. NetFlow is a network protocol designed to collect and monitor network traffic.</p>

<p class="wb-stl-normal">It exchanged data in network flows, which can correspond to TCP connections or other IP packets sharing common characteristics, such UDP packets sharing source and destination IP addresses, port numbers, and other information.The research was conducted for six years by professor Sambuddho Chakravarty, a former researcher at Columbia University’s Network Security Lab and now researching Network Anonymity and Privacy at the Indraprastha Institute of Information Technology in Delhi.</p>

<p class="wb-stl-normal">Here’s how his team did it, in simple terms: they repeatedly injected typical HTML files a Tor user would access into a router’s connection. Since Netflow was designed to break down and analyze traffic depending on what you use the internet for (say 25 percent email and 50 percent web browsing), they could check who accessed those HTML files and get their IP addresses. He’s convinced that a large organization (like, well, the government) can easily uncover the identities of Tor users if it wanted. In fact, he says one doesn’t even need the resources of a powerful organization to do so, as a single autonomous system programmed to de-anonymize Tor clients can monitor up to 39 percent of the browser’s traffic.</p>

<p class="wb-stl-normal">Jayson Street of Pwnie Express advises people to rely not just on one method if they truly want to be anonymous on the internet. As he told International Business Times:</p>

<p class="wb-stl-normal">End users don’t know how to properly configure it — they think it’s a silver bullet. They think once they use this tool, they don’t have to take other precautions. It’s another reminder to users that nothing is 100 percent secure. If you’re trying to stay protected online, you have to layer your defenses.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>
</div><div id="wb_element_instance878" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(128);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance878");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance878").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance874" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance875" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance876" class="wb_element"><div id="wb_element_instance876_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance876_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance876_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance876_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance876_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance876_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance876_toolbox"); }
			</script></div><div id="wb_element_instance879" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>