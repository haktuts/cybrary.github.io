<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Google works like NSA</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link href="css/129.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance880" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance881" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance885" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">Google works Like NSA by collecting, storing, and indexing user data: Assange.</h1>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Julian Assange, the WikiLeaks founder, has confirmed that Google collects, stores, and indexes people’s data, and is in fact ‘a privatized version of the NSA,’ according to media reports.</p>

<p class="wb-stl-normal">“Google’s business model is the spy. It makes more than 80 percent of its money by collecting information about people, pooling it together, storing it, indexing it, building profiles of people to predict their interests and behavior, and then selling those profiles principally to advertisers, but also others,” Assange told BBC.</p>

<p class="wb-stl-normal">However, he also admitted that it is not doing anything that is illegal.</p>

<p class="wb-stl-normal">The founder argued that Google’s work practices are almost identical to NSA adding that the company has been working with the NSA since at least 2002, in terms of contract.</p>

<p class="wb-stl-normal">“They are formally listed as part of the defense industrial base since 2009. They have been engaged with the Prism system, where nearly all information collected by Google is available to the NSA,” he said.</p>

<p class="wb-stl-normal">Additionally, at the institutional level, “Google is deeply involved in US foreign policy.”</p>

<p class="wb-stl-normal">Assange told BBC that Google has become the most influential commercial organization with its ramifications across every country and every single person with access to Internet.</p>

<p class="wb-stl-normal">He further said that the company has tricked people into believing that it is a humane organization and not a big, bad US corporation.</p>

<p class="wb-stl-normal">Julian Assange, 43 year old Australian, is staying at the Ecuadorian embassy in London since 2012. The embassy is being watched by British police round the clock who are ready to arrest him should he attempt to leave.</p>

<p class="wb-stl-normal">His stay at the embassy has impacted his work, said Assange.</p>

<p class="wb-stl-normal">“The 7.3 million pounds (US$12 million) of police surveillance admitted outside this embassy. It is a difficult situation. It is not a situation that is easy for [a] national security reporter. You can’t read sources. It is difficult to meet some of my staff because of that surveillance.”</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> However, he pointed the brighter side of his restricted movements as well.</p>

<p class="wb-stl-normal">“There are no subpoenas, there are no door knocks in the night, unlike [for] other national security reporters. So in some ways there are benefits to the situation,” he noted.</p>

<p class="wb-stl-normal">He has been optimistic about the attitude shift that has taken place recently. Britain amended its extradition laws to ban extradition without charges.</p>

<p class="wb-stl-normal">Situation has been changing in Sweden also, where he filed an appeal against a Swedish warrant, which his lawyers argue is a gross ‘breach of Swedish law.’</p>

<p class="wb-stl-normal">Meanwhile, the founder has released a book “When Google Met WikiLeaks,” wherein he describes his vision for internet future as well as recounts a meeting with Eric Schmidt, the Google chairman, in 2011.</p>

<p class="wb-stl-normal">Update: In reply to allegations, the Google’s Eric Schmidt has said that Julian Assange ‘Paranoid’.</p>

<p class="wb-stl-normal"> </p>
</div><div id="wb_element_instance886" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(129);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance886");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance886").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance882" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance883" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance884" class="wb_element"><div id="wb_element_instance884_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance884_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance884_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance884_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance884_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance884_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance884_toolbox"); }
			</script></div><div id="wb_element_instance887" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>