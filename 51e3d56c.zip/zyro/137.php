<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Firefox Addons for Pentest</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link href="css/137.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance950" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance951" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance955" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">Firefox AddOns For Pentester</h1>

<p> </p>

<p class="wb-stl-normal">1.Greasemonkey<br>
Customize the way a web page displays or behaves, by using small bits of JavaScript.</p>

<p class="wb-stl-normal"><br>
2.MultiFox</p>

<p class="wb-stl-normal">Multifox is an extension that allows Firefox to connect to websites using different user names Simultaneously! Like multiple sign in with single browser.<br><br>
3.NoScript Security Suite<br>
The best security you can get in a web browser!<br>
Allow active content to run only from sites you trust, and protect yourself against XSS and Clickjacking attacks.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">4.HackBar<br>
Simple security audit / Penetration test tool.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">5.SQL Inject Me<br>
SQL Injection vulnerabilites can cause a lot of damage to a web application. A malicious user can possibly view records, delete records, drop tables or gain access to your server. SQL Inject-Me is Firefox Extension used to test for SQL Injection vuln...</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">6.XSS Me<br>
Cross-Site Scripting (XSS) is a common flaw found in todays web applications. XSS flaws can cause serious damage to a web application. Detecting XSS vulnerabilities early in the development process will help protect a web application from unnecessary...<br><br>
7.PassiveRecon<br>
PassiveRecon provides information security professionals with the ability to perform "packetless" discovery of target resources utilizing publicly available information.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">8.CryptoFox<br>
CryptoFox is an encryption or decryption tool for Mozilla Firefox. It supports most of the available encryption algorithm. So, you can easily encrypt or decrypt data with supported encryption algorithm. This add-on comes with dictionary attack support, to crack MD5 cracking passwords.<br><br>
9.Offsec Exploit-db Search<br>
This is another plugin similar to the last two above. It also lets users search for vulnerabilities and exploits listed in exploit-db.com. This website is always up-to-date with latest exploits and vulnerability details.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">10.Magic-Net Full Online DNS Lookup <br>
DNS Search engine from Magic-NET. Full DNS records lookup, MX records lookup, Reverse lookup, PTR, rDNS, SPF records, Subdomains lookup, Multiple blacklist check, Zone Transfers.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">11.Server Spy <br>
Server Spy indicates what brand of HTTP server (e.g. Apache, IIS, etc.) runs on the visited sites.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">12.FoxyProxy Standard<br>
FoxyProxy is an advanced proxy management add-on for Firefox browser. It improves the built-in proxy capabilities of Firefox. There are few other similar kind of proxy management add-ons available, but it offers more features that other add-ons. Based on the URL patterns, it switches internet connection across one or more proxy servers. When proxy is in use, it also displays an animated icon. In case you want to see the proxies used by the tool, you can see the logs.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">13.Live HTTP Headers<br>
Live HTTP Headers is a really helpful penetration testing add-on for Firefox. It displays live headers of each http request and response. You can also save header information by clicking on the button in the lower left corner. I don’t think that there is any kind of need to tell how important this add-on is for the security testing process.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">14.Tamper Data<br>
Tamper Data is similar to the Live HTTP Header add-on but, has header editing capabilities. With the tamper data add-on, you can view and modify HTTP/HTTPS headers and post parameters. Thus it helps in security testing web application by modifying POST parameters. It can be used in performing XSS and SQL Injection attacks by modifying header data.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">15.SecurityFocus Vulnerabilities search plugin<br>
SecurityFocus Vulnerabilities search plugin, is not a security tool but a search plugin that lets users search for vulnerabilities from the Security Focus database</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">16.Firebug<br>
Firebug is a nice add-on that integrates a web development tool inside the browser. With this tool, you can edit and debug HTML, CSS and JavaScript live in any webpage to see the effect of changes. It helps in analyzing JS files to find XSS vulnerabilities. It’s an really helpful add-on in finding DOM based XSS for security testing professionals.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">17. User Agent Switcher<br>
User Agent Switcher add-on; adds a one click user agent switch to the browser. It adds a menu and tool bar button in the browser. Whenever you want to switch the user agent, use the browser button. User Agent add on helps in spoofing the browser while performing some attack.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">18.Snort IDS Rule Search<br>
Snort IDS Rule Search is another search add-on for Firefox. It lets users search for Snort IDS rules on the snort.org website. Snort is the most widely deployed IDS/IPS technology worldwide. It’s an open source network Intrusion prevention and detection system with more than 400,000 users<br>
 </p>
</div><div id="wb_element_instance956" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(137);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance956");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance956").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance952" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance953" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance954" class="wb_element"><div id="wb_element_instance954_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance954_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance954_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance954_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance954_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance954_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance954_toolbox"); }
			</script></div><div id="wb_element_instance957" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>