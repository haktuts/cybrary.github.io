<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Android Phone as WebCam</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link href="css/140.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance987" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance988" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance992" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">USE YOUR ANDROID PHONE AS WEBCAM</h1>

<p class="wb-stl-normal"> </p>

<h5 class="wb-stl-subtitle">I. Use your android phone as webcam using Wifi.</h5>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Requirement -  both your computer and your android phone should be connected to the same network with android connected via WiFi.</p>

<p class="wb-stl-normal">Once your phone is connected to the same PC network via wifi, follow these steps -</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">1.From android market in your phone, install IP Webcam.</p>

<p class="wb-stl-normal"><br>
2.Open the app and you will get the configuration screen where you can set the options for port, sound, video quality and username/password.<br>
  The default options are good enough, so scroll down and click on the "Start server" option.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">3.Ip Webcam will now open your camera and start streaming the video to a particular IP address and port. Click on the "How do I connect" button appearing on the top left  and choose "I'm using Wi-fi router" to get this IP address and port. You will get some thing like "http://10.42.43.89:8080".</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">4.Note this address down and type it in your PC web browser. You will get a page with links for various ways in which you can use your new webcam. From the list, you need to use either of the two links.</p>

<p class="wb-stl-normal">Connect to PC for use with Skype and other videochats on Windows.<br>
Connect to PC for use with Skype and other videochats on Ubuntu GNU/Linux.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">5.Depending on your operating system (Windows or Linux), use the links to download and install the webcam driver on your PC.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">6.That's it.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<h5 class="wb-stl-subtitle">II. Use your android phone as webcam using USB.</h5>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">1. Setup your phone in debugging mode (Settings -&gt; Applications -&gt; Development -&gt; USB debugging).</p>

<p class="wb-stl-normal">   Connect the phone to your computer via USB (don't select storage mode if the phone asks while connecting USB).</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">2.Download DroidCam from android market,install it and open it on your phone. It will show a "Starting server" message.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">3.Download and install the client application in your computer from Dev47Apps.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">4.Start the DroidCam client and choose the "USB" option or button.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">5.That's it. DroidCam will now open the camera on your phone and you can use it as webcam on your PC. Just configure the video settings of your video call application to use "DroidCam" driver.</p>

<p> </p>

<p> </p>

<p> </p>
</div><div id="wb_element_instance993" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(140);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance993");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance993").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance989" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance990" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance991" class="wb_element"><div id="wb_element_instance991_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance991_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance991_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance991_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance991_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance991_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance991_toolbox"); }
			</script></div><div id="wb_element_instance994" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>