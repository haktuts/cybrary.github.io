<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Network Management</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link href="css/156.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance1412" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance1413" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance1417" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal">NETWORK MANGEMENT</p>

<p class="wb-stl-normal"><br><span style="color:#f10631;">ifconfig</span><br>
Show the ip address eth0</p>

<p class="wb-stl-normal"><br><span style="color:#f10631;">iwconfig</span></p>

<p class="wb-stl-normal">show the ip address of wireless connection</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">ip addr show</span>  <br>
Display all network interfaces and ip address<br>
(a iproute2 command,powerful than ifconfig).</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">ip address add 192.168.0.1 dev eth0</span>  <br>
Set ip address</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">ethtool eth0</span> <br>
Linux tool to show ethernet status</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">mii-tool eth0</span>  <br>
Linux tool to show ethernet status</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">ping host</span>  <br>
Send echo request to test connection</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">whois domain</span>  <br>
Get who is information for domain</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">dig domain</span> <br>
Get DNS information for domain</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">dig -x host</span> <br>
Reverse lookup host</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">host haktuts.com</span> <br>
Lookup DNS ip address for the name</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">hostname -i</span> <br>
Lookup local ip address</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">wget file</span> <br>
Download file</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">wget -c file</span> </p>

<p class="wb-stl-normal">Continue stopped download</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">wget -r url</span> </p>

<p class="wb-stl-normal">recursively download files from url</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">netstat -tupl</span> <br>
Listing all active listening ports</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">hostname</span> <br>
Show system host name</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>SHARE FILE FROM WINDOWS TO LINUX.</strong></p>

<p class="wb-stl-normal">1.Share a folder in Windows PC with permission set to everyone</p>

<p class="wb-stl-normal">2.then goto terminal and type <span style="color:#f10631;">smbclient //PC NAME/Share folder name -U username</span>  and then enter password when prompted.</p>

<p class="wb-stl-normal">e.g. <span style="color:#f10631;">smbclient //HAKTUTS/Ethicalhacking -U hak</span><br><br><strong>SSH-Secure Shell</strong><br><span style="color:#f10631;">ssh user@host</span> <br>
Connect to host as user</p>

<p class="wb-stl-normal">e.g.: ssh admin@haktuts.com</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">ssh -p port user@host</span> <br>
Connect using port p</p>

<p class="wb-stl-normal">e.g. ssh -22 admin@haktuts.com</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#f10631;">ssh -D port user@host</span> <br>
Connect and use bind port</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>FTP-File Transfer Protocol</strong></p>

<p class="wb-stl-normal"><span style="color:#f10631;">ftp</span></p>

<p class="wb-stl-normal">Type ftp in terminal then</p>

<p class="wb-stl-normal"><span style="color: rgb(241, 6, 49);">ftp&gt; open ftp.hak.com</span></p>

<p class="wb-stl-normal">The above command will open ftp session and then type your ftp username &amp; password.</p>

<p class="wb-stl-normal">username:ftp username</p>

<p class="wb-stl-normal">password:ftp pasword</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><br>
 </p>
</div><div id="wb_element_instance1418" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(156);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance1418");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance1418").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance1414" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance1415" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance1416" class="wb_element"><div id="wb_element_instance1416_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance1416_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance1416_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1416_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1416_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1416_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance1416_toolbox"); }
			</script></div><div id="wb_element_instance1419" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>