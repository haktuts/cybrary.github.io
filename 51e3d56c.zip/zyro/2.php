<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Ethical Hacking</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="which encompasses formal and methodical penetration testing, white hat hacking, and vulnerability testing — involves the same tools, tricks, and techniques that criminal hackers use, but with one major difference: Ethical hacking is performed with the target’s permission in a professional setting." />
	<meta name="keywords" content="Free online ethical hacking course" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383877" rel="stylesheet" type="text/css" />
	<link href="css/2.css?ts=1425383877" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance10" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li class="active"><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance12" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance11" class="wb_element"><ul class="vmenu"><li><a href="Introduction-1/" target="_self" title="Introduction">Introduction</a></li><li><a href="Hackers-Hierarchy-1/" target="_self" title="Hackers Hierarchy">Hackers Hierarchy</a></li><li><a href="Hackers-Keyword-1/" target="_self" title="Hackers Keyword">Hackers Keyword</a></li><li><a href="Virus/" target="_self" title="Virus">Virus</a></li><li><a href="what-are-the-different-types-of-virus-1/" target="_self" title="Types of Virus">Types of Virus</a></li><li><a href="HOW-TO-get-Protect-From-Virus-1/" target="_self" title="Protect from virus">Protect from virus</a></li><li><a href="IP-and-MAC-1/" target="_self" title="IP and MAC">IP and MAC</a></li><li><a href="WHAT-IS-IP-Address-1/" target="_self" title="Concept of IP ">Concept of IP </a></li><li><a href="What-are-the-types-of-IP-Address-1/" target="_self" title="Types of IP">Types of IP</a></li><li><a href="HOW-TO-MAC-Spoof-without-tools-1/" target="_self" title="MAC Spoofing">MAC Spoofing</a></li><li><a href="how-to-surf-on-web-anonymously-1/" target="_self" title="Anonymous Surfing">Anonymous Surfing</a></li><li><a href="How-to-bind-two-exe-file-in-one-another-via-command-prompt-1/" target="_self" title="Steganography">Steganography</a></li><li><a href="how-to-bind-one-exe-file-with-another-exe-file-1/" target="_self" title="Tools of Steganography">Tools of Steganography</a></li><li><a href="list-of-tools-to-detect-steganography-1/" target="_self" title="Detecting Steganography">Detecting Steganography</a></li><li><a href="What-is-cryptography-1/" target="_self" title="Cryptography">Cryptography</a></li><li><a href="What-are-the-types-of-Cryptography-1/" target="_self" title="Types of Cryptography">Types of Cryptography</a></li><li><a href="how-to-send-a-spoofed-mail-1/" target="_self" title="Email Hacking">Email Hacking</a></li><li><a href="Tools-of-Password-Cracking-1/" target="_self" title="Password Cracking">Password Cracking</a></li><li><a href="How-to-crack-a-zip-or-rar-password-protected-file-1/" target="_self" title="Rar Password Cracking">Rar Password Cracking</a></li><li><a href="How-to-crack-a-pdf-password-protected-file-1/" target="_self" title="PDF Password Cracking">PDF Password Cracking</a></li><li><a href="HOW-TO-Bypassing-Windows-8-1-Password-1/" target="_self" title="Windows Password Cracking">Windows Password Cracking</a></li><li><a href="Information-Gathering/" target="_self" title="Information Gathering">Information Gathering</a></li><li><a href="Introduction-to-Android-architecture-1/" target="_self" title="Android">Android</a></li><li><a href="how-to-root-android-device-via-one-click-1/" target="_self" title="Rooting Andoid Device">Rooting Andoid Device</a></li><li><a href="how-to-bypass-the-screen-lock-of-android-devices-1/" target="_self" title="Lock Screen Bypass of Android Device">Lock Screen Bypass of Android Device</a></li><li><a href="how-to-perform-pentesting-via-android-device-1/" target="_self" title="Pentesting Android Device">Pentesting Android Device</a></li><li><a href="best-android-hacking-tools-for-rooted-smartphone-1/" target="_self" title="Some Useful Android Stuff">Some Useful Android Stuff</a></li><li><a href="iOS-1/" target="_self" title="iOS">iOS</a></li><li><a href="HOW-TO-Jailbreak-iOS-DEVICE-1/" target="_self" title="Jailbreak iOS Device">Jailbreak iOS Device</a></li><li><a href="list-of-tools-to-jailbreak-ios-device-1/" target="_self" title="Jailbreak tools for iOS Device">Jailbreak tools for iOS Device</a></li><li><a href="how-to-establish-ssh-connection-with-iphone-1/" target="_self" title="SSH For iOS">SSH For iOS</a></li><li><a href="How-to-setup-fully-undetectable-Remote-Keylogger-1/" target="_self" title="Keylogger">Keylogger</a></li><li><a href="meaning-of-virtual-machine-1/" target="_self" title="Virtualization">Virtualization</a></li><li><a href="advantages-of-virtual-machine-1/" target="_self" title="Benefits of Virtualization">Benefits of Virtualization</a></li><li><a href="how-to-setup-virtual-machine-1/" target="_self" title="Setup Virtual Machine">Setup Virtual Machine</a></li><li><a href="how-to-install-ubuntu-in-virtual-machine-1/" target="_self" title="Install ubuntu via virtual machine">Install ubuntu via virtual machine</a></li><li><a href="Introduction-of-backtrack-1/" target="_self" title="Backtrack">Backtrack</a></li><li><a href="top-command-of-backtrack-for-hacking-1/" target="_self" title="Command For Backtrack">Command For Backtrack</a></li><li><a href="top10-command-of-nmap-1/" target="_self" title="Information Gathering Via NMAP">Information Gathering Via NMAP</a></li><li><a href="How-to-hack-windows-7-with-metasploit-1/" target="_self" title="Backtrack Payload">Backtrack Payload</a></li><li><a href="how-to-perform-dos-attack-using-kali-linux/" target="_blank" title="Kali">Kali</a></li><li><a href="types-of-wifi-1/" target="_self" title="Wifi Hacking">Wifi Hacking</a></li><li><a href="how-to-crack-wep-protected-wifi-1/" target="_self" title="      Crack WEP Encryption">      Crack WEP Encryption</a></li><li><a href="how-to-crack-wpawpa2-protected-wifi-1/" target="_self" title="Crack WPA/WPA2 Encryption">Crack WPA/WPA2 Encryption</a></li><li><a href="how-to-hack-wifi-via-pyrit-1/" target="_self" title="How to speed up the hacking process">How to speed up the hacking process</a></li><li><a href="how-to-perform-Lan-phishing/" target="_blank" title="Desktop Phishing">Desktop Phishing</a></li><li><a href="how-to-hack-website-via-cross-site-scripting/" target="_blank" title="Cross site scripting">Cross site scripting</a></li><li><a href="how-to-hack-the-website/" target="_blank" title="Remote attack">Remote attack</a></li><li><a href="How-to-hack-databases-of-website-using-sql-injection/" target="_blank" title="SQL Injection">SQL Injection</a></li><li><a href="How-to-hack-website-through-clickjacking-1/" target="_self" title="Click Jacking Attack">Click Jacking Attack</a></li><li><a href="HOW-TO-HACK-FACEBOOK-ACCOUNT-VIA-PHISHING-METHOD-1/" target="_blank" title="How to hack facebook account">How to hack facebook account</a></li><li><a href="how-to-change-your-caller-id-1/" target="_self" title="Spoof Call">Spoof Call</a></li><li><a href="how-to-send-sms-with-someone-else-numbers/" target="_self" title="Spoof SMS">Spoof SMS</a></li><li><a href="Send-Mail-with-someone-else-mail-id-1/" target="_self" title="Fake/Spoof mail">Fake/Spoof mail</a></li><li><a href="How-to-kill-wfi-connection-of-entire-network/" target="_self" title="Kill Wifi Of Entire Network">Kill Wifi Of Entire Network</a></li><li><a href="how-to-bypass-applocker-in-andriod-1/" target="_self" title="Bypass Applocker In Android">Bypass Applocker In Android</a></li><li><a href="how-to-run-dual-whatsapp-on-android-without-root-1/" target="_self" title="Dual WhatsApp Without Root">Dual WhatsApp Without Root</a></li><li><a href="how-to-use-whatsapp-on-PC-and-Phone/" target="_self" title="Use WhatsApp on PC and Android Simultaneously">Use WhatsApp on PC and Android Simultaneously</a></li><li><a href="multi-user-android-1/" target="_self" title="Multi User in Android">Multi User in Android</a></li><li><a href="create-an-undeletable-folder/" target="_self" title="Create an Undeletable Folder using CMD">Create an Undeletable Folder using CMD</a></li><li><a href="multi-window-for-android-device/" target="_self" title="Run Multiple Window On Any Android Device">Run Multiple Window On Any Android Device</a></li><li><a href="how-to-share-internet-without-wifi-router-1/" target="_self" title="Share Internet without Wifi Router">Share Internet without Wifi Router</a></li><li><a href="how-to-increase-ram-in-android-device-1/" target="_self" title="Increase Swap Space In Android">Increase Swap Space In Android</a></li><li><a href="how-to-increase-internal-storage-of-android-device-1/" target="_self" title="Increase Internal Storage in Android">Increase Internal Storage in Android</a></li><li><a href="list-of-top-cydia-tweaks-for-ios-1/" target="_self" title="Cydia Tweaks For iOS">Cydia Tweaks For iOS</a></li><li><a href="how-to-optimize-your-download-speed-1/" target="_self" title="Optimize Download Speed of IDM">Optimize Download Speed of IDM</a></li><li><a href="how-to-download-torrent-files-via-IDM-1/" target="_self" title="Download Torrent File Using IDM">Download Torrent File Using IDM</a></li><li><a href="How-to-bypass-phone-sms-verfication-of-any-website-1/" target="_self" title="Bypass Phone and Sms Verfication of Any Website">Bypass Phone and Sms Verfication of Any Website</a></li><li><a href="how-to-check-caller-id-on-windows-PC/" target="_self" title="Windows Tricks">Windows Tricks</a></li><li><a href="how-to-trace-ip-address/" target="_self" title="Trace IP Address of Victim">Trace IP Address of Victim</a></li><li><a href="how-to-install-kali-linux-nethunter-in-android-device-1/" target="_self" title="Kali Linux Nethunter for Android Device">Kali Linux Nethunter for Android Device</a></li><li><a href="how-to-install-android-lollipop-1/" target="_self" title="Install Android Lollipop">Install Android Lollipop</a></li><li><a href="how-to-install-kali-linux-on-android-device-1/" target="_self" title="Install Kali Linux on Android Device">Install Kali Linux on Android Device</a></li><li><a href="how-to-install-windows-xp-on-android-device-1/" target="_self" title="Install Windows in Android Device">Install Windows in Android Device</a></li><li><a href="how-to-download-entire-youtube-playlist-via-idm-1/" target="_self" title="Download Youtube Playlist Via IDM">Download Youtube Playlist Via IDM</a></li><li><a href="how-to-use-your-anndroid-device-as-webcam-1/" target="_self" title="Use Android Device As WebCam">Use Android Device As WebCam</a></li><li><a href="Firefox-addons-for-pentesting-1/" target="_self" title="Firefox Addons For Pentest">Firefox Addons For Pentest</a></li><li><a href="basic-windows-command-1/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick-1/" target="_self" title="Notepad Tricks">Notepad Tricks</a></li><li><a href="how-to-lock-unlock-your-PC-via-usb-1/" target="_self" title="Lock &amp; Unlock Windows PC with USB ">Lock &amp; Unlock Windows PC with USB </a></li><li><a href="how-to-solve-software-problem-of-usb-drive-1/" target="_self" title="Restore Usb Drive Back to Full Capacity">Restore Usb Drive Back to Full Capacity</a></li><li><a href="how-o-send-messages-on-facebook-when-blocked-1/" target="_self" title="Send Messages on Facebook When Blocked">Send Messages on Facebook When Blocked</a></li><li><a href="how-to-download-apk-files-on-your-pc-from-playstore/" target="_self" title="Download Apk Files Via Browser">Download Apk Files Via Browser</a></li><li><a href="how-to-use-your-pc-internet-on-your-android-device-via-usb-1/" target="_self" title="Share PC Internet with Android Device via USB">Share PC Internet with Android Device via USB</a></li><li><a href="how-to-delete-files-permanently-from-your-pc-via-cmd-1/" target="_self" title="Delete Files Permanently Using CMD">Delete Files Permanently Using CMD</a></li><li><a href="How-to-run-linux-in-windows/" target="_self" title="How to run linux in windows.">How to run linux in windows.</a></li></ul></div><div id="wb_element_instance16" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Ethical hacking</strong> <strong>: </strong>which encompasses formal and methodical penetration testing, white hat hacking, and vulnerability testing — involves the same tools, tricks, and techniques that criminal hackers use, but with one major difference: Ethical hacking is performed with the target’s permission in a professional setting.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">The intent of ethical hacking is to discover vulnerabilities from a malicious attacker’s viewpoint to better secure systems. Ethical hacking is part of an overall information risk management program that allows for ongoing security improvements. Ethical hacking can also ensure that vendors’ claims about the security of their products are legitimate.</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Hackers</strong>: A type of person interested in exploration,usually of a computer.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Hack</strong> (v): Cut with rough or heavy and blows. Eg:Hack of the dead branches</span><span style="font-size: 20px;">.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">In other words,manage or cope .Lots of people leave because they can't hack it.</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><br><strong>List Of Some Notable Hackers</strong>:<br><strong>Kevin Mitnick</strong>: Known worldwide as the “most famous hacker” and for having been the first to serve a prison sentence for infiltrating computer systems. He started dabbling when he was a minor, using the practice known as phone phreaking. Although he has never worked in programming, Mitnick is totally convinced that you can cause severe damage with a telephone and some calls. These days, totally distanced from his old hobbies and after passing many years behind bars, he works as a security consultant for multinational companies through his company “Mitnick Security.”</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>Gary McKinnon</strong>: This 41-year-old Scotsman, also known as Solo, is the perpetrator of what’s considered the biggest hack in the history of computer science – into a military system. Not satisfied with this, in the years 2001 and 2002, he made a mockery of the information security of NASA itself and the Pentagon. Currently he is at liberty awarding his extradition to the U.S. and prohibited access to a computer with Internet connection.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>Vladimir Levin</strong>: This Russian biochemist and mathematician was accused of having committed one of the biggest bank robberies of all times by means of the cracking technique. From Saint Petersburg, Levin managed to transfer funds estimated at approximately 10 million dollars from Citibank in New York to accounts he had opened in distant parts of the world. He was arrested by INTERPOL in 1995 at Heathrow airport (England). Although he managed to rob more than 10 million dollars, he was only sentenced to three years in prison. Currently he is free.<br><br><strong>Kevin Poulsen</strong>: Today he may be a journalist and collaborates with authorities to track paedophiles on the Internet, but Poulsen has a dark past as a cracker and phreaker. The event that brought him the most notoriety was taking over Los Angeles phone lines in 1990. A radio station was offering a Porsche as a prize for whoever managed to be caller number 102. It goes without saying that Poulsen was the winner of the contest.<br><br><strong>Timothy Lloyd</strong>:In 1996, information services company Omega, provider of NASA and the United States Navy, suffered losses of around 10 million dollars. And it was none other than Tim Lloyd, an x-employee fired some weeks earlier, who was the cause of this financial disaster. Lloyd left a virtually activated information bomb in the company’s codes, which finally detonated July 31 of that same year.<br><br><strong>Robert Morris</strong>: Son of one of the forerunners in the creation of the virus, in 1988 Morris managed to infect no fewer than 6,000 computers connected to the ArpaNet network (one of the precursors to the internet) He did it from the prestigious Massachusetts Institute of Technology (MIT) and for his criminal activities he earned a four year prison sentence, which was finally reduced to community service.<br><br><strong>David Smith</strong>: Not all hackers can boast of creating the virus that spread the fastest to computers the width and breadth of the globe – David Smith can. In 1999, the father of the Melissa virus managed to infect and crash 100,000 email accounts with his malicious creation. Smith, who was thirty years old at the time, was sentenced and freed on bail.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>MafiaBoy</strong>: In February of 2000, many of the most important online companies in the US, such as eBay, Yahoo and Amazon, suffered a technical glitch called Denial of Service, which caused a total of 1700 million dollars in losses. But did these sites know that the perpetrator of the attack was a 16 year-old Canadian who responded to the alias MafiaBoy? Surely not, although it didn’t take them long to find out, thanks to his bragging about his bad deed to his classmates at school.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>Masters of Deception (MoD)</strong>: MoD was a New York cyber-gang that reached its apogee in the early 90s. Under the cover of different aliases, its biggest attacks involved taking over telephone lines and centres of the Internet, then still in its infancy. During this time McD starred in the historic “battles of the hackers,” along with other groups like the Legion of Doom (LoD), as they sought to destroy each other until the computers couldn’t take it anymore.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>Richard Stallman</strong>: Since the early 80s when he was a hacker specializing in artificial intelligence, this hippie-looking New Yorker has been one of the most active militants in favor of free software. At MIT he firmly opposed the privatization of the software used by the institute’s laboratory, so much so they he created what today is known as GNU and the concept of CopyLeft. Popular systems like Linux utilize the GNU mode and Stallman is currently one of the gurus of software democratization.<br><br><strong>List of some Hacker Groups</strong>:<br><strong>1984 network liberty alliance</strong>:is a loose group of software programmers, artists, social activists and militants, interested in computers and networks and considering them tools to empower and link the various actors of the social movement around the world.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>Anonymous</strong>: originated in 2003 ,is a loosely associated international network of activist and hacktivist entities. A website nominally associated with the group describes it as "an internet gathering" with "a very loose and decentralized command structure that operates on ideas rather than directives".[2] The group became known for a series of well-publicized publicity stunts and distributed denial-of-service (DDoS) attacks on government, religious, and corporate websites.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>Chaos Computer Club</strong>: is based in Germany and other German-speaking countries. Famous among older hackers.<br>
Cult of the Dead Cow: also known as cDc or cDc Communications, is a computer hacker and DIY media organization founded in 1984 inLubbock, Texas. The group maintains a weblog on its site, also titled "Cult of the Dead Cow". New media are released first through the blog, which also features thoughts and opinions of the group's members.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>Decocidio</strong>: is an anonymous, autonomous collective of hacktivists which is part of Earth First!,a radical environmental protest organisation, and adheres to Climate Justice Action. In their hacks the group shows affiliation with the autonomous Hackbloc collective.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>Jester</strong>: is a computer vigilante who describes himself as grey hat hacktivist. He claims to be responsible for attacks on WikiLeaks, 4chan, Iranian President Mahmoud Ahmadinejad, and Islamist websites. He claims to be acting out of American patriotism. The Jester uses a denial-of-service (DoS) tool known as "XerXeS", that he claims to have developed.One of The Jester's habits is to tweet "TANGO DOWN" on Twitter whenever he successfully takes down a website.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>LulzSec</strong>:  a black hat computer hacker group that claimed responsibility for several high profile attacks, including the compromise of user accounts from Sony Pictures in 2011. The group also claimed responsibility for taking the CIA website offline. Some security professionals have commented that LulzSec has drawn attention to insecure systems and the dangers of password reuse. It has gained attention due to its high profile targets and the sarcastic messages it has posted in the aftermath of its attacks. One of the founders of LulzSec was a computer security specialist who used the online moniker Sabu. The man accused of being Sabu has helped law enforcement track down other members of the organization as part of a plea deal. At least four associates of LulzSec were arrested in March 2012 as part of this investigation. British authorities had previously announced the arrests of two teenagers they allege are LulzSec members T-flow and Topiary.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>milw0rm</strong>: is a group of "hacktivists best known for penetrating the computers of the Bhabha Atomic Research Centre (BARC) in Mumbai, the primary nuclear research facility of India, on June 3, 1998.The group conducted hacks for political reasons, including the largest mass hack up to that time, inserting an anti-nuclear weapons agenda and peace message on its hacked websites. The group's logo featured the slogan "Putting the power back in the hands of the people.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><strong>Telecomix</strong>: is a decentralized cluster of net activists, committed to the freedom of expression. Telecomix is a name used by both WeRebuild and Telecomix. WeRebuild is a collaborative project used to propose and discuss laws as well as to collect information about politics and politicians. The Telecomix is the operative body that executes schemes and proposals presented by the WeRebuild. On September 15, 2011, Telecomix diverted all connections to the Syrian web, and redirected internauts to a page with instructions to bypass censorship.<br>
 </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">If u have any queries...or want any other info , then join our <a data-target="true" data-type="url" data-url="https://www.facebook.com/groups/1562639250623631/" href="https://www.facebook.com/groups/1562639250623631/" target="_blank">facebook</a> group Or inbox me your question.</p>
</div><div id="wb_element_instance17" class="wb_element"><script id="airpushScript" type="text/javascript" src="//ab.airpush.com/apportal/client/airpush.js?siteid=263411&amp;testmode=0&amp;banner360=1&amp;banner=slot1&amp;placementid=0&amp;tp=0">
</script></div><div id="wb_element_instance18" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(2);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance18");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance18").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance13" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance14" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance15" class="wb_element"><div id="wb_element_instance15_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance15_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance15_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance15_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance15_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance15_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance15_toolbox"); }
			</script></div><div id="wb_element_instance19" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>