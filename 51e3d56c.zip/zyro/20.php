<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Fingerprint hacked</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link href="css/20.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance1228" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance1229" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance1233" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">Hacker Clones German Defense Minister's Fingerprint Using Just her Photos</h1>

<p class="wb-stl-normal"><br>
Hackers have already bypassed Apple's fingerprint scanner using fake fingerprints, and now they have found a way to reproduce your fingerprints by using just a couple of photos of your fingers.<br>
Special Fingerprint sensors have already been used by Apple and Samsung in their smartphones for authentication purposes and in near future fingerprints sensors are believed to be the part of plenty of other locked devices that can be unlocked using fingerprints, just to add an extra layer of authentication. But, How secure are your fingerprints?</p>

<p class="wb-stl-normal"><br>
A member of Europe's oldest hacker collective, the Chaos Computer Club (CCC), claimed to have cloned a fingerprint of a Germany's federal minister of defense, Ursula von der Leyen, using pictures taken with a "standard photo camera" at a news conference.<br>
At the 31st annual Chaos Computer Conference in Hamburg Germany this weekend, biometrics researcher Starbug, whose real name is Jan Krissler, explained that he used a close-up photo of Ms von der Leyen's thumb that was taken with a "standard photo camera" at a presentation in October -- standing nine feet (3 meters) away from the official. He also used several other pictures of her thumb taken at different angles.<br>
Starbug then used a publicly available software program called VeriFinger with photos of the finger taken from different angles to recreate an accurate thumbprint. According to CCC, this software is good enough to fool fingerprint security systems.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">"After this talk, politicians will presumably wear gloves when talking in public," Starbug told the audience at the Chaos Computer Conference (CCC) conference.<br>
However, this is not the very first time when Chao Computer Club has targeted fingerprints. In past, the group has demonstrated how easily the Apple iPhone 5s can be unlocked using a fake fingerprint obtained from an individual who has touched a shiny surface, such as glass or a smartphone screen.<br>
"This demonstrates—again—that fingerprint biometrics is unsuitable as [an] access control method and should be avoided," the group said at the time.<br>
Moreover, just three days after the launch of the Galaxy S5, hackers successfully managed to hack Galaxy S5 Fingerprint sensor using a similar method that was used to spoof the Touch ID sensor on the iPhone 5S.<br>
But this recent hack did not require any object 'carrying the fingerprints anymore,' which means that any person could potentially steal someone's fingerprint identity from photos posed on Facebook, Twitter or any social networking site.</p>

<p class="wb-stl-normal"><br>
This new finding by Starbug potentially calls into question the effectiveness of fingerprint scanners as a security measure. Fingerprints have been supported in the past as biometric identifiers, but because it can be easily reproduced, using fingerprints for security purposes raises questions.<br>
The practical danger is low, because even after obtaining your fingerprint, the data thieves would still need to have your devices or otherwise find a way to sign in using your biometric information. But, the concern is more as the method require no technical skill to perform the fingerprint cloning.</p>

<p class="wb-stl-normal"><br>
 </p>
</div><div id="wb_element_instance1234" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(20);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance1234");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance1234").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance1230" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance1231" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance1232" class="wb_element"><div id="wb_element_instance1232_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance1232_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance1232_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1232_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1232_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1232_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance1232_toolbox"); }
			</script></div><div id="wb_element_instance1235" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>