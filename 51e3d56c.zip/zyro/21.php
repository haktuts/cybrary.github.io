<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>sony</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link href="css/21.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance1236" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance1237" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance1241" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">Hacker Group Lizard Squad Takes Down Sony's PlayStation</h1>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">A 22-year-old man linked to the notorious hacking group, Lizard Squad, that claimed responsibility for knocking Sony’s PlayStation Network and Microsoft’s Xbox Live offline on Christmas Day was arrested by the United Kingdom police on Monday.<br>
Lizard Squad launched simultaneous Distributed Denial-of-Service (DDoS) attacks against the largest online gaming networks, Xbox Live and PlayStation Network, on Dec. 25. Then offered to sell its own Lizard-branded DDoS-for-hire tool called Lizard Stresser.<br>
Vinnie Omari, an alleged member of Lizard Squad, arrested by the police investigating PayPal thefts and cyber-fraud offences occurred in 2013-14 while raiding his London home. Law enforcement officials reportedly seized phones, laptops and an Xbox from his home.<br><br>
Omari, who is a student of network security and ethical hacking, provided a copy of the search warrant to the Daily Dot, but the details have not been confirmed with local police yet. The press release from the Thames Valley Police Department confirms that Omari was arrested "on suspicion of fraud by false representation and Computer Misuse Act offences [sic]."<br><br><br>
The Federal Bureau of Investigation (FBI) is also reportedly investigating another Lizard Squad member named Julius “Ryan” Kivimaki a 17-year-old teenager, for his connection to the alleged DDoS attacks against Xbox Live and PlayStation Network. He was arrested by Finnish authorities later this week.<br>
In the past few months, Lizard Squad hackers group has come up as an infamous hacking organisation by claiming responsibility for some high-profile DDoS attacks against the popular gaming networks, including EA games, Destiny and Xbox Live. DDoS attacks overwhelm a network with too much of bogus web traffic, making targeted networks inaccessible for legitimate users.<br><br>
On Christmas Day, Lizard Squad did exactly same to PlayStation Network and Xbox Live which caused extended outages for millions of gamers all around the world. The group only stopped its attacks after MegaUpload founder Kim Dotcom gave the group 3,000 vouchers for his uploading service.<br>
Omari denies to have any part in the attack on Sony and Microsoft, and said he is simply a spokesman for Lizard Squad.<br>
Omari was released from the jail on bail on Tuesday, and thus far, he said, no charges have been filed against him, "just alleged charges." He added that he'll "know more when the forensics team gets info." He refused to provide further details about the alleged 2013 crimes.<br>
"Ryan" recently appeared on Sky News, openly claiming that he was a member of Lizard Squad. Unlike Omari, Ryan will remain in jail.<br>
 </p>
</div><div id="wb_element_instance1242" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(21);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance1242");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance1242").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance1238" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance1239" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance1240" class="wb_element"><div id="wb_element_instance1240_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance1240_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance1240_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1240_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1240_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1240_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance1240_toolbox"); }
			</script></div><div id="wb_element_instance1243" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>