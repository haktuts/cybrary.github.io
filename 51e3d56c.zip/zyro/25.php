<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>32 sites</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link href="css/25.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance1268" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance1269" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance1273" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">India blocks 32 websites, including GitHub, Vimeo......</h1>

<p class="wb-stl-normal"><br>
China is known as the nation of 'global internet censorship', and the country proved it many times, in fact when recently it blocked the access to Gmail from the country. Now, it seems that its northern neighbouring country, India doesn't want to get left behind.</p>

<p class="wb-stl-normal"><br>
On Wednesday, the Indian Computer Emergency Response Team issued the ban, asking internet service providers and mobile operators to block access to dozens of popular websites in the name of its censorship laws, according to a government advisory made public by Pranesh Prakash, director of the Centre for Internet and Society in Bangalore.</p>

<p class="wb-stl-normal"><br>
As many as 32 websites including GitHub, PasteBin, Vimeo, Imgur, DailyMotion, Internet Archive have reportedly been banned in India under an order from the Department of Telecom (DoT).<br>
Vodafone, the second largest mobile network operator in India (after Airtel) with an estimated 173 million customers and BSNL, Indian state-owned telecom operator with 117 million customers, have already blocked access to the above mentioned websites. However, other telecom operators and ISPs are still providing access to those websites.</p>

<p class="wb-stl-normal"><br>
The Indian government has accused the websites for hosting anti-India material content posted by the members of a terrorist organization called Islamic State group, also known as ISIS.<br><br>
The notice sent to all Internet Service Licensees mentions the Section 69A of the IT Act, 2000, which states "Power to issue directions for blocking for public access of any information through any computer resource." Based on which the DoT have decided to immediately block the access to 32 websites.<br>
Prakash posted a copy of the notice listing the 32 blocked URLs. The URLs listed include:<br>
justpaste.it<br>
hastebin.com<br>
codepad.org<br>
freehosting.com<br>
vimeo.com<br>
dailymotion.com<br>
pastebin.com<br>
gist.github.com<br>
archive.org<br>
ipaste.eu<br>
github.com (gist-it)<br>
pastie.org<br>
pastee.org<br>
paste2.org<br>
thesnippetapp.com<br>
snipt.net<br>
tny.cz (Tinypaste)<br>
slexy.org<br>
paste4btc.com<br>
0bin.net<br>
heypasteit.com<br>
sourceforge.net/projects/phorkie<br>
atnsoft.com/textpaster<br>
hpage.com<br>
ipage.com<br>
webs.com<br>
weebly.com<br>
000webhost.com<br>
snipplr.com<br>
termbin.com<br>
snippetsource.net<br>
cryptbin.com</p>

<p class="wb-stl-normal"><br>
One of the blocked sites, Pastebin.com tweeted that its url was blocked in India. "We are getting many reports about this. The Indian government has blocked us, and right now there is little we can do about it. It has happened in the past, and we got unblocked after some time. For now we recommend using a free proxy service if you are based in India," it said in a Facebook post.<br>
However, the contents of the list is particularly embarrassing for Prime Minister Narendra Modi as well, who recently unveiled a "Make In India" campaign earlier this year in an attempt to encourage international businesses to invest in India, which also includes information technology sector. And blocking websites like GitHub is the most definitely not in sync with that vision.<br>
 </p>
</div><div id="wb_element_instance1274" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(25);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance1274");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance1274").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance1270" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance1271" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance1272" class="wb_element"><div id="wb_element_instance1272_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance1272_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance1272_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1272_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1272_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1272_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance1272_toolbox"); }
			</script></div><div id="wb_element_instance1275" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>