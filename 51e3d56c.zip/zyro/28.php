<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>top 2014</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link href="css/28.css?ts=1425383881" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance1292" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance1293" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance1297" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal">Top Worst Cyber Attacks of 2014<br><br>
Cyber attacks have become more sophisticated and elaborate, raising global concern over time. Of course, in the year of 2014 there has been an alarming number of hacking incidents and attacks targeting both individuals and organizations.<br>
Now that we have reached the end of the year and we are about to welcome the bright and shiny 2015, it is high time we referred to the top incidents that have drawn our attention. This report should function towards gaining the proper knowledge that will help us in the near future to avoid the same or similar problems.<br>
Although technology is progressing exponentially and this is great, the same applies to the knowledge and skills of hackers everywhere. So, only by being vigilant and up to date can we expect to develop the right defensive line against attacks and hacking attempts. Let’s start recalling the top incidents that have made it to shake the waters of the technology industry!<br><br>
    <strong>Shellshock</strong>: This threat emerged in September and has been alternatively known as Bashdoor. The irony behind the Shellshock bug is that it had remained dormant for twenty years before being brought to light. Within just hours after its discovery, DDoS attacks have been triggered with the contribution of this bug. For some, the Shellshock incident has been even more intense than the Heartbleed bug that took place earlier in 2014.<br>
 <br>
   <strong> Heartbleed</strong>: The Heartbleed bug has been a severe vulnerability discovered in the OpenSSL protocol. Apparently, due to the vulnerability that emerged, the cryptographic function of the OpenSSL could not be performed. Without the encryption throughout the Internet traffic, communication can be leaked and data can be intercepted. This is what happened, causing frenzy online back in April and motivating all sites to request changing passwords and taking additional precautions.<br>
 <br>
    <strong>eBay Attack</strong>: 233 million users were stripped off their personal information, according to reports. Between February and March, hackers were able to gain access to usernames and passwords, phone numbers and addresses. This is perhaps the most gigantic data interception of 2014. Payment data has been left intact, but everyone was encouraged to alter all passwords immediately.<br>
 <br>
    <strong>Home Depot</strong>: The company admitted having suffered from a huge cyber attack in a statement published on 18th September, 2014. Unfortunately, 56 million credit and debit cards have been compromised due to this cyber attack. On the bright side, no PIN numbers were affected and therefore no monetary damage was completed to the holders of the cards.<br>
 <br>
    <strong>Yahoo Email</strong>: In January, the email service provider admitted having been under attack with a blog post published. Though there is no actual number of how many email accounts have been compromised, it is worth considering that Yahoo is the second most popular email service option universally (right after Gmail). It is estimated that about 273 million people have got a Yahoo email account – so, you do the Math!<br>
 <br>
    <strong>Gmail</strong>: Just to set things straight and even the score, Gmail has had 5 million usernames and passwords leaked in a Russian forum in September. In a statement, Gmail reassured the email account owners not to worry and informed of the advanced anti-hijacking service that is available for protecting login attempts from third parties. Still, the concern was grave and the lists were indeed leaked.<br>
 <br>
    <strong>Apple iCloud in China</strong>: This is not the first time the Great Firewall acted against products and services from the US. MITM (Man-In-The-Middle) attack was launched on Apple’s iCloud and confirmed by GreatFire.org. The Chinese Government is truly strict and does not allow companies to provide innovative technological alternatives to people in China, limiting in this way the liberty they enjoy.<br>
 <br>
    <strong>JP Morgan Chase</strong>: Another serious cyber attack was held on JP Morgan Chase during the summer of 2014. According to the reports, about 80 million households and their accounts have been compromised. You can imagine the range of information that has been leaked, including names and addresses.<br>
 <br>
    <strong>4chan Photo Scandal</strong>: Starting in August, hundreds of nude photos including celebrities were published online under the banner of Fappening. The photos were obtained via Apple iCloud and there have been severe reactions by the celebrities and people who oppose to the lack of privacy. The scandal is also known as the “Celebgate” and the “Fappening”.<br>
 <br>
    <strong>Sony PlayStation</strong>: One of the most significant DDoS cyber attacks launched in 2014 was that of the group called Lizard Squad against Sony PlayStation. The company announced that no user data has been compromised, but the distress was evident as to what has triggered the attack and the extent of the damage.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">   <strong>Staples Store Breach</strong>: The world’s largest office supply chain store Staples faced massive breach where personal details including names, credited card details of its 1.16 million customers were stolen.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">   <strong>Anonymous vs. Ku Klux Klan (KKK)</strong>: Anonymous leaked credit card details along with home address of racist white Christian Supremacist group KKK. The leak was done against KKK’s interference in Operation Ferguson.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>
</div><div id="wb_element_instance1298" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(28);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance1298");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance1298").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance1294" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance1295" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance1296" class="wb_element"><div id="wb_element_instance1296_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance1296_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance1296_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1296_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1296_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1296_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance1296_toolbox"); }
			</script></div><div id="wb_element_instance1299" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>