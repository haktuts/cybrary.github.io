<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Tips and Trick</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="1. Download youtube multidownloader
   2. goto the channel tab                          
   3. provide name of youtube channel,

Sometime we face some problem while downloading from torrent like more leeachers,less  bandwidth and less speed while downloding from internet.
 some steps to download torrent file from idm" />
	<meta name="keywords" content="STEPS TO INSTALL DUAL WHATSAPP IN YOUR ANDROID WITHOUT ROOT,How to increase the swap space in android device,How to increase the internal storage in android" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383877" rel="stylesheet" type="text/css" />
	<link href="css/3.css?ts=1425383877" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance20" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li class="active"><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance21" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance25" class="wb_element"><a class="wb_button" href="Tips-and-trck-2/"><span>2&gt;</span></a></div><div id="wb_element_instance26" class="wb_element"><a class="wb_button" href="Tips-and-tricks/"><span>&lt;1</span></a></div><div id="wb_element_instance27" class="wb_element"><a href="how-to-run-dual-whatsapp-on-android-without-root/" target="1"><img alt="" src="gallery/321a4d2cec5bc6953e042c727e16788c_300x220.jpg"></a></div><div id="wb_element_instance28" class="wb_element"><a href="how-to-increase-ram-in-android-device/" target="1"><img alt="" src="gallery/02cd56d9a1eb59eb4d5e8293d7ad1ef8_300x220.jpg"></a></div><div id="wb_element_instance29" class="wb_element"><a href="how-to-increase-internal-storage-of-android-device/" target="1"><img alt="" src="gallery/02659e2492230faaf0a1b602f2b60986_300x220.jpg"></a></div><div id="wb_element_instance30" class="wb_element"><a href="Shutdown-PC-via-Phone/" target="1"><img alt="" src="gallery/1a3b650beb29aa72839d932f06029044_300x220.jpg"></a></div><div id="wb_element_instance31" class="wb_element"><a href="how-to-download-torrent-files-via-IDM/" target="1"><img alt="" src="gallery/ee61f5e9689c461ff9c80590f0c1254b_300x220.jpg"></a></div><div id="wb_element_instance32" class="wb_element"><a href="how-to-optimize-your-download-speed/" target="1"><img alt="" src="gallery/0df25a08d001288d074388fee8b60b18_300x220.jpg"></a></div><div id="wb_element_instance33" class="wb_element"><a href="How-to-bypass-phone-sms-verfication-of-any-website/" target="1"><img alt="" src="gallery/d55090928e4ae57cf532ddbd1f6abfeb_300x220.jpg"></a></div><div id="wb_element_instance34" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-special"><span style="color:#bebebe;">Steps To Install Dual Whatsapp In </span></span></p>

<p><span class="wb-stl-special"><span style="color:#bebebe;">Your Android Without Root.</span></span></p>

<p><a href="how-to-run-dual-whatsapp-on-android-without-root/" target="_blank"><span style="color:#bebebe;"><u><span class="wb-stl-special">Read More</span></u></span></a></p>
</div><div id="wb_element_instance35" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-special">How To Increase the Swap Space in Android Device?</span></p>

<p><a href="how-to-increase-ram-in-android-device/" target="_blank"><span class="wb-stl-special"><u><span style="color:#bebebe;">Read More</span></u></span></a></p>
</div><div id="wb_element_instance36" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-special">How to increase the internal storage in android??</span></p>

<p><a href="how-to-increase-internal-storage-of-android-device/" target="_blank"><span class="wb-stl-special"><u><span style="color:#bebebe;">Read More</span></u></span></a></p>
</div><div id="wb_element_instance37" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-special">How To Shutdown A Computer With A Cell Phone.</span></p>

<p><a href="Shutdown-PC-via-Phone/" target="_blank"><span class="wb-stl-special"><u><span style="color:#bebebe;">Read More</span></u></span></a></p>
</div><div id="wb_element_instance38" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-special">How to download torrent file to using IDM.</span></p>

<p><a href="how-to-download-torrent-files-via-IDM/" target="_blank"><span class="wb-stl-special"><u><span style="color:#bebebe;">Read More</span></u></span></a></p>
</div><div id="wb_element_instance39" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-special">How to Optimize the download speed of IDM.</span></p>

<p><a href="how-to-optimize-your-download-speed/" target="_blank"><span class="wb-stl-special"><u><span style="color:#bebebe;">Read More</span></u></span></a></p>
</div><div id="wb_element_instance40" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-special">How to Bypass Phone and SMS verification of Any Website.</span></p>

<p><a href="How-to-bypass-phone-sms-verfication-of-any-website/" target="_blank"><span class="wb-stl-special"><u><span style="color:#bebebe;">Read More</span></u></span></a></p>
</div><div id="wb_element_instance41" class="wb_element"><a href="Ethical-hacking/"><img alt="" src="gallery/e8667218f9509bf1ae3b5034b14a141e_250x260.jpeg"></a></div><div id="wb_element_instance42" class="wb_element"><a class="wb_button" href="http://www.cybrary.it"><span>free ethical hacking course online</span></a></div><div id="wb_element_instance43" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(3);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance43");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance43").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance22" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance23" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance24" class="wb_element"><div id="wb_element_instance24_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance24_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance24_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance24_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance24_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance24_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance24_toolbox"); }
			</script></div><div id="wb_element_instance44" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>