<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Hackers Keyword</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="RAT :Remote administration tool
DDOS: Distributed denial of service
FUD: Fully undetectable
SQL: Structured query language
XSS: Cross site scripting
Skid: Script kiddie
Malware: Malicious software
SSH : Secure shell
VPN : Virtual private network
VPS: Virtual private service" />
	<meta name="keywords" content="Hackers Keywords,Hacking Terms" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/47.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance135" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance136" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance140" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">Hackers Keywords</span></h1>

<p><br><span style="color:#bebebe;"><strong>RAT</strong> :Remote administration tool<br><strong>DDOS</strong>: Distributed denial of service<br><strong>FUD</strong>: Fully undetectable<br><strong>SQL</strong>: Structured query language<br><strong>XSS</strong>: Cross site scripting<br><strong>Skid</strong>: Script kiddie<br><strong>Malware</strong>: Malicious software<br><strong>SSH</strong> : Secure shell<br><strong>VPN</strong> : Virtual private network<br><strong>VPS</strong>: Virtual private service</span></p>

<p><span style="color:#bebebe;">For more Detail:</span></p>

<p><span style="color:#bebebe;"><strong>http://www.textfiles.com/magazines/PHANTASY/iirg-acronyms-v12.txt</strong></span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Hacking Terms</span></h1>

<p><br><span style="color:#bebebe;">•<strong>Hackers Dictionary</strong></span></p>

<p><span style="color:#bebebe;">•If you are a newbie in hacking then you need to learn some things. There are some terms that every hacker should know about them.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Algorithm</strong> - A series of steps specifying which actions to take in which order.</span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>ANSI Bomb</strong> - ANSI.SYS key-remapping commands consist of cryptic-looking text that specifies, using ansi numeric codes to redefine keys.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>Back Door</strong> - Something a hacker leaves behind on a system in order to be able to get back in at a later time.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>Binary</strong> - A numbering system in which there are only two possible values for each digit: 0 and 1.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•<strong>Black Hat</strong> - A hacker who performs illegal actions to do with hacking online. (Bad guy, per se)</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>Blue Hat</strong> - A blue hat hacker is someone outside computer security consulting firms who is used to bug test a system prior to its launch, looking for exploits so they can be closed. Microsoft also uses the term BlueHat to represent a series of security briefing events.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>Bot</strong> - A piece of malware that connects computer to an attacker commonly using the HTTP or IRC protocal to await malicous instructions.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>Botnet</strong> - Computers infected by worms or Trojans and taken over by hackers and brought into networks to send spam, more viruses, or launch denial of service attacks.</span></span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Buffer Overflow </strong>- A classic exploit that sends more data than a programmer expects to receive. Buffer overflows are one of the most common programming errors, and the ones most likely to slip through quality assurance testing.</span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>Cracker</strong> - A specific type of hacker who decrypts passwords or breaks software copy protection schemes.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>DDoS</strong> - Distributed denial of service. Flooding someones connection with packets. Servers or web-hosted shells can send packets to a connection on a website usually from a booter.</span></span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Deface</strong> - A website deface is an attack on a site that changes the appearance of the site or a certain webpage on the site.</span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>Dictionary Attack </strong>- A dictionary attack is an attack in which a cyber criminal can attempt to gain your account password. The attack uses a dictionary file, a simple list of possible passwords, and a program which fills them in. The program just fills in every single possible password on the list, untill it has found the correct one. Dictionary files usually contain the most common used passwords.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>DOX</strong> - Personal information about someone on the Internet usualy contains real name, address, phone number, SSN, credit card number, etc.</span></span></p>

<p><span style="color:#bebebe;">•&gt;<strong>E-Whore</strong> - A person who manipulates other people to believe that he/she is a beautiful girl doing cam shows or selling sexual pictures to make money.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Encryption</strong> - In cryptography, encryption applies mathematical operations to data in order to render it incomprehensible. The only way to read the data is apply the reverse mathematical operations. In technical speak, encryption is applies mathematical algorithms with a key that converts plaintext to ciphertext. Only someone in possession of the key can decrypt the message.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Exploit</strong> - A way of breaking into a system. An exploit takes advantage of a weakness in a system in order to hack it.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>FUD</strong> - Fully undetectable, can be used in many terms. Generally in combination with crypters, or when trying to infect someone.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Grey Hat</strong> - A grey hat hacker is a combination of a Black Hat and a White Hat Hacker. A Grey Hat Hacker may surf the internet and hack into a computer system for the sole purpose of notifying the administrator that their system has been hacked, for example. Then they may offer to repair their system for a small fee.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Hacker</strong> (definition is widely disputed among people...) - A hacker is someone who is able to manipulate the inner workings of computers, information, and technology to work in his/her favor.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Hacktivist</strong> - A hacktivist is a hacker who utilizes technology to announce a social, ideological, religious, or political message. In general, most hacktivism involves website defacement or denial-of-service attacks.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>IP Address</strong> - On the Internet, your IP address is the unique number that others use to send you traffic.</span></p>

<p><span style="color:#bebebe;">•<strong>IP Grabber</strong> - A link that grabs someone's IP when they visit it.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Keylogger</strong> - A software program that records all keystrokes on a computer's keyboard, used as a surveillance tool or covertly as spyware.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Leach</strong> - A cultural term in the warez community referring to people who download lots of stuff but never give back to the community.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>LOIC/HOIC </strong>- Tool(s) used by many anonymous members to conduct DDoS attacks. It is not recommended to use these under any circumstances.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Malware</strong> - Software designed to do all kinds of evil stuff like stealing identity information, running DDoS attacks, or soliciting money from the slave.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Neophyte</strong> - A neophyte, "n00b", or "newbie" is someone who is new to hacking or phreaking and has almost no knowledge or experience of the <span style="background-color: transparent;">workings of technology, and hacking.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>smith</strong> - Somebody new to a forum/game.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>OldFag</strong> - Somebody who's been around a forum/game for a long time.</span></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">•&gt;<strong>Packet</strong> - Data that is sent across the Internet is broken up into packets, sent individually across the network, and reassembled back into the original data at the other end.</span></span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Phreak</strong> - Phone Freaks. Hackers who hack cell phones for free calling. Free Long distance calling. Etc.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Phreaking</strong> - The art and science of cracking the phone network.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Proxy</strong> - A proxy is something that acts as a server, but when given requests from clients, acts itself as a client to the real servers.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Rainbow Table</strong> - A rainbow table is a table of possible passwords and their hashes. It is way faster to crack a password using rainbow tables then using a dictionary attack (Bruteforce).</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Remote Administration Tool</strong> - A tool which is used to remotely control (an)other machine(s). These can be used for monitoring user actions, but often misused by cyber criminals as malware, to get their hands on valuable information, such as log in credentials.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Resolver</strong> - Software created to get an IP address through IM (instant messenger, like Skype/MSN) programs.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Reverse Engineering</strong> - A technique whereby the hacker attempts to discover secrets about a program. Often used by crackers, and in direct modifications to a process/application.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Root</strong> - Highest permission level on a computer, able to modify anything on the system without restriction.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Rootkit (ring3 ring0) </strong>- A powerful exploit used by malware to conceal all traces that it exists. Ring3 - Can be removed easily without booting in safemode. Ring0 - Very hard to remove and very rare in the wild, these can require you to format, it's very hard to remove certain ring0 rootkits without safemode.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Script Kiddie</strong> - A script kid, or skid is a term used to describe those who use scripts created by others to hack computer systems and websites. Used as an insult, meaning that they know nothing about hacking.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Shell</strong> - The common meaning here is a hacked web server with a DoS script uploaded to conduct DDoS attacks via a booter. OR A shell is an script-executing unit - Something you'd stick somewhere in order to execute commands of your choice.</span></p>

<p><span style="color:#bebebe;">•<strong>Social Engineer</strong> - Social engineering is a form of hacking that targets people's minds rather than their computers. A typical example is sending out snail mail marketing materials with the words "You may already have won" emblazoned across the outside of the letter. As you can see, social engineering is not unique to hackers; it's main practitioners are the marketing departments of corporations.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Spoof</strong> - The word spoof generally means the act of forging your identity. More specifically, it refers to forging the sender's IP address (IP spoofing). (Spoofing an extension for a RAT to change it from .exe to .jpg, etc.)</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>SQL Injection</strong> - An SQL injection is a method often used to hack SQL databases via a website, and gain admin control (sometimes) of the site. You can attack programs with SQLi too.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Trojan</strong> - A Trojan is a type of malware that masquerades as a legitimate file or helpful program with the ultimate purpose of granting a hacker unauthorized access to a computer.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>VPS </strong>- The term is used for emphasizing that the virtual machine, although running in software on the same physical computer as other customers' virtual machines, is in many respects functionallyequivalent to a separate physical computer, is dedicated to the individual customer's needs, has the privacy of a separate physical computer, and can be configured to run server software.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Warez</strong> - Software piracy</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>White Hat</strong> - A "white hat" refers to an ethical hacker, or a computer security expert, who specializes in penetration testing and in other testing methods to ensure the security of a businesses information systems. (Good guy, per se)</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Worm</strong> - Software designed to spread malware with little to no human interaction.</span></p>

<p><span style="color:#bebebe;">•&gt;<strong>Zero Day Exploit</strong> - An attack that exploits a previously unknown vulnerability in a computer application, meaning that the attack occurs on "day zero" of awareness of the vulnerability. This means that the developers have had zero days to address and patch the vulnerability.</span></p>

<p> </p>
</div><div id="wb_element_instance141" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(47);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance141");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance141").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance137" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance138" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance139" class="wb_element"><div id="wb_element_instance139_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance139_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance139_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance139_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance139_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance139_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance139_toolbox"); }
			</script></div><div id="wb_element_instance142" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>