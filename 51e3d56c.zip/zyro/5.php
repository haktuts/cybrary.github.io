<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>News4</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="Google plans to launch its own messaging application similer to whatsapp,the economics times of india reports." />
	<meta name="keywords" content="Google messaging application,FBI Arrested CEO of,StealthGenie,For Selling Mobile spyware application,Delivery drone become reality,Kali linux Nethunter" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383877" rel="stylesheet" type="text/css" />
	<link href="css/5.css?ts=1425383877" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance70" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance71" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance75" class="wb_element"><a href="TOR-not-100-untraceable/" target="1"><img alt="" src="gallery/2e53e97d22aba1b755e0b459e38d0c9c_300x220.jpg"></a></div><div id="wb_element_instance76" class="wb_element"><a href="Google-works-like-NSA/" target="1"><img alt="" src="gallery/99f19e053ceca2e9ab4f7f2a1ba1c0bf_300x220.jpg"></a></div><div id="wb_element_instance77" class="wb_element"><a href="Android-Vulnerable-by-Privelege-Escalation/" target="1"><img alt="" src="gallery/4dc02b5c2a440fe526ed8aabe3c251e0_300x220.jpg"></a></div><div id="wb_element_instance78" class="wb_element"><a href="iOS-Vulnerability-Masque-Attack/" target="1"><img alt="" src="gallery/47daec1f909892f1c05cc47f285225de_300x220.jpg"></a></div><div id="wb_element_instance79" class="wb_element"><a href="WhatsApp-now-secured/" target="1"><img alt="" src="gallery/f90ca8a22674cf8a26e4e128a9652b59_300x220.jpg"></a></div><div id="wb_element_instance80" class="wb_element"><a href="Microsoft-PAtches-19-yrar-old-Vulnerability/" target="1"><img alt="" src="gallery/d995b49e3b7be880a56155c382ee1898_300x220.jpg"></a></div><div id="wb_element_instance81" class="wb_element"><a href="Tor-and-Mozilla-working-Together/" target="1"><img alt="" src="gallery/4f54acb79f105dfc3581a8cc350342ae_300x220.jpg"></a></div><div id="wb_element_instance82" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal"><span class="wb-stl-special">Tor User’s IP Address Can Be </span></p>

<p class="wb-stl-normal"><span class="wb-stl-special">Identified By </span><span style="font-size: 35px;">Exploiting Routers.</span></p>

<p class="wb-stl-normal"><a href="TOR-not-100-untraceable/" target="_blank"><u><span class="wb-stl-special">Read More</span></u></a></p>
</div><div id="wb_element_instance83" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal"><span class="wb-stl-special">Google works Like NSA by collecting, storing, and indexing user data: Assange.</span></p>

<p class="wb-stl-normal"><a href="Google-works-like-NSA/" target="_blank"><u><span class="wb-stl-special">Read More</span></u></a></p>
</div><div id="wb_element_instance84" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-special">ANDROID DEVICES VULNERABLE TO PRIVILEGE ESCALATION.</span></p>

<p class="wb-stl-normal"><a href="Android-Vulnerable-by-Privelege-Escalation/" target="_blank"><u><span class="wb-stl-special">Read More</span></u></a></p>
</div><div id="wb_element_instance85" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal"><span class="wb-stl-special">Masque Attack New iOS Vulnerability.</span></p>

<p class="wb-stl-normal"><a href="iOS-Vulnerability-Masque-Attack/" target="_blank"><u><span class="wb-stl-special">Read More</span></u></a></p>

<div id="cke_pastebin" style="position: absolute; top: -528px; width: 1px; height: 772px; overflow: hidden; margin: 0px; padding: 0px; left: -1000px;"> </div>
</div><div id="wb_element_instance86" class="wb_element" style=" line-height: normal;"><h1 class="title single-title entry-title" itemprop="headline" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; border: 0px; font-family: Roboto; font-size: 25px; font-stretch: inherit; line-height: 1.4; vertical-align: baseline; color: rgb(68, 68, 68); text-transform: uppercase; clear: both; word-wrap: break-word; width: 805.90625px;"><span class="wb-stl-special">WHATSAPP NOW SECURED</span></h1>

<h1 class="title single-title entry-title" itemprop="headline" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; border: 0px; font-family: Roboto; font-size: 25px; font-stretch: inherit; line-height: 1.4; vertical-align: baseline; color: rgb(68, 68, 68); text-transform: uppercase; clear: both; word-wrap: break-word; width: 805.90625px;"><span class="wb-stl-special">WITH ENCRYPTION.</span></h1>

<p><a href="WhatsApp-now-secured/" target="_blank"><span style="color:#bebebe;"><u><span class="wb-stl-special">Read More</span></u></span></a></p>
</div><div id="wb_element_instance87" class="wb_element" style=" line-height: normal;"><p><span class="wb-stl-special">Microsoft Fixes Security flaw in Windows That Existed For 19 Years.</span></p>

<p><a href="Microsoft-PAtches-19-yrar-old-Vulnerability/" target="_blank"><span style="color:#bebebe;"><u><span class="wb-stl-special">Read More</span></u></span></a></p>
</div><div id="wb_element_instance88" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal"><span class="wb-stl-special">MOZILLA AND TOR JOIN FORCES TO IMPROVE ONLINE PRIVACY.</span></p>

<p class="wb-stl-normal"><a href="Tor-and-Mozilla-working-Together/" target="_blank"><u><span class="wb-stl-special">Read More</span></u></a></p>
</div><div id="wb_element_instance89" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(5);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance89");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance89").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance72" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance73" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance74" class="wb_element"><div id="wb_element_instance74_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance74_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance74_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance74_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance74_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance74_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance74_toolbox"); }
			</script></div><div id="wb_element_instance90" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>