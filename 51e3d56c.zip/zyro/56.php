<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Anonymous Surf</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="Method to spoof IP
1.Add-On
2.Proxy
3.VPN
4.TOR (Browser)" />
	<meta name="keywords" content="HOW TO STAY ANAONYMOUS,IP Spoofing,Spoofing via  Browser Add-on,Proxy,VPN,TOR,BROWSER" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/56.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance210" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance211" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance215" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">IP Spoofing</span></h1>

<p> </p>

<p><span style="color:#bebebe;"><strong>Method</strong> to spoof IP</span></p>

<p><span style="color:#bebebe;"><strong>1.Add-On<br>
2.Proxy<br>
3.VPN<br>
4.TOR (Browser)</strong></span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Spoofing via  Browser Add-on</span></h1>

<p> </p>

<p><span style="color:#bebebe;"><strong>Google Chrome</strong>:</span></p>

<p><span style="color:#bebebe;">1.<a data-target="true" data-type="url" data-url="https://chrome.google.com/webstore/detail/hidemyass-free-web-proxy/angedonhhlnfgpihepebcbbnbeeghcgd?hl=en" href="https://chrome.google.com/webstore/detail/hidemyass-free-web-proxy/angedonhhlnfgpihepebcbbnbeeghcgd?hl=en" target="_blank">HideMyAss</a></span></p>

<p><span style="color:#bebebe;">2.<a data-target="true" data-type="url" data-url="https://chrome.google.com/webstore/detail/vpns-http-proxy/deoodoglhbmpafkajmlggnjnngdclnie?hl=en" href="https://chrome.google.com/webstore/detail/vpns-http-proxy/deoodoglhbmpafkajmlggnjnngdclnie?hl=en" target="_blank">VPN.S HTTP Proxy</a></span></p>

<p> </p>

<p><span style="color:#bebebe;"><strong>Opera</strong>:</span></p>

<p><span style="color:#bebebe;">1.<a data-target="true" data-type="url" data-url="http://proxyswitcher.net" href="http://proxyswitcher.net" target="_blank">Proxy Switch Sharp</a></span></p>

<p><span style="color:#bebebe;">2.<a data-target="true" data-type="url" data-url="Webproxy.net" href="Webproxy.net" target="_blank">Webproxy.net</a></span></p>

<p> </p>

<p><span style="color:#bebebe;"><strong>Mozilla Firefox</strong>:</span></p>

<p><span style="color:#bebebe;">1.<a data-target="true" data-type="url" data-url="https://www.anonymox.net/en/download" href="https://www.anonymox.net/en/download" target="_blank">AnonyMoX</a></span></p>

<p> </p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Proxy</span></h1>

<p> </p>

<p><span style="color:#bebebe;"><strong>1.</strong>   A proxy server is a computer on the network between you and the other computers on the Internet. usually, what happens when you connect to a site, your computer sends a request to the server you're trying to receive data from but when you connect to a proxy, you send the request to the proxy, and the proxy sends the data back to you.</span></p>

<p><span style="color:#bebebe;"><strong>2.</strong>    Proxy divided into three types</span></p>

<p><span style="color:#bebebe;">          <strong>Normal proxy:</strong></span></p>

<p><span style="color:#bebebe;"><strong>          Transparent proxy</strong></span></p>

<p><span style="color:#bebebe;"><strong>           Reverse proxy</strong></span></p>

<p> </p>

<p><span style="color:#bebebe;"><strong>Normal Proxy</strong></span></p>

<p><span style="color:#bebebe;">1.Benefit for client.<br>
2.Client side verification required<br>
3.Proxy working in browser.<br>
4.It stores a copy for future use. So next time when another client requests for the same webpage the proxy server just replies to the request with the content in its cache thus improving the overall request-reply speed.</span></p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;"><strong style="background-color: transparent;">Transparent Proxy</strong></span></p>

<p><span style="color:#bebebe;">1.Benefit for client.<br>
2.Client side configuration not required<br>
3.Proxy working in Gateway like port forwarding.<br>
4.It fetches the content for the first time and subsequently replies from its local cache.Eg Torrent</span></p>

<p> </p>

<p><span style="color:#bebebe;"><strong>Reverse Proxy</strong></span></p>

<p><span style="color:#bebebe;">1.Benefit for web server<br>
2.Proxy working in web server <br>
3.It will cache all the static answers from the web server and reply to the clients from its cache to reduce the load on the web server.<br>
4.This type of setup is also known as Web Server Acceleration</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">VPN</span></h1>

<p> </p>

<p><span style="color:#bebebe;">List of VPN which help you to surf web anonymously.</span></p>

<p><span style="color:#bebebe;"><strong>1.<a data-target="true" data-type="url" data-url="https://www.hidemyass.com" href="https://www.hidemyass.com" target="_blank">Hide my ass</a><br>
2.<a data-target="true" data-type="url" data-url="http://www.cyberghostvpn.com/en_us" href="http://www.cyberghostvpn.com/en_us" target="_blank">Cyberghost</a><br>
3.<a data-target="true" data-type="url" data-url="http://www.hotspotshield.com" href="http://www.hotspotshield.com" target="_blank">Hotspot shield</a><br>
4.<a data-target="true" data-type="url" data-url="https://www.steganos.com/us/products/overview/" href="https://www.steganos.com/us/products/overview/" target="_blank">Steganos</a><br>
5.<a data-target="true" data-type="url" data-url="https://www.expressvpn.com" href="https://www.expressvpn.com" target="_blank">Express VPN</a><br>
6.<a data-target="true" data-type="url" data-url="http://www.purevpn.com" href="http://www.purevpn.com" target="_blank">Pure VPN</a><br>
7.<a data-target="true" data-type="url" data-url="https://www.hideman.net" href="https://www.hideman.net" target="_blank">Hideman</a><br>
8.<a data-target="true" data-type="url" data-url="https://www.tunnelbear.com" href="https://www.tunnelbear.com" target="_blank">Tunnel bear</a></strong></span></p>

<p> </p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>TOR (BROWSER)</strong></span></h1>

<p> </p>

<p><br><span style="color:#bebebe;"><strong>•Tor</strong> browser use  volunteer network consisting of more than five thousand relays to conceal a user's location. It is difficult to trace down the user activity on web using tor browser. Most of people use tor browser to open hidden wiki and deep web.</span><br>
 </p>

<p> </p>

<p> </p>
</div><div id="wb_element_instance216" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(56);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance216");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance216").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance212" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance213" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance214" class="wb_element"><div id="wb_element_instance214_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance214_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance214_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance214_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance214_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance214_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance214_toolbox"); }
			</script></div><div id="wb_element_instance217" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>