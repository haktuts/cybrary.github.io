<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Introduction</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/58.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance226" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance227" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance231" class="wb_element" style=" line-height: normal;"><p class="wb-stl-normal">Now a days, lots of attack on website ,network happen like dos attack, SQL injection attack, Cross site scripting attack etc.</p>

<p class="wb-stl-normal">As the crime increase ,requirement of ethical hacker and pentester increase as there is direct relationship between</p>

<p class="wb-stl-normal"> hacker and ethical hacker. There is the need of ethical hacker and pentester in public as well as private organization.</p>

<p class="wb-stl-normal">but training was very expensive so people think twice before spending money ,now the opportunity to learn and do so, at no cost at <a data-type="url" data-url="https://www.cybrary.it" href="https://www.cybrary.it"><span style="color:#f10631;"><strong>https://www.cybrary.it</strong></span></a></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Content of the course</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">1:Phase of pentesting</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">PenTest, like forensics, is almost as much an art as it is a science – you can only be taught so far, technical techniques and tools are all very well, but you really need a mind that can think sideways and approach a task from as many angles as possible</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">2:Footprinting</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Tools and tricks to get the information about the computer,ip and mac address,related user and system.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">3:Scanning</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Before starting the pentesting,pentester must have some information about network and system.so pentester scan the entire network with some tool like nMap,zenmap,ping and hping etc</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">4:Enumeration</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">During the enumeration phase, possible entry points into the tested systems are identified. The information collected during the reconnaissance phase is put to use.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">5:System Hacking</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">System hacking login to system without credentials not only bypass the credentials but also you can work in system as root user by privilege escalation.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">6:Trojans</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">It is a generally non-self-replicating type of malware program containing malicious code.A Trojan often acts as a backdoor, contacting a controller which can then have unauthorized access to the affected computer.While Trojans and backdoors are not easily detectable by themselves, computers may appear to run slower due to heavy processor or network usage</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">7:viruses and worms</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">A computer virus attaches itself to a program or file enabling it to spread from one computer to another, leaving infections .a worm is its capability to replicate itself on your system, so rather than your computer sending out a single worm, it could send out hundreds or thousands of copies of itself, creating a huge devastating effect.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">8:Sniffing Traffic</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">It is a program that monitors and analyzes network traffic, detecting and finding problems.Various technique and tool is used for sniffing like kali linux MITM attack,tshark,urlsnarf etc</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">9:Social engineering</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">In this technique,ethical hacker create the phishing page of website to obtain credential of users.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">10:Denial of service</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">A DoS attack generally consists of efforts to temporarily interrupt or suspend or down the services of a host connected to the Internet.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">11:Session Hijacking</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">It is used to gain unauthorized access to information or services in a computer system.Session hijacking is also known as man in the middle attack.This can be performed with the help of kali linux which is based on debian linux.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">12:Hacking Web Servers</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Web server can be hacked by varios ways like Denial of Service Attacks,Domain Name System Hijacking,Phishing etc.List of tool to hack web server are Metasploit,Mpack,Zeus etc</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">13:Webapplication</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Webapplication is used to intercept the proxy,as an intruder,as an repeater etc after hacking the website webapplication is used to upload injecton and script in website like populer c99 injection.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">14:SQL Injection</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">SQL injection is used to insert the qwery and confuse the database of system to gain unauthorised access.Hackers use sql injection to extract the data from website without credential Eg ‘or’‘=’</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">15:Wireless</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">In this user get to know about the type of wireless interface and how to expoit the different type of security encryption like wep ,wpa,wpa2 etc</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">16:Mobile hacking</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">users know ,how to sniff the nework using mobile ,hack another user smartphone and extract the data from smartphone,how to root the smartphone etc.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">17:IDS,Firewell and Honeypots</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">IDS stands for Intrusion detection system.IDS  is a device or software application that monitors network or system activities.Firewell is used to set rule to inbound and outbound traffic.There are two types of firewell software and hardware.software firewell is cheap as compare to hardware firewell.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">18:Buffer Overflows</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">A buffer overflow condition exists when a program attempts to put more data in a buffer than it can hold.Normally this is due to the vulnerability in drivers of system as when driver start performing improperly then system get crashed and blue screen appear on the screen.</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">19:Cryptography</p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal">Cryptography is the study and application of techniques that hide the real meaning of information by transforming it into non human readable formats and vice versa.The process of transforming information into non human readable form is called encryption.</p>

<p class="wb-stl-normal">The process of reversing encryption is called decryption.</p>

<p class="wb-stl-normal">Decryption is done using a secret key which is only known to the legitimate recipients of the information</p>
</div><div id="wb_element_instance232" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(58);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance232");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance232").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance228" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance229" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance230" class="wb_element"><div id="wb_element_instance230_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance230_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance230_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance230_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance230_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance230_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance230_toolbox"); }
			</script></div><div id="wb_element_instance233" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>