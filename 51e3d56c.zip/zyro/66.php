<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Password Cracking</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="Password Cracking is the process of recovering passwords from data that have been stored in or transmitted by a computer system. A common approach (brute-force attack) is to repeatedly try guesses for the password." />
	<meta name="keywords" content="Introduction to Password Cracking,Tips to create the strong password,Tools of Password Cracking" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/66.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance303" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance304" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance308" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">Introduction to Password Cracking</span></h1>

<p><br><span style="color:#bebebe;"><strong>Password Cracking</strong> is the process of recovering passwords from data that have been stored in or transmitted by a computer system. A common approach (brute-force attack) is to repeatedly try guesses for the password.<br>
The purpose of password cracking might be to help a user recover a forgotten password (though installing an entirely new password is less of a security risk, but involves System Administration privileges), to gain unauthorized access to a system, or as a preventive measure by System Administrators to check for easily crackable passwords. On a file-by-file basis, password cracking is utilized to gain access to digital evidence for which a judge has allowed access but the particular file's access is restricted.</span></p>

<p><br><span style="color:#bebebe;">computer programmers have been trying to create algorithms for password cracking in less time. Most of the password cracking tools try to login with every possible combination of words. If login is successful, it means the password was found. If the password is strong enough with a combination of numbers, characters and special characters, this cracking method may take hours to weeks or months. A few password cracking tools use a dictionary that contains passwords. These tools are totally dependent on the dictionary, so success rate is lower.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Tips to create the strong password</span></h1>

<p><br><br><span style="color:#bebebe;">The longer the password, the harder it is to crack: Password length is the most important factor. If you select a small password, password cracking tools can easily crack it by using few words combinations. A longer password will take a longer time in guessing. Your password must be at least 8 characters long.<br><br>
Always use a combination of characters, numbers and special characters: This is another thing which makes passwords hard to crack. Password cracking tools try the combination of one by one. Have a combination of small characters, capital letters, and special characters. Suppose if you have only numbers in your password. Password cracking tools only need to guess numbers from 0-9. Here only length matters. But having a password combination of a-z, A-Z, 0-9 and other special characters with a good length will make it harder to crack. This kind of password sometimes takes weeks to crack.<br><br>
Variety in passwords: One important thing you must always take care. Never use same password everywhere. Cyber criminals can steal passwords from one website and then try it on other websites too.<br>
In case you are not sure about the strength of your password, you can check it from variety of online tools available for free. Try this official Microsoft Tool for checking the password strength.</span></p>

<p><span style="color:#bebebe;">•https://www.microsoft.com/security/pc-security/password-checker.aspx</span></p>

<p><br><span style="color:#bebebe;">•Example of strong password: AdZfL48024@ #$!</span></p>

<p><br>
 </p>

<p><br>
 </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Tools of Password Cracking</span></h1>

<p> </p>

<p><span style="color:#bebebe;"><strong>1.  Brutus</strong><br>
Brutus is one of the most popular remote online password cracking tools. It claims to be the fastest and most flexible password cracking tool. This tool is free and is only available for Windows systems. It was released back in October 2000.<br>
It supports HTTP (Basic Authentication), HTTP (HTML Form/CGI), POP3, FTP, SMB, Telnet and other types such as IMAP, NNTP, NetBus, etc. You can also create your own authentication types. This tool also supports multi-stage authentication engines and is able to connect 60 simultaneous targets. It also has resume and load options. So, you can pause the attack process any time and then resume whenever you want to resume.<br>
This tool has not been updated for many years. Still, it can be useful for you.</span></p>

<p><span style="color:#bebebe;"><strong>2.   RainbowCrack</strong><br>
RainbowCrack is a hash cracker tool that uses a large-scale time-memory trade off process for faster password cracking than traditional brute force tools. Time-memory trade off is a computational process in which all plain text and hash pairs are calculated by using a selected hash algorithm. After computation, results are stored in the rainbow table. This process is very time consuming. But, once the table is ready, it can crack a password must faster than brute force tools.<br>
You also do not need to generate rainbow tablets by yourselves. Developers of RainbowCrack have also generated LM rainbow tables, NTLM rainbow tables, MD5 rainbow tables and Sha1 rainbow tables. Like RainbowCrack, these tables are also available for free. You can download these tables and use for your password cracking processes.<br><br>
This tool is available for both Windows and Linux systems.</span></p>

<p><span style="color:#bebebe;"><strong>3. Wfuzz</strong><br>
Wfuzz is another web application password cracking tool that tries to crack passwords with brute forcing. It can also be used to find hidden resources like directories, servlets and scripts. This tool can also identify different kind of injections includingSQL Injection, XSS Injection, LDAP Injection, etc in Web applications.<br><br>
Key features of Wfuzz password cracking tool:<br>
Capability of injection via multIipe points with multiple dictionary<br>
Output in colored HTML<br>
Post, headers and authentication data brute forcing<br>
Proxy and SOCK Support, MultIipe Proxy Support<br>
Multi Threading<br>
Brute force HTTP Password<br>
POST and GET Brute forcing<br>
Time delay between requests<br>
Cookies fuzzing</span></p>

<p> </p>

<p><span style="color:#bebebe;"><strong>4.  Cain and Abel</strong><br>
Cain and Abel is a well-known password cracking tool that is capable of handling a variety of tasks. The most notable thing is that the tool is only available for Windows platforms. It can work as sniffer in the network, cracking encrypted passwords using the dictionary attack, recording Voip conversations, brute force attacks, cryptanalysis attacks, revealing password boxes, uncovering cached passwords, decoding scrambled passwords, and analyzing routing protocols.<br><br>
Cain and Abel does not exploit any vulnerability or bugs. It only covers security weakness of protocols to grab the password. This tool was developed for network administrators, security professionals, forensics staff, and penetration testers.</span></p>

<p><span style="color:#bebebe;"><strong>5.  John the Ripper</strong><br>
John the Ripper is another well-known free open source password cracking tool for Linux, Unix and Mac OS X. A Windows version is also available. This tool can detect weak passwords. A pro version of the tool is also available, which offers better features and native packages for target operating systems. You can also download Openwall GNU/*/Linux that comes with John the Riper.</span><br>
 </p>

<p><span style="color:#bebebe;"><strong>6. THC Hydra</strong><br>
THC Hydra is a fast network logon password cracking tool. When it is compared with other similar tools, it shows why it is faster. New modules are easy to install in the tool. You can easily add modules and enhance the features. It is available for Windows, Linux, Free BSD, Solaris and OS X. This tool supports various network protocols.<br><br>
Currently it supports Asterisk, AFP, Cisco AAA, Cisco auth, Cisco enable, CVS, Firebird, FTP, HTTP-FORM-GET, HTTP-FORM-POST, HTTP-GET, HTTP-HEAD, HTTP-PROXY, HTTPS-FORM-GET, HTTPS-FORM-POST, HTTPS-GET, HTTPS-HEAD, HTTP-Proxy, ICQ, IMAP, IRC, LDAP, MS-SQL, MYSQL, NCP, NNTP, Oracle Listener, Oracle SID, Oracle, PC-Anywhere, PCNFS, POP3, POSTGRES, RDP, Rexec, Rlogin, Rsh, SAP/R3, SIP, SMB, SMTP, SMTP Enum, SNMP, SOCKS5, SSH (v1 and v2), Subversion, Teamspeak (TS2), Telnet, VMware-Auth, VNC and XMPP.</span></p>

<p><span style="color:#bebebe;"><strong>7. Medusa</strong><br>
Medusa is also a password cracking tool similar to THC Hydra. It claims to be a speedy parallel, modular and login brute forcing tool. It supports HTTP, FTP, CVS, AFP, IMAP, MS SQL, MYSQL, NCP, NNTP, POP3, PostgreSQL, pcAnywhere, rlogin, SMB, rsh, SMTP, SNMP, SSH, SVN, VNC, VmAuthd and Telnet. While cracking the password, host, username and password can be flexible input while performing the attack.<br>
Medusa is a command line tool, so you need to learn commands before using the tool. Efficiency of the tool depends on network connectivity. On a local system, it can test 2000 passwords per minute.<br>
With this tool, you can also perform a parallel attack. Suppose you want to crack passwords of a few email accounts simultaneously. You can specify the username list along with the password list.</span><br>
 </p>

<p><span style="color:#bebebe;"><strong>8. OphCrack</strong><br>
OphCrack is a free rainbow-table based password cracking tool for Windows. It is the most popular Windows password cracking tool, but can also be used on Linux and Mac systems. It cracks LM and NTLM hashes. For cracking Windows XP, Vista and Windows 7, free rainbow-tables are also available.<br>
A live CD of OphCrack is also available to simplify the cracking. One can use the Live CD of OphCrack to crack Windows-based passwords. This tool is available for free.</span></p>

<p><span style="color:#bebebe;"><strong>9. L0phtCrack</strong><br>
L0phtCrack is an alternative to OphCrack. It attempts to crack Windows password from hashes. For cracking passwords, it uses Windows workstations, network servers, primary domain controllers, and Active Directory. It also uses dictionary and brute force attacking for generating and guessing passwords. It was acquired by Symantec and discontinued in 2006. Later L0pht developers again re-acquired it and launched L0phtCrack in 2009.<br>
It also comes with a schedule routine audit feature. One can set daily, weekly or monthly audits, and it will start scanning on the scheduled time.</span></p>

<p><span style="color:#bebebe;"><strong>10. Aircrack-NG</strong><br>
Aircrack-NG is a WiFi password cracking tool that can crack WEP or WPA passwords. It analyzes wireless encrypted packets and then tries to crack passwords via its cracking algorithm. It uses the FMS attack along with other useful attack techniques for cracking password. It is available for Linux and Windows systems. A live CD of Aircrack is also available.</span><br>
 </p>

<p> </p>

<p> </p>
</div><div id="wb_element_instance309" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(66);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance309");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance309").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance305" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance306" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance307" class="wb_element"><div id="wb_element_instance307_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance307_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance307_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance307_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance307_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance307_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance307_toolbox"); }
			</script></div><div id="wb_element_instance310" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>