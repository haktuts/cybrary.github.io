<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Introduction</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="Types of hackers,
1.White hat hackers
2.Black hat hackers
3.Grey hat hackers," />
	<meta name="keywords" content="Who is hacker,Hackers v,s crackers" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/7.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance103" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance104" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance108" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">Who is Hacker?</h1>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Hacker</strong> is a person who is able to discover a vulnerability in system and manages to exploit. Hacking  means gains unauthorised access into system. There are three types of hackers as given below:</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;">1.White hat hackers</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">2.Black hat hackers</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">3.Grey hat hackers</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>White hat hackers</strong>:  white hat hackers or penetration tester are  ethical hackers. They use the hacking skill for defensive purpose.</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Black hat hackers</strong>: this category of hackers also known as crackers . They find the vulnerability in system and use the same for offensive purpose.</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Grey hat hackers</strong>: these are those category of hackers who use their skill for both defensive and offensive purpose.</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;">The majority of people fall in this categories.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">Apart from above another type of hackers given below:</span></p>

<p class="wb-stl-normal"><strong><span style="color:#bebebe;">Elite hackers</span></strong></p>

<p class="wb-stl-normal"><strong><span style="color:#bebebe;">Script kiddie</span></strong></p>

<p class="wb-stl-normal"><strong><span style="color:#bebebe;">Neophyte</span></strong></p>

<p class="wb-stl-normal"><strong><span style="color:#bebebe;">Hacktivist</span></strong></p>

<p class="wb-stl-normal"><strong><span style="color:#bebebe;">Green hat hackers</span></strong></p>

<h1 class="wb-stl-heading1"> </h1>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Hackers v/s crackers </span></h1>

<p class="wb-stl-normal"><br><span style="color:#bebebe;">A cracker (also known as a black hat hacker) is an individual with extensive computer knowledge whose purpose is to breach or bypass internet security or gain access to software. hackers can also be internet security experts hired to find vulnerabilities in systems. These hackers are also known as white hat hackers. Crackers can also refer to those who reverse engineer software and modify it for their own amusement.</span><br>
 </p>

<p> </p>
</div><div id="wb_element_instance109" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(7);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance109");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance109").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance105" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance106" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance107" class="wb_element"><div id="wb_element_instance107_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance107_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance107_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance107_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance107_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance107_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance107_toolbox"); }
			</script></div><div id="wb_element_instance110" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>