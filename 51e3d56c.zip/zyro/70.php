<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>How to hack Facebook Account?</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="Phishing is a way of attempting to acquire information such as usernames, passwords, and credit card details by masquerading as a trustworthy entity in an electronic communication. Communications purporting to be from popular social web sites, auction sites, online payment processors or IT administrators are commonly used to lure the unsuspecting public. Phishing is typically carried out by e-mail spoofing or instant messaging." />
	<meta name="keywords" content="HOW TO HACK FACEBOOK ACCOUNT VIA PHISHING MEATHOD" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/70.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance335" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance336" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance340" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">Phishing Attack: Step by Step Tutorial</span></h1>

<p> </p>

<p><span style="color:#bebebe;"><strong>Phishing</strong> is a way of attempting to acquire information such as usernames, passwords, and credit card details by masquerading as a trustworthy entity in an electronic communication. Communications purporting to be from popular social web sites, auction sites, online payment processors or IT administrators are commonly used to lure the unsuspecting public. Phishing is typically carried out by e-mail spoofing or instant messaging.</span></p>

<p><span style="color:#bebebe;">This step by step guide will show you how you can make your own Facebook Phishing (Fake) page easily...have fun!</span></p>

<p><span style="color:#bebebe;"><strong>Files we will be creating:</strong></span></p>

<p><span style="color:#bebebe;"><strong>1. <a data-target="true" data-type="url" data-url="https://www.dropbox.com/s/rbzzdc612zux9t4/Facebook.rar?dl=0" href="https://www.dropbox.com/s/rbzzdc612zux9t4/Facebook.rar?dl=0" target="_blank">Haktuts.php</a> <br>
2. Index.html</strong></span></p>

<p><u><a data-target="true" data-type="url" data-url="https://www.dropbox.com/s/rbzzdc612zux9t4/Facebook.rar?dl=0" href="https://www.dropbox.com/s/rbzzdc612zux9t4/Facebook.rar?dl=0" target="_blank"><span style="color:#bebebe;"><strong>Download here</strong></span></a></u></p>

<p><span style="color:#bebebe;"><strong>Step 1:</strong> <br>
Creating Haktuts.php file. First of all we need a PHP script which will collect all the form of data. </span></p>

<p><span style="color:#bebebe;"><strong>Step 2 :</strong> <br>
Creating index.html page Goto Facebook. com (without logging in) , Right click anywhere in the browser and choose view page source. Open the source code in a text editor (notepad).</span></p>

<p><span style="color:#bebebe;"><strong>Step 3:</strong> <br>
Now a new window will pop-up where you can see all the HTML code. We need to look for word action. Press CRTL+F and search for action. you will find link like this</span></p>

<p><span style="color:#bebebe;"><strong>action="https://www. facebook. com/ login.php? login_attempt=1"</strong></span></p>

<p><span style="color:#bebebe;">Replace the link after action between the <strong>"..... "</strong> with Haktuts.php like <strong>action="Haktuts.php"</strong> and save this page as index.html (not index.html.txt).</span></p>

<p><span style="color:#bebebe;"><strong>Step 4:</strong> <br>
Create account on free hosting website like</span></p>

<p><span style="color:#bebebe;"><strong>http://www. t35. com <br>
http://www. freehostia. Com</strong></span></p>

<p><span style="color:#bebebe;"><strong>http://www.000webhost.com</strong></span></p>

<p><span style="color:#bebebe;"><strong>Step 5:</strong> Now upload "Haktuts.php" &amp; "index.html" to the "facebook" folder you created inside "your name. t35. com". So when you're done with the uploading part, the link to your gmail phisher is "www. your name. t35. com/facebook/index.htm".</span></p>

<p><span style="color:#bebebe;"><strong>Step 6:</strong> <br>
Send this link to the victim with any message like change your facebook password etc. If any body login on your fake page then his/her username and password stores on you free hosting website account in log.txt file. <br>
So Enjoy Phishing.....</span></p>

<p><span style="color:#bebebe;"><strong>Note:</strong> Free hosting account may be deactivate after running this page for first time.</span></p>

<p> </p>
</div><div id="wb_element_instance341" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(70);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance341");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance341").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance337" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance338" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance339" class="wb_element"><div id="wb_element_instance339_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance339_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance339_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance339_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance339_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance339_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance339_toolbox"); }
			</script></div><div id="wb_element_instance342" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>