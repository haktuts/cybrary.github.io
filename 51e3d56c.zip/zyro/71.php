<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Android</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="Android is a mobile operating system (OS) based on the Linux kernel.
Dalvik is the software that runs the applications on Android devices. we can say, dalvik as the virtual machine of android device.
list of android version:
1. Alpha (1.0)
2. Beta (1.1)
3. Cupcake (1.5)
4. Donut (1.6)
5. Eclair (2.0–2.1)
6. Froyo (2.2–2.2.3)
7. Gingerbread (2.3–2.3.7)
8. Honeycomb (3.0–3.2.6)
9. Ice Cream Sandwich (4.0–4.0.4)" />
	<meta name="keywords" content="Introduction to Android,Architecture of Android" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/71.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance343" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance344" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance348" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">Introduction to Android</span></h1>

<p> </p>

<p><span style="color:#bebebe;"><strong>Android</strong> is a mobile operating system (OS) based on the Linux kernel.</span></p>

<p><span style="color:#bebebe;"><strong>Dalvik</strong> is the software that runs the applications on Android devices. we can say, dalvik as the virtual machine of android device.</span></p>

<p><span style="color:#bebebe;"><strong>list </strong>of android version:</span></p>

<p><span style="color:#bebebe;"><strong>1. Alpha (1.0)</strong></span></p>

<p><span style="color:#bebebe;"><strong>2. Beta (1.1)</strong></span></p>

<p><span style="color:#bebebe;"><strong>3. Cupcake (1.5)</strong></span></p>

<p><span style="color:#bebebe;"><strong>4. Donut (1.6)</strong></span></p>

<p><span style="color:#bebebe;"><strong>5. Eclair (2.0–2.1)</strong></span></p>

<p><span style="color:#bebebe;"><strong>6. Froyo (2.2–2.2.3)</strong></span></p>

<p><span style="color:#bebebe;"><strong>7. Gingerbread (2.3–2.3.7)</strong></span></p>

<p><span style="color:#bebebe;"><strong>8. Honeycomb (3.0–3.2.6)</strong></span></p>

<p><span style="color:#bebebe;"><strong>9. Ice Cream Sandwich (4.0–4.0.4)</strong></span></p>

<p><span style="color:#bebebe;"><strong>10. Jelly Bean (4.1–4.3.1)</strong></span></p>

<p><span style="color:#bebebe;"><strong>11. Kit Kat (4.4–4.4.4)</strong></span></p>

<p><span style="color:#bebebe;"><strong>12. Lollipop 5.0</strong></span></p>

<p><span style="color:#bebebe;"><strong>Note:</strong> list of android version are in sequence of A-L .(i.e. Ascending order)</span></p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Architecture of Android</span></h1>

<p> </p>

<p><span style="color:#bebebe;"><strong>1).  Linux Kernel:</strong> Android is open sources operating system. Android OS was built on linux kernal. Normally,it control the hardware component of android devices like camera,wifi and flash etc….</span></p>

<p><span style="color:#bebebe;"><strong>2).  Android Runtime:</strong> It help the programmer to execute the programme written in java language. programmer use the dalvik virtual machine to run the android application.</span></p>

<p><span style="color:#bebebe;"><strong>3).  Libraries: </strong>Android library contain both source code and resources of application.</span></p>

<p><span style="color:#bebebe;"><strong>4).  Application framework:</strong> It contain the UI and activity of the android application.</span></p>

<p><span style="color:#bebebe;"><strong>5).  Application:</strong> we can say the final stage of android application as after build and compilation the output is called android application.</span></p>

<p> </p>
</div><div id="wb_element_instance349" class="wb_element"><img alt="" src="gallery/f77b85a967abe1196963be3882641b02_900x500.jpg"></div><div id="wb_element_instance350" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(71);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance350");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance350").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance345" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance346" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance347" class="wb_element"><div id="wb_element_instance347_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance347_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance347_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance347_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance347_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance347_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance347_toolbox"); }
			</script></div><div id="wb_element_instance351" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>