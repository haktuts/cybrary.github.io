<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Pentesting</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="1).  zAnti is a network diagnostic toolkit. zANTI provide features, including everything from Man-In-The-Middle,password authentication,backdoor,brute-force,port monitoring and packet sniffer. It also help to route traffic from HTTPS TO HTTP.
2).  Fing Tool help to find out which devices are connected to your Wi-Fi network. Fing is a professional App for network analysis. Displays MAC Address and device manufacturer. It help to find out the open port, Ping and traceroute and  automatic DNS lookup and reverse lookup.
3).  tPacketcapture help to capture the packet without the root permission. Captured data are saved as a PCAP file format in the external storage.
4).  Shark for root is a traffic sniffer.It require root permission to capture the packet." />
	<meta name="keywords" content="Pentesting via android application,Pentesting via windows" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/74.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance368" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance369" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance373" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">Pentesting via android application</span></h1>

<p> </p>

<p><span style="color:#bebebe;"><strong>1).</strong>  <strong>zAnti</strong> is a network diagnostic toolkit. zANTI provide features, including everything from Man-In-The-Middle,password authentication,backdoor,brute-force,port monitoring and packet sniffer. It also help to route traffic from HTTPS TO HTTP.</span></p>

<p><span style="color:#bebebe;"><strong>2).</strong>  <strong>Fing Tool</strong> help to find out which devices are connected to your Wi-Fi network. Fing is a professional App for network analysis. Displays MAC Address and device manufacturer. It help to find out the open port, Ping and traceroute and  automatic DNS lookup and reverse lookup.</span></p>

<p><span style="color:#bebebe;"><strong>3).</strong>  <strong>tPacketcapture</strong> help to capture the packet without the root permission. Captured data are saved as a PCAP file format in the external storage.</span></p>

<p><span style="color:#bebebe;"><strong>4).</strong>  <strong>Shark</strong> <strong>for root</strong> is a traffic sniffer.It require root permission to capture the packet.</span></p>

<p><span style="color:#bebebe;"><strong>5).</strong>  <strong>Shark Reader</strong> use for reading the captured packet which are saved as PCAP extension.</span></p>

<p><span style="color:#bebebe;"><strong>6).</strong>  <strong>Loic</strong> stands for low Orbit Ion Cannon. It is used for flooding packets.It is useful for performing dos attack.</span></p>

<p><span style="color:#bebebe;"><strong>7).</strong>  <strong>ZIMPERIUM</strong> Mobile IPS used to defend your Android devices from advanced mobile threats.It protect from Man-in-the-Middle attacks, SpearPhishing attacks, Reconnaissance Scans.</span></p>

<p><span style="color:#bebebe;"><strong>8).</strong>  <strong>Sqlmapchik</strong> tool is useful for testing vulnerability in website.User can inject sqlinjection,if vulnerability found in website.</span></p>

<p><span style="color:#bebebe;"><strong>9).</strong>  <strong>Dsploit</strong> provide features from Man-In-The-Middle,password authentication,backdoor,brute-force,port monitoring and packet sniffer. It also help to redirect website from one to another.</span></p>

<p><span style="color:#bebebe;"><strong>10).</strong>  <strong>Droidsheep</strong> tool is used to hijack the http seassion of user.It is used to steal the session and cookie of user.</span></p>

<p> </p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">Pentesting via windows</span></h1>

<p> </p>

<p><span style="color:#bebebe;"><strong>1.</strong>  <strong>Drozer</strong> provides an easy and powerful way to interact with application IPC endpoints. Assessing the integrity of an application from attacks launched from malicious apps is a major part of any Android application vulnerability assessment. Ethical hacking service providers must ensure that other apps on the device cannot steal application data or invoke the application in insecure ways. Mercury allows for a tester to use an agent to simulate any attacks they wish, and operate as an unprivileged but malicious app.</span></p>

<p><span style="color:#bebebe;"><strong>2.</strong>  <strong>Eclipse</strong> help reverse engineering and subverting client side controls . Client side controls on the Android platform can generally be defeated most easily by modifying and repackaging smali code. It provides an easy to use interface to import the applications APK, disassemble the application, view the contents of the package, and rebuild the application after modifying code. It also allows for Java to be generated for smali documents, allowing an easier way to read many code pages. Packages can also be seamlessly pushed to your testing device or emulator through ADB. It is free for personal use.</span></p>

<p><span style="color:#bebebe;"><strong>3.</strong>  <strong>Burp Suite</strong> is a Java application that can be used to secure or penetrate web applications. The suite consists of different tools, such as a proxy server, a web spider, intruder and repeater. Burp has simple but powerful features to intercept, modify, and replay traffic sent by the client.</span></p>

<p> </p>
</div><div id="wb_element_instance374" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(74);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance374");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance374").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance370" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance371" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance372" class="wb_element"><div id="wb_element_instance372_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance372_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance372_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance372_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance372_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance372_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance372_toolbox"); }
			</script></div><div id="wb_element_instance375" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>