<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Jailbreak Tools</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="iOS jailbreak Tools" />
	<meta name="keywords" content="LIST OF JAILBREAKING TOOL,Pangu,evasi0n7,evasi0n,p0sixspwn,absinthe" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/78.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance400" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance401" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance405" class="wb_element" style=" line-height: normal;"><p><span style="color:#bebebe;">1. iOS 7.1-7.1.2</span></p>

<p><br><br><br><br>
 </p>

<p><span style="color:#bebebe;">2. iOS 7.0-7.0.6</span></p>

<p><br><br><br><br>
 </p>

<p><span style="color:#bebebe;">3. iOS 6.1.3-6.1.6</span></p>

<p><br><br><br>
 </p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">4. iOS 6.0-6.1.2</span></span></p>

<p> </p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;">5.  iOS 5.1.1</span></p>

<p><br><br><br><br>
 </p>

<p><span style="color:#bebebe;">6.  iOS  5.1.1, 5.0.1,</span></p>

<p><span style="color:#bebebe;">     4.0 through 4.3.3</span></p>

<p><br>
 </p>

<p><span style="color:#bebebe;">7.  iOS 5.0-5.0.1</span></p>

<p><br><br>
 </p>

<p><span style="color:#bebebe;">8.  iOS 4.3-4.3.3, 4.2.6-4.2.8</span></p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;">9.  iOS 4.1-4.2.1</span></p>

<p><br>
 </p>

<p> </p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">10.  iOS 3.1.2-4.0.1</span></span></p>

<p><br><br><br><span style="color:#bebebe;"><span style="background-color: transparent;">11.  iOS  3.1.2, 3.1.3, 3.2</span></span></p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;">12.  iOS 3.1.2</span></p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">13.  iOS 3.0</span></span></p>

<p> </p>

<p><span style="color:#bebebe;">14.  iOS 2.2.1</span></p>

<p><br><br>
 </p>

<p> </p>
</div><div id="wb_element_instance406" class="wb_element" style=" line-height: normal;"><p><span style="color:#bebebe;">1.  IPhone 5S, IPhone 5C, IPhone 5, IPhone 4S, IPhone 4, IPad mini 2nd generation, IPad mini 1st generation, IPad Air, IPad 4th generation, IPad 3rd generation, IPad 2, and IPod touch 5g.</span></p>

<p> </p>

<p><span style="color:#bebebe;">2.  IPhone 5S, IPhone 5C, IPhone 5, IPhone 4S, IPhone 4, IPad mini 2nd generation, IPad mini 1st generation, IPad Air, IPad 4th generation, IPad 3rd generation, IPad 2, and IPod touch 5g.</span></p>

<p> </p>

<p><span style="color:#bebebe;">3. IPhone 5, IPhone 4S, IPhone 4, IPhone 3GS, IPad mini, IPad 4th generation, IPad 3rd generation, IPad 2, and IPod touch 5g and 4g.</span></p>

<p> </p>

<p><span style="color:#bebebe;">4. IPhone 5, IPhone 4S, IPhone 4, IPhone 3GS, IPad mini, IPad 4th generation, IPad 3rd generation, IPad 2, and IPod touch 5g and 4g.</span></p>

<p> </p>

<p><span style="color:#bebebe;">5.  IPad 3rd generation, IPad 2, IPad 1, IPhone 4S, IPhone 4, IPhone 3GS, and IPod touch 3g and 4g.</span></p>

<p><br><br>
 </p>

<p><span style="color:#bebebe;">6.  on most devices except IPad 3rd generation, IPad 2, and IPhone 4S); can preserve unlockable basebands.</span></p>

<p><br>
 </p>

<p><span style="color:#bebebe;">7.  IPhone 4S and IPad 2</span></p>

<p><br><br>
 </p>

<p><span style="color:#bebebe;">8.  IPhone 3GS and 4, IPod touch 3g and 4g, IPad 1, IPad 2 , IPhone 4 CDMA.</span></p>

<p> </p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">9.  IPhone 3GS and 4; IPod touch 2g, 3g, and 4g; and IPad 1</span></span></p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">10.  IPhone ,IPod ,IPad 1.</span></span></p>

<p><br><br><br>
 </p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">11.  2G unlock, IPad 1</span></span></p>

<p><br><br><span style="color:#bebebe;"><span style="background-color: transparent;">12.  Newer 3GS models tethered</span></span></p>

<p><br>
 </p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">13.  3GS only</span></span></p>

<p><br><br>
 </p>

<p><span style="color:#bebebe;">14.  IPhone 2G</span></p>

<p> </p>

<p> </p>
</div><div id="wb_element_instance407" class="wb_element" style=" line-height: normal;"><p><span style="color:#bebebe;">1. Pangu -Macs and windows.</span></p>

<p><br><br><br>
 </p>

<p> </p>

<p><span style="color:#bebebe;">2. evasi0n7-Macs and Windows.</span></p>

<p><br><br><br><br><span style="color:#bebebe;"><span style="background-color: transparent;">3. P0sixspwn-Macs and Windwows.</span></span></p>

<p><br><br>
 </p>

<p><span style="color:#bebebe;">4. evasi0n-Macs, Linux and Windows.</span></p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;">5.  Absinthe 2.0 -Macs ,Linx and windows.</span></p>

<p><br><br>
 </p>

<p><span style="color:#bebebe;">6.  Pwnage Tools-Macs.</span></p>

<p><br><br>
 </p>

<p> </p>

<p><span style="color:#bebebe;">7.  Absinthe 0.4 -Macs ,Linx and windows.</span></p>

<p><br>
 </p>

<p><span style="color:#bebebe;">8.  JailbreakMe.com “Saffron”(Web)</span></p>

<p><br>
 </p>

<p><span style="color:#bebebe;">9.  Greenpois0n (Windows &amp; Mac)</span></p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">10.  JailbreakMe.com “Star”(Web)</span></span></p>

<p><br><br><br><span style="color:#bebebe;"><span style="background-color: transparent;">11.  Spirit (Windows &amp; Mac)</span></span></p>

<p> </p>

<p> </p>

<p><span style="color:#bebebe;">12.  Blackra1n Windows &amp; Mac)</span></p>

<p><br>
 </p>

<p><span style="color:#bebebe;">13.  Purplera1n (Windows &amp; Mac)</span></p>

<p> </p>

<p><span style="color:#bebebe;">14.  QuickPwn-Mac&amp; Window</span></p>

<p> </p>

<p> </p>
</div><div id="wb_element_instance408" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(78);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance408");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance408").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance402" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance403" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance404" class="wb_element"><div id="wb_element_instance404_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance404_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance404_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance404_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance404_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance404_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance404_toolbox"); }
			</script></div><div id="wb_element_instance409" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>