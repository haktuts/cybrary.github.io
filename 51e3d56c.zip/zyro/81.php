<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>keylogger</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="A key logger is a hardware device or a software program that records the real time activity of a computer user including the keyboard keys they press." />
	<meta name="keywords" content="What is Key Logger,Types of keylogger" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/81.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance426" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance427" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance431" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">Keylogger</span></h1>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p><br><span style="color:#bebebe;"> <strong>What is Key Logger ???</strong><br>
•A key logger is a hardware device or a software program that records the real time activity of a computer user including the keyboard keys they press.<br>
•Keyloggers are used in IT organizations to troubleshoot technical problems with computers and business networks.<br>
•Keyloggers can also be used by a family (or business) to monitor the network usage of people without their direct knowledge. <br>
• Finally, malicious individuals may use key loggers on public computers to steal passwords or credit card information.<br>
•It can be used by parents to keep eye on their children's or company owner to spy on their employs.</span><br>
 </p>

<p><span style="color:#bebebe;"> <strong>Types of  Key Loggers</strong> </span></p>

<p><span style="color:#bebebe;">•<strong>Hardware</strong> Key Logger.</span></p>

<p><span style="color:#bebebe;">•<strong>Software</strong> Key Logger.</span></p>

<p> </p>

<p><span style="color:#bebebe;"><strong>Various Key Logger Names</strong></span></p>

<p><span style="color:#bebebe;">•<strong>Award</strong> Key logger Pro 3.2.<br>
•<strong>Refog</strong> Free Keylogger.<br>
•<strong>Super WinSpy</strong>.<br>
•<strong>Personal</strong> Keylogger.<br>
•Keylogger <strong>Douglas</strong>.<br>
•<strong>Revealer</strong> Keylogger Free Edition.</span><br>
 </p>

<p> </p>

<p><span style="color:#bebebe;"><strong>How to setup Remote  Keylogger:</strong><br><br><strong>1.</strong><a data-target="true" data-type="url" data-url="http://www.ardamax.com/download.html" href="http://www.ardamax.com/download.html" target="_blank">Download</a> Adramax Keylogger<br><strong>2.</strong>Ignore Antivirus Warning<br><strong>3.</strong>Install it<br><strong>4.</strong>Now start Adramax keylogger<br><strong>5.</strong>In setting tab enter the registration keys<br><strong>6.</strong>Right click  the adramax icon from the tray bar and click on remote installation menu<br><strong>7.</strong>Click next button 2 times and select all the check boxes<br><strong>8.</strong>Click Enable and enter a password  so that no one else can open  your logs<br><strong>9.</strong> Now click next button 3 times and check the send logs every check box  and enter<br><strong>10.</strong>now chose the delivery method select the email options , give the email address were you want the logs to  be stored and then click next<br><strong>11.</strong>click on test button and if you get success  pop-up then you are almost done and click next now<br><strong>12.</strong>now select the path where you want to save your keylogger and click the exe icon and you can use some jpeg icon so that victim can be easily fooled<br><strong>13.</strong>Thats it ! You are done .you will have to use some <a data-target="true" data-type="url" data-url="http://cypherx.org" href="http://cypherx.org" target="_blank">crypters</a> to make the keylogger Fully Un Dectectable<a data-target="true" data-type="url" data-url="http://cypherx.org" href="http://cypherx.org" target="_blank">(FUD)</a>.</span><br>
 </p>

<p> </p>
</div><div id="wb_element_instance432" class="wb_element"><img alt="" src="gallery/148eb9f571b8e6291de0950f7a2561a8_400x266.jpg"></div><div id="wb_element_instance433" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(81);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance433");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance433").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance428" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance429" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance430" class="wb_element"><div id="wb_element_instance430_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance430_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance430_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance430_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance430_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance430_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance430_toolbox"); }
			</script></div><div id="wb_element_instance434" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>