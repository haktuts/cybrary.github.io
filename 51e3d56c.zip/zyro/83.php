<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Benefits</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="1. Run Old Apps
2.Access Virus-Infected Data
3. Browse in Complete Safely
4. Test Software, Upgrades, or New Configurations" />
	<meta name="keywords" content="Things that virtualization lets you do" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/83.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance443" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance444" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance448" class="wb_element" style=" line-height: normal;"><p><span style="color:#bebebe;"><strong><span style="background-color: transparent;">Things that virtualization lets you do</span></strong></span></p>

<p><br><span style="color:#bebebe;"><strong>1. Run Old Apps:</strong><br>
Got an application that won't play nice in Windows 7 or Vista, but works fine in XP or an even earlier version of Windows, like Me? Just grab an old Windows CD and install it within a virtual machine (VM). Then install your app.<br>
VMware Player features Unity mode, which allows applications running in the virtual machine to appear as if they're running natively on the host computer. They have their own taskbar buttons and their own program windows, making for a seamless experience. For this to work, however, you'll need to install the VMware Tools program on the virtualized operating system. You're usually prompted to do this after installation of the OS has finished.<br><br><strong>2. Access Virus-Infected Data:</strong><br>
Ever been sent a file that your antivirus program has flagged, but which contains important data you just have to view? Most virtualization software includes snapshot functionality, which means you can create a "saved state" of the virtual OS and its entire hard disk. It's a little like travelling back in time.<br>
You could create a snapshot in the virtual machine, open the infected file within the VM to access the data and, if the virus causes chaos, simply click to restore the VM snapshot. Hey presto--a clean virtualized computer.</span></p>

<p><br><span style="color:#bebebe;"><strong>3. Browse in Complete Safely</strong><br>
Why not install Windows on VMware Player, then install Firefox, and run it in Unity mode so it appears to run natively on the host computer?<br>
Essentially Firefox will be running in what's known as a sandbox, meaning that should it (or one of its plugins) get hacked while you're online, there'll be no absolutely no risk to your actual operating system. You could create a snapshot once everything's been configured in the virtual machine in order to get things back up and running quickly, should anything go wrong.<br><br><strong>4. Test Software, Upgrades, or New Configurations</strong><br>
The virus testing technique above isn't limited to malware. You could use your virtual computer to test new software, updates, or even new configurations of software before you roll them out for real on your main OS.<br>
Some server administrators use virtualization to create a copy of an existing installation of an operating system, plus its data, which they then run virtualized and play with to see if configuration changes or updates will cause any harm. If you manage workstation computers and want to be sure a Windows update is OK before rolling it out, you could do the same thing--just test it in a virtualized machine first.</span></p>

<p><br><span style="color:#bebebe;"><strong>5. Run Linux on Top of Windows (or vice-versa):</strong></span></p>

<p><span style="color:#bebebe;"><span style="background-color: transparent;">Want to give Linux a try but can't face repartitioning your computer's hard disk? Provided that it would ordinarily install on your computer, you can run just about any operating system inside a virtual machine, including most Linux distros.</span></span></p>

<p><span style="color:#bebebe;">Linux and Mac users have been using virtualization for years to run Windows on top of their chosen OS in this way.<br>
If you run a Linux machine for mail or Web services, as examples, having a desktop version of Linux for occasional use will also make it easier to communicate with the server. There's no need to install PUTTY on Windows to communicate via secure shell (SSH), for example, because Linux has that kind of thing built-in.<br><br><strong>6. Back Up an Entire Operating System</strong><br>
Because the virtual OS is entirely contained within a series of files, backing it up is as simple as backing up any other files. It's the same with virtualized server installations too. If you're running a virtual machine on a server to host your mail server, and it's brought down by a hack attack, then bringing things back to working order is as simple as restoring the backup files (assuming the vulnerability that allowed the hack is quickly addressed once things are up and running, of course).<br>
Bear in mind that creating a copy of a VM creates legal issues. Backing up should be fine, but if you create a copy of a VM installation to give to a friend, for example, then you'll be contravening copyright laws (assuming they apply, as with Microsoft, but not always with Linux).</span></p>

<p><span style="color:#bebebe;"><strong>7. Create a Personal Cloud Computer</strong><br>
If you're out of the office, there's no need to take your laptop with you. Just leave it running (with power saving turned off!), take your mobile phone or tablet computer instead, and access the laptop via a Remote Desktop Protocol (RDP) connection over the Internet. This will let you access the same desktop environment you're used to, although there'll be no fancy graphics.<br><br>
If you're running Windows 7 Professional, Ultimate, or Enterprise, then you can configure the computer to accept RDP connections by right-clicking Computer on the Start menu, selecting Properties, and clicking the Remote Settings link in the window that appears. The same instructions work for Windows Vista, although you'll need the Professional, Business, or Ultimate editions. Other versions of Windows don't support setting up an RDP server without a little bit of hacking (Google it).<br><br>
You'll need to take a note of the public IP address of your router in order to connect remotely, and configure the router to port forward incoming RDP connections to your notebook PC. How this is done varies from computer to computer, but often you can select predefined rules.<br>
Then download an RDP client for your mobile device and connect. For the Apple iPad and iPhone, you can try iTap but there are RDP clients for most platforms.<br><br><strong>8. Run Headless For Web Development</strong><br>
Most virtualization software allows the virtual machine to run headless, which is to say, without displaying a desktop (or other user-interface). Essentially, the virtual PC runs in the background although accepts all other kinds of connections, such as networking. For people creating websites, this offers the possibility of running their very own private web server for testing purposes.<br><br><br><strong>9. Make a Backup of Your Server For Emergencies</strong><br>
Amazon's Elastic Cloud Computing (EC2) service allows you to copy across any existing virtualized Windows 2008 Server installation for use on EC2 (eventually all kinds of server installs will be supported, such as Linux).<br>
Creating periodic backups of existing server installs in this way could provide vital redundancy if a catastrophe happens to your existing server. After the hurricane hits, leaving your physical servers in a whirl of dust, all you'd have to do is boot up the EC2 image, reconfigure things slightly to take into account the different IP addresses, and then continue as usual.<br><br><strong>10. Reuse Old Hardware:</strong><br><br>
By installing Citrix XenDesktop on your Windows server, you can turn old, less powerful computers into thin clients, wiping out the need for a workstation IT upgrade budget.<br><br>
The clients access their personal desktop spaces on the server and there's little noticeable difference compared with running the operating system and applications locally.<br><br>
 XenDesktop includes clever technology to avoid common thin-clientpitfalls, such as the fact videos and animations don't play well, by shifting some of the processing work to the client computer.<br>
XenDesktop also allows your workers to access their desktops from home, provided the server is configured to be publicly accessible and they have the right client software installed. You can even use mobile phones to connect to the desktop environments.</span></p>

<p> </p>
</div><div id="wb_element_instance449" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(83);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance449");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance449").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance445" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance446" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance447" class="wb_element"><div id="wb_element_instance447_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance447_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance447_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance447_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance447_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance447_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance447_toolbox"); }
			</script></div><div id="wb_element_instance450" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>