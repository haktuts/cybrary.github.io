<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Install Ubuntu via VirtualBox</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="1.Choose Ubuntu vm, click Start:
2. When vm starts, it shows you the first screen of Ubuntu setup. Choose the language you want from over 60languages, or wait 30 seconds for             English to be selected:
3. Ubuntu starts now in so called Live Mode. Double click Install Ubuntu icon:
4. Once again, choose your installation language:
5. Choose Download updates while installing. You might also want to install Fluendo MP3 plugin offered for better audio features.ClickForward:
6. Choose Erase and use the entire disk. Notice please, we are now talking about the virtual hard disk we created earlier, not the actual hd on your host computer. In other words, this does not mean your HD with Windows on it will be erased  Click Forward:
7. Click Install Now:
8. Choose your time zone:" />
	<meta name="keywords" content="Steps to install ubuntu in computer via virtual machine" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link href="css/85.css?ts=1425383878" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance459" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance460" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance464" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>Steps to install ubuntu in computer via virtual machine.</strong></span></h1>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>   </strong></span></h1>

<p><span style="color:#bebebe;"><strong>1.</strong>Choose Ubuntu vm, click Start:<br><strong>2.</strong> When vm starts, it shows you the first screen of Ubuntu setup. Choose the language you want from over 60<span style="background-color: transparent;">languages, or wait 30 seconds for             English to be selected:</span></span></p>

<p><span style="color:#bebebe;"><strong>3.</strong> Ubuntu starts now in so called Live Mode. Double click Install Ubuntu icon:<br><strong>4.</strong> Once again, choose your installation language:<br><strong>5.</strong> Choose Download updates while installing. You might also want to install Fluendo MP3 plugin offered for better audio features.<span style="background-color: transparent;">ClickForward:</span></span></p>

<p><span style="color:#bebebe;"><strong>6.</strong> Choose Erase and use the entire disk. Notice please, we are now talking about the virtual hard disk we created earlier, not the actual hd on your host computer. In other words, this does not mean your HD with Windows on it will be erased  Click Forward:<br><strong>7.</strong> Click Install Now:<br><strong>8.</strong> Choose your time zone:</span></p>

<p><span style="color:#bebebe;"><strong>9.</strong>Choose your preferred keyboard layout. To avoid confusion, I recommend choosing the same you are using on your host computer's<span style="background-color: transparent;">Windows.            Click Forward:</span></span></p>

<p><span style="color:#bebebe;"><strong>10.</strong> Tell Ubuntu your name, choose the computer name and set up a password. Click Forward:<br><strong>11.</strong> Installation starts, you have now some 20+ minutes for a coffee break, or you can watch a presentation about Ubuntu by clicking<span style="background-color: transparent;">those arrow               symbols on left and right:</span></span></p>

<p><span style="color:#bebebe;"><strong>12.</strong> When installation is finished, you have to unmount (deattach) Ubuntu ISO image before reboot. Before clicking Restart Now,<span style="background-color: transparent;">OpenDevices menu         from vm window, click CD/DVD devices, choose Unmount CD/DVD Device:</span></span></p>

<p><span style="color:#bebebe;"><strong>13.</strong> Click Restart Now:<br><strong>14.</strong> When Ubuntu has booted, click your username to open a password prompt. Type your password, click Log In:<br><strong>15.</strong> To fully integrate Ubuntu vm to your Windows 7 desktop, to allow networking and for instance cross platform <span style="background-color: transparent;">copy &amp; paste, you need to                       install VirtualBox Guest Additions. Click Devices menu, choose Install Guest Additions:</span></span></p>

<p><span style="color:#bebebe;"><strong>16.</strong> If the CD/DVD icon appears on the desktop, right click it and choose Open With Autorun Prompt:<br><strong>17.</strong> If the CD/DVD icon does not appear on desktop (happens sometimes), open Ubuntu's Places menu, and <span style="background-color: transparent;">choose VBOXADDITIONS. Choose               then Open Autorun Prompt from VBOXADDITIONS window:</span></span></p>

<p><span style="color:#bebebe;"><strong>18.</strong>  Choose Run to start Guest Additions setup:<br><strong>19.</strong>  You must now enter the administrative password. It is the same you chose for your account, so enter it now:<br><strong>20.</strong>  When Guest Additions are set up, you must press Return (Enter) to close the window:<br><strong>21.</strong>  Restart Ubuntu:<br><strong>22.</strong>  After reboot, you are ready to go:<br><strong>23.</strong> Thats it.</span></p>

<p> </p>
</div><div id="wb_element_instance465" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(85);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance465");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance465").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance461" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance462" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance463" class="wb_element"><div id="wb_element_instance463_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance463_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance463_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance463_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance463_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance463_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance463_toolbox"); }
			</script></div><div id="wb_element_instance466" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>