<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>News</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link href="css/9.css?ts=1425383880" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance1139" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li class="active"><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance1140" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance1144" class="wb_element"><img alt="" src="gallery/8de4722cf5f9823f12d337a09f37b002_275x150.jpg"></div><div id="wb_element_instance1145" class="wb_element"><img alt="" src="gallery/ad88ce7814f47d18ee24a2ee86f0ce63_275x150.jpg"></div><div id="wb_element_instance1146" class="wb_element"><img alt="" src="gallery/b4a7e919e60f89e904dd8098880627ac_275x150.jpg"></div><div id="wb_element_instance1147" class="wb_element"><img alt="" src="gallery/15ccd088231257e4328c1eeda60ab381_275x150.jpg"></div><div id="wb_element_instance1148" class="wb_element"><img alt="" src="gallery/318d930dc39075c1f40ef98b4a76ffde_275x150.jpg"></div><div id="wb_element_instance1149" class="wb_element"><img alt="" src="gallery/603c991dd84a56e4442bafa49998b0c9_275x150.jpg"></div><div id="wb_element_instance1150" class="wb_element"><img alt="" src="gallery/585a1c3189d2b06736c0009e295d401f_275x150.jpg"></div><div id="wb_element_instance1151" class="wb_element"><img alt="" src="gallery/d80f88eca5d66f6dce8f1aa64df487eb_275x150.jpg"></div><div id="wb_element_instance1152" class="wb_element"><img alt="" src="gallery/89d697b4de748526ddbd422c1ee47412_275x150.jpg"></div><div id="wb_element_instance1153" class="wb_element"><img alt="" src="gallery/37dc05079ac2ea4a1ca4c2a53811f0e5_275x150.jpeg"></div><div id="wb_element_instance1154" class="wb_element"><img alt="" src="gallery/5f32c8f62da559ad042baa48434d1121_275x150.jpg"></div><div id="wb_element_instance1155" class="wb_element"><img alt="" src="gallery/7f96a8e694c61d33c521042cb70d0fda_275x150.png"></div><div id="wb_element_instance1156" class="wb_element"><img alt="" src="gallery/4ae8312bb95496a9c539481858eda77e_275x150.jpg"></div><div id="wb_element_instance1157" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="Bitcoin/">Bitstamp Exchange Hacked, Website Offline, Bitcoin Worth $5M Stolen.</a></h1>
</div><div id="wb_element_instance1158" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="WifiPhisher/">WiFiPhisher — Automated Phishing Attacks Against Wi-Fi .</a></h1>
</div><div id="wb_element_instance1159" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="Gmail-Blocked/">Google's Gmail blocked in China.</a></h1>
</div><div id="wb_element_instance1160" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="ExCbs-Reporter/">Ex-CBS reporter sues Obama administration for hacking her computer.</a></h1>
</div><div id="wb_element_instance1161" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="Xbox-Sdk/">Hacker Leaks Xbox One SDK that could let Developers make Homebrew Apps.</a></h1>
</div><div id="wb_element_instance1162" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="facebook-read-users-messages/">Facebook to face lawsuit for ‘reading’ users’ messages.</a></h1>
</div><div id="wb_element_instance1163" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="Fingerprint-hacked/">Hackers Show How They Can Get Your Fingerprint From a Photograph.</a></h1>
</div><div id="wb_element_instance1164" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="sony/">Hacker Group Lizard Squad Takes Down Sony's PlayStation.</a></h1>
</div><div id="wb_element_instance1165" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="paypal/">Researcher Shows How To Hack Any PayPal Account In Just One Click.</a></h1>
</div><div id="wb_element_instance1166" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="google-microsoft/">Google Makes Vulnerable Windows Code Public, No Fix From Microsoft.</a></h1>
</div><div id="wb_element_instance1167" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="Ec-council/">Hackers Deface  EC-Council Sub-Domains.</a></h1>
</div><div id="wb_element_instance1168" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="32-sites/">India blocks 32 websites, including GitHub, Vimeo, Pastebin...</a></h1>
</div><div id="wb_element_instance1169" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="gogo/">Gogo Serving Fake SSL Certificates.</a></h1>
</div><div id="wb_element_instance1170" class="wb_element"><img alt="" src="gallery/ef6defb3a32164b21329b9ccbe2b6ffd_275x150.jpeg"></div><div id="wb_element_instance1171" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="top-2014/">Top Worst Cyber Attacks of 2014.</a></h1>
</div><div id="wb_element_instance1172" class="wb_element"><img alt="" src="gallery/b61b8aa2ab2b3e0d23932ae396d499a7_275x150.jpg"></div><div id="wb_element_instance1173" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><a href="Twitter-9000/">Saudi Ethical Hackers help Cops to Hack 9000 Porno Twitter Accounts.</a></h1>
</div><div id="wb_element_instance1174" class="wb_element"><div style="font-size: 1px; overflow: hidden; line-height: 1px; padding: 0; background: transparent; float: none; position: relative; margin: 1px 0 0 0; width: 100%; height: 1px; left: 0; top: 50%; border-top: 3px solid #303030;"></div></div><div id="wb_element_instance1175" class="wb_element"><a class="wb_button" href="latest-news-for-hacking/"><span>1</span></a></div><div id="wb_element_instance1176" class="wb_element"><a class="wb_button" href="News2/"><span>2</span></a></div><div id="wb_element_instance1177" class="wb_element"><a class="wb_button" href="News3/"><span>3</span></a></div><div id="wb_element_instance1178" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(9);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance1178");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance1178").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance1141" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance1142" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance1143" class="wb_element"><div id="wb_element_instance1143_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance1143_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance1143_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1143_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1143_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance1143_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance1143_toolbox"); }
			</script></div><div id="wb_element_instance1179" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>