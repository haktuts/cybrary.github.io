<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Wifi Hacking</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="Wi-Fi is the industry name for wireless local area network (WLAN)communication technology related to the IEEE 802.11 family of wireless networking standards.
Wi-Fi technology first became popular with 802.11b, introduced in 1999 and the first standard in that family to enjoy mainstream adoption. Today, Wi-Fi refers to any of the established standards:
802.11a
802.11b
802.11g
802.11n
802.11ac" />
	<meta name="keywords" content="Introduction of wifi,Radio Types of wifi" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/91.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance531" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance532" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance536" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">Introduction of wifi</span></h1>

<p> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;">        <strong>Wi-Fi</strong> is the industry name for wireless local area network (WLAN)communication technology related to the IEEE 802.11 family of wireless networking standards.<br>
Wi-Fi technology first became popular with 802.11b, introduced in 1999 and the first standard in that family to enjoy mainstream adoption. Today, Wi-Fi refers to any of the established standards:<br><strong>802.11a<br>
802.11b<br>
802.11g<br>
802.11n<br>
802.11ac</strong><br><br>
The Wi-Fi Alliance certifies vendor equipment to ensure 802.11 products on the market follow the various 802.11 specifications.<br>
Consumer versions of Wi-Fi products have additionally maintained backward compatibility.<br>
For example, 802.11b, 802.11g, and 802.11n equipment all can communicate with each other, and mixed Wi-Fi networks with devices running multiple of these standards are commonly referred to as "802.11b/g/n" networks.<br>
802.11ac equipment also communicates with each of these others.<br>
The old 802.11a technology is not compatible with these others and has fallen out of mainstream usage as a result.</span></p>

<p class="wb-stl-normal"> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>Radio Types of wifi</strong></span></h1>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;">            <strong>802.11:</strong> In 1997, the Institute of Electrical and Electronics Engineers (IEEE) created the first WLAN standard.<br>
They called it 802.11 after the name of the group formed to oversee its development.<br>
Unfortunately, 802.11 only supported a maximum network bandwidth of 2 Mbps - too slow for most applications.<br>
For this reason, ordinary 802.11 wireless products are no longer manufactured.<br><br><strong>802.11b:</strong> IEEE expanded on the original 802.11 standard in July 1999, creating the 802.11bspecification.<br>
802.11b supports bandwidth up to 11 Mbps, comparable to traditionalEthernet .<br>
802.11b uses the same unregulated radio signaling frequency (2.4 GHz) as the original 802.11 standard. Vendors often prefer using these frequencies to lower their production costs.<br>
Being unregulated, 802.11b gear can incur interference from microwave ovens, cordless phones, and other appliances using the same 2.4 GHz range.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><span style="background-color: transparent;">However, by installing 802.11b gear a reasonable distance from other appliances, interference can easily be avoided.</span></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Pros of 802.11b -</strong> lowest cost; signal range is good and not easily obstructed<br><strong>Cons of 802.11b -</strong> slowest maximum speed; home appliances may interfere on the unregulated frequency band<br><br><strong>802.11a</strong><br>
While 802.11b was in development, IEEE created a second extension to the original 802.11 standard called 802.11a . Because 802.11b gained in popularity much faster than did 802.11a, some folks believe that 802.11a was created after 802.11b.<br>
 In fact, 802.11a was created at the same time. Due to its higher cost, 802.11a is usually found on business networks whereas 802.11b better serves the home market.<br>
802.11a supports bandwidth up to 54 Mbps and signals in a regulated frequency spectrum around 5 GHz.<br>
This higher frequency compared to 802.11b shortens the range of 802.11a networks.<br>
The higher frequency also means 802.11a signals have more difficulty penetrating walls and other obstructions.<br>
Because 802.11a and 802.11b utilize different frequencies, the two technologies are incompatible with each other. Some vendors offer hybrid 802.11a/b network gear, but these products merely implement the two standards side by side (each connected devices must use one or the other).</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Pros of 802.11a</strong> <strong>-</strong> fast maximum speed; regulated frequencies prevent signal interference from other devices<br><strong>Cons of 802.11a</strong> <strong>-</strong> highest cost; shorter range signal that is more easily obstructed</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><span style="background-color: transparent;">           </span></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><span style="background-color: transparent;"><strong>802.11g: </strong></span></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><span style="background-color: transparent;">In 2002 and 2003, WLAN products supporting a newer standard called 802.11g emerged on the market.</span></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">802.11g attempts to combine the best of both 802.11a and 802.11b.<br>
802.11g supports bandwidth up to 54 Mbps, and it uses the 2.4 Ghz frequency for greater range. 802.11g is backwards compatible with 802.11b, meaning that 802.11g access points will work with 802.11b wireless network adapters and vice versa.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Pros of 802.11g -</strong> fast maximum speed; signal range is good and not easily obstructed<br><strong>Cons of 802.11g - </strong>costs more than 802.11b; appliances may interfere on the unregulated signal frequency</span><br>
 </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"> <strong>802.11n: </strong></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><span style="background-color: transparent;">802.11n (also sometimes known as "Wireless N") was designed to improve on 802.11g in the amount of bandwidth supported by utilizing multiple wireless signals and antennas (called MIMO technology) instead of one.</span></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">Industry standards groups ratified 802.11n in 2009 with specifications providing for up to 300 Mbps of network bandwidth. 802.11n also offers somewhat better range over earlier Wi-Fi standards due to its increased signal intensity, and it is backward-compatible with 802.11b/g gear.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Pros of 802.11n -</strong> fastest maximum speed and best signal range; more resistant to signal interference from outside sources<br><strong>Cons of 802.11n -</strong> standard is not yet finalized; costs more than 802.11g; the use of multiple signals may greatly interfere with nearby 802.11b/g based networks.<br><br><strong>802.11ac</strong></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">The newest generation of Wi-Fi signaling in popular use, 802.11ac utilizes dual band wireless technology, supporting simultaneous connections on both the 2.4 GHz and 5 GHz Wi-Fi bands.<br>
802.11ac offers backward compatibility to 802.11b/g/n and bandwidth rated up to 1300 Mbps on the 5 GHz band plus up to 450 Mbps on 2.4 GHz.<br><br>
802.11ac<br>
The newest generation of Wi-Fi signaling in popular use, 802.11ac utilizes dual band wireless technology, supporting simultaneous connections on both the 2.4 GHz and 5 GHz Wi-Fi bands. 802.11ac offers backward compatibility to 802.11b/g/n and bandwidth rated up to 1300 Mbps on the 5 GHz band plus up to 450 Mbps on 2.4 GHz.<br><br><strong>Other IEEE 802.11</strong> working group standards like 802.11h and 802.11j are extensions or offshoots of Wi-Fi technology that each serve a very specific purpose.<br><br><strong>WiMax</strong> also was developed separately from Wi-Fi. WiMax is designed for long-range networking (spanning miles or kilometers) as opposed to local area wireless networking.</span><br>
 </p>
</div><div id="wb_element_instance537" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(91);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance537");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance537").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance533" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance534" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance535" class="wb_element"><div id="wb_element_instance535_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance535_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance535_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance535_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance535_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance535_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance535_toolbox"); }
			</script></div><div id="wb_element_instance538" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>